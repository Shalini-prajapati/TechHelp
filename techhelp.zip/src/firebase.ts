import { initializeApp } from "firebase/app";
import { 
  getAuth, 
  GoogleAuthProvider, 
  signInWithPopup, 
  signOut,
  onAuthStateChanged,
  User
} from "firebase/auth";
import { 
  getFirestore, 
  doc, 
  getDocFromServer,
  collection,
  getDocs,
  addDoc,
  updateDoc,
  deleteDoc,
  query,
  orderBy,
  limit,
  setDoc,
  getDoc,
  where
} from "firebase/firestore";
import firebaseConfig from "../firebase-applet-config.json";

// Initialize Firebase App
const app = initializeApp(firebaseConfig);

// Initialize Auth
export const auth = getAuth(app);

// Initialize Firestore targeting the enterprise custom DB instance ID
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);

// Google Sign-In Provider setup
export const googleProvider = new GoogleAuthProvider();

// Error definition
export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
  }
}

// Error logger and handler conforming to SKILL.md specs
export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
    },
    operationType,
    path
  };
  console.error('[TechHelp Firestore Error]: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Test Connection
async function testConnection() {
  try {
    // Attempt standard connection validation
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn("Firebase client appears to be offline or config is mismatching.");
    }
  }
}
testConnection();

import { 
  signInAnonymously,
  updateProfile
} from "firebase/auth";

// Direct login popup with graceful cancellation handling
export async function signInWithGoogle() {
  try {
    const result = await signInWithPopup(auth, googleProvider);
    return result.user;
  } catch (error: any) {
    const code = error?.code || "";
    if (
      code === "auth/popup-closed-by-user" ||
      code === "auth/cancelled-popup-request" ||
      code === "auth/user-cancelled" ||
      error?.message?.includes("popup-closed-by-user")
    ) {
      // User closed the popup before completing sign-in
      console.info("Sign-in popup closed by user.");
      return null;
    }
    if (code === "auth/popup-blocked") {
      console.warn("Popup blocked by browser. Please enable popups or use Instant Student Sign-In.");
      return null;
    }
    console.warn("Google sign-in notice:", error?.message || String(error));
    return null;
  }
}

// Instant Student / Guest sign-in without external popup hurdles
export async function signInAsDemoStudent(customName?: string) {
  try {
    const cred = await signInAnonymously(auth);
    if (cred.user) {
      try {
        await updateProfile(cred.user, {
          displayName: customName || "Student Scholar",
          photoURL: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop"
        });
      } catch {
        // Non-critical profile attribute assignment
      }
      return cred.user;
    }
    return null;
  } catch (err: any) {
    // If anonymous sign-in is restricted on the Firebase instance, fallback to local student session
    console.info("Falling back to local student session mode:", err?.message || err);
    const guestUser = {
      uid: "student-guest-" + Math.random().toString(36).substring(2, 9),
      displayName: customName || "Student Scholar",
      email: "scholar@techhelp.edu",
      photoURL: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop",
      isAnonymous: true
    };
    localStorage.setItem("techhelp_guest_session", JSON.stringify(guestUser));
    return guestUser;
  }
}

// Standard log out
export async function logoutUser() {
  try {
    localStorage.removeItem("techhelp_guest_session");
    await signOut(auth);
  } catch (error: any) {
    console.info("Logout completed:", error?.message);
  }
}
