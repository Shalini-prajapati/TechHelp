import React, { useState } from "react";
import { Sparkles, FileText, Compass, HelpCircle, Send, Copy, Loader2, Bot, ArrowRight, Clipboard, Printer, CheckCircle2 } from "lucide-react";
import { invitePrompt } from "../utils";

// Custom light Markdown parser to avoid package matching issues and output pristine styling blocks
function SimpleMarkdown({ text }: { text: string }) {
  if (!text) return null;

  // Split lines
  const lines = text.split("\n");
  
  return (
    <div className="space-y-3 text-slate-800 dark:text-slate-200 text-sm leading-relaxed font-sans">
      {lines.map((line, idx) => {
        // Code Blocks
        if (line.trim().startsWith("```")) {
          return null; // Skip code fences
        }

        // Headers
        if (line.startsWith("# ")) {
          return <h1 key={idx} className="text-2xl font-display font-semibold text-slate-900 dark:text-white pt-4 pb-1 border-b border-slate-200/50 dark:border-white/10">{line.replace("# ", "")}</h1>;
        }
        if (line.startsWith("## ")) {
          return <h2 key={idx} className="text-xl font-display font-medium text-slate-900 dark:text-white pt-4 pb-1 border-b border-slate-200/50 dark:border-white/10">{line.replace("## ", "")}</h2>;
        }
        if (line.startsWith("### ")) {
          return <h3 key={idx} className="text-lg font-semibold text-slate-900 dark:text-slate-100 pt-3">{line.replace("### ", "")}</h3>;
        }

        // Bullet points
        if (line.trim().startsWith("- ") || line.trim().startsWith("* ")) {
          const content = line.trim().substring(2);
          return (
            <li key={idx} className="list-disc ml-5 pl-1 text-slate-700 dark:text-slate-300">
              {parseInlineMarkdown(content)}
            </li>
          );
        }

        // Numbered list
        const numMatch = line.trim().match(/^(\d+)\.\s(.*)/);
        if (numMatch) {
          return (
            <li key={idx} className="list-decimal ml-5 pl-1 text-slate-700 dark:text-slate-300">
              {parseInlineMarkdown(numMatch[2])}
            </li>
          );
        }

        // Empty separator lines
        if (line.trim() === "") {
          return <div key={idx} className="h-2" />;
        }

        // Standard Paragraphs
        return <p key={idx}>{parseInlineMarkdown(line)}</p>;
      })}
    </div>
  );
}

// Inline formatting (bold, codes, italic)
function parseInlineMarkdown(text: string) {
  // Bold match **text**
  const boldRegex = /\*\*(.*?)\*\*/g;
  const parts = [];
  let lastIndex = 0;
  let match;

  while ((match = boldRegex.exec(text)) !== null) {
    if (match.index > lastIndex) {
      parts.push(text.substring(lastIndex, match.index));
    }
    parts.push(
      <strong key={match.index} className="font-bold text-slate-950 dark:text-white">
        {match[1]}
      </strong>
    );
    lastIndex = boldRegex.lastIndex;
  }

  if (lastIndex < text.length) {
    parts.push(text.substring(lastIndex));
  }

  // Handle inline code `code` in children
  const parsedParts = parts.map((part, i) => {
    if (typeof part !== "string") return part;
    const codeRegex = /`(.*?)`/g;
    const codeParts = [];
    let cIndex = 0;
    let cMatch;

    while ((cMatch = codeRegex.exec(part)) !== null) {
      if (cMatch.index > cIndex) {
        codeParts.push(part.substring(cIndex, cMatch.index));
      }
      codeParts.push(
        <code key={cMatch.index} className="font-mono text-xs px-1.5 py-0.5 bg-slate-100 dark:bg-slate-800 text-rose-500 rounded border border-slate-200 dark:border-white/5">
          {cMatch[1]}
        </code>
      );
      cIndex = codeRegex.lastIndex;
    }

    if (cIndex < part.length) {
      codeParts.push(part.substring(cIndex));
    }
    return <span key={i}>{codeParts}</span>;
  });

  return parsedParts;
}

export default function AiTools() {
  const [activeTab, setActiveTab] = useState<'chatbot' | 'resume' | 'roadmap' | 'interview'>('chatbot');

  return (
    <div className="rounded-2xl glass p-6 md:p-8 shadow-xl border border-white/20 dark:border-white/5 transition-all">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <h2 className="text-3xl font-display font-medium text-slate-900 dark:text-white flex items-center gap-2">
            <Sparkles className="w-7 h-7 text-indigo-500 animate-pulse" /> Advanced Student AI Suite
          </h2>
          <p className="text-slate-600 dark:text-slate-400 mt-1">
            Accelerate your studies and professional placements using state-of-the-art server-side Gemini AI.
          </p>
        </div>

        {/* Dynamic selectors */}
        <div className="flex flex-wrap gap-2 bg-slate-100 dark:bg-slate-900/50 p-1 rounded-xl w-full md:w-auto">
          <button
            onClick={() => setActiveTab('chatbot')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium text-sm transition-all flex-1 md:flex-none ${
              activeTab === 'chatbot'
                ? 'bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <Bot className="w-4 h-4" /> AI Tutor
          </button>
          <button
            onClick={() => setActiveTab('resume')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium text-sm transition-all flex-1 md:flex-none ${
              activeTab === 'resume'
                ? 'bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <FileText className="w-4 h-4" /> Resume Builder
          </button>
          <button
            onClick={() => setActiveTab('roadmap')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium text-sm transition-all flex-1 md:flex-none ${
              activeTab === 'roadmap'
                ? 'bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <Compass className="w-4 h-4" /> Career Roadmaps
          </button>
          <button
            onClick={() => setActiveTab('interview')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium text-sm transition-all flex-1 md:flex-none ${
              activeTab === 'interview'
                ? 'bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <HelpCircle className="w-4 h-4" /> Interview Prep
          </button>
        </div>
      </div>

      {/* Frame Active tools */}
      <div className="bg-white/40 dark:bg-slate-900/40 p-1 rounded-xl">
        {activeTab === 'chatbot' && <AiChatBot />}
        {activeTab === 'resume' && <AiResumeBuilder />}
        {activeTab === 'roadmap' && <AiRoadmapGenerator />}
        {activeTab === 'interview' && <AiInterviewPrep />}
      </div>
    </div>
  );
}

// -----------------------------------------------------------------
// 1. AI CHATBOT TUTO
// -----------------------------------------------------------------
interface Message {
  role: 'user' | 'model';
  text: string;
}

function AiChatBot() {
  const [messages, setMessages] = useState<Message[]>([
    { role: 'model', text: "Hello! I am your TechHelp Study Assistant tutor. Feel free to ask me anything about computer science engineering, core concepts, database queries, previous year structures, or career preparation guidelines! What are we studying today?" }
  ]);
  const [inputVal, setInputVal] = useState('');
  const [loading, setLoading] = useState(false);

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputVal.trim() || loading) return;

    const userMsg = inputVal.trim();
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setInputVal('');
    setLoading(true);

    try {
      const response = await fetch("/api/gemini/chatbot", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: userMsg,
          history: messages
        })
      });

      if (!response.ok) throw new Error("Server service failure");

      const data = await response.json();
      setMessages(prev => [...prev, { role: 'model', text: data.reply || "No reply generated." }]);
    } catch (err) {
      setMessages(prev => [...prev, { role: 'model', text: "Apologies, I hit a server transmission bottleneck. Please try sending again." }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-96 max-h-96 border border-slate-150 dark:border-white/5 rounded-2xl overflow-hidden bg-white/70 dark:bg-slate-900/60 shadow-inner">
      {/* Messenger Header */}
      <div className="px-4 py-3 bg-indigo-50/50 dark:bg-indigo-950/20 border-b border-slate-150 dark:border-white/5 flex items-center gap-2">
        <Bot className="w-5 h-5 text-indigo-500 animate-bounce" />
        <span className="font-semibold text-slate-800 dark:text-slate-100 text-sm">TechHelp AI Study Desk</span>
        <span className="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-pulse ml-auto" />
        <span className="text-xs text-slate-500 font-mono">Live Tutor</span>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`p-3 rounded-2xl max-w-lg shadow-sm text-sm ${
              m.role === 'user'
                ? 'bg-gradient-to-r from-indigo-600 to-blue-600 text-white rounded-br-none'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-slate-100 rounded-bl-none border border-slate-150 dark:border-white/5'
            }`}>
              {m.role === 'model' ? (
                <SimpleMarkdown text={m.text} />
              ) : (
                <p className="whitespace-pre-wrap">{m.text}</p>
              )}
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="bg-slate-100 dark:bg-slate-800 p-3 rounded-2xl rounded-bl-none flex items-center gap-2 border border-slate-150 dark:border-white/5">
              <Loader2 className="w-4 h-4 text-indigo-500 animate-spin" />
              <span className="text-xs text-slate-500">TechHelp AI is thinking...</span>
            </div>
          </div>
        )}
      </div>

      {/* Chat input */}
      <form onSubmit={sendMessage} className="p-3 bg-slate-50 dark:bg-slate-950/50 border-t border-slate-200 dark:border-white/5 flex gap-2">
        <input
          type="text"
          value={inputVal}
          onChange={(e) => setInputVal(e.target.value)}
          placeholder="Ask a question (e.g. explain React lifecycle, help me with quicksort...)"
          className="flex-1 px-4 py-2 text-sm rounded-xl border border-slate-250 dark:border-white/10 bg-white dark:bg-slate-850 text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
          disabled={loading}
        />
        <button
          type="submit"
          disabled={loading || !inputVal.trim()}
          className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-xl text-sm transition-all flex items-center justify-center gap-1 shadow-sm"
        >
          <Send className="w-4 h-4" /> Send
        </button>
      </form>
    </div>
  );
}

// -----------------------------------------------------------------
// 2. AI RESUME BUILDER
// -----------------------------------------------------------------
function AiResumeBuilder() {
  const [formData, setFormData] = useState({
    name: "John Doe",
    email: "john.doe@college.edu",
    phone: "+91 9876543210",
    education: "B.Tech in Computer Science and Engineering, Tech College (CGPA: 8.9)",
    skills: "React, Node.js, Express, TypeScript, Tailwind CSS, PostgreSQL, Firebase, git",
    experience: "Web Development Intern at CodeCrafters (Built a content management app increasing efficiency by 20%)",
    projects: "TaskMaster Pro: Collaborative todo application powered by WebSockets to synchronize student routines."
  });
  const [resumeText, setResumeText] = useState('');
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const response = await fetch("/api/gemini/resume", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData)
      });
      if (!response.ok) throw new Error("Resume endpoint failed");
      const data = await response.json();
      setResumeText(data.resume);
    } catch (err) {
      console.error(err);
      setResumeText("### Error generating resume. Please double check backend connectivity.");
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(resumeText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      {/* Inputs Form */}
      <form onSubmit={handleSubmit} className="space-y-4 bg-slate-50 dark:bg-slate-900/40 p-5 rounded-2xl border border-slate-150 dark:border-white/5">
        <h3 className="font-semibold text-slate-800 dark:text-slate-100 flex items-center gap-1.5">
          <FileText className="w-4 h-4 text-indigo-500" /> Enter Your Credentials
        </h3>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs text-slate-500 mb-1">Full Name</label>
            <input
              type="text"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="w-full px-3 py-1.5 text-sm rounded-lg border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
            />
          </div>
          <div>
            <label className="block text-xs text-slate-500 mb-1">Email ID</label>
            <input
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              className="w-full px-3 py-1.5 text-sm rounded-lg border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
            />
          </div>
        </div>
        <div className="grid grid-cols-1 gap-3">
          <div>
            <label className="block text-xs text-slate-500 mb-1">Phone Number</label>
            <input
              type="text"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              className="w-full px-3 py-1.5 text-sm rounded-lg border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
            />
          </div>
          <div>
            <label className="block text-xs text-slate-500 mb-1">Academic Background / College</label>
            <textarea
              rows={2}
              value={formData.education}
              onChange={(e) => setFormData({ ...formData, education: e.target.value })}
              className="w-full px-3 py-1.5 text-sm rounded-lg border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
            />
          </div>
          <div>
            <label className="block text-xs text-slate-500 mb-1">Technical Skills</label>
            <textarea
              rows={2}
              value={formData.skills}
              onChange={(e) => setFormData({ ...formData, skills: e.target.value })}
              className="w-full px-3 py-1.5 text-sm rounded-lg border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
            />
          </div>
          <div>
            <label className="block text-xs text-slate-500 mb-1">Internship / Work Experience</label>
            <textarea
              rows={2}
              value={formData.experience}
              onChange={(e) => setFormData({ ...formData, experience: e.target.value })}
              className="w-full px-3 py-1.5 text-sm rounded-lg border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
            />
          </div>
          <div>
            <label className="block text-xs text-slate-500 mb-1">Project Portfolio highlights</label>
            <textarea
              rows={2}
              value={formData.projects}
              onChange={(e) => setFormData({ ...formData, projects: e.target.value })}
              className="w-full px-3 py-1.5 text-sm rounded-lg border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
            />
          </div>
        </div>
        <button
          type="submit"
          disabled={loading}
          className="w-full flex items-center justify-center gap-2 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-xl text-sm transition-all shadow-md cursor-pointer"
        >
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" /> Formulating Resume Layout...
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4" /> Build ATS Optimized Resume
            </>
          )}
        </button>
      </form>

      {/* Output Display */}
      <div className="flex flex-col border border-slate-150 dark:border-white/5 rounded-2xl bg-white dark:bg-slate-950 p-6 shadow-sm min-h-xs h-[500px] overflow-y-auto">
        {resumeText ? (
          <>
            <div className="flex justify-between items-center pb-3 border-b border-slate-100 dark:border-white/5 mb-4">
              <span className="text-xs uppercase font-mono text-slate-500 font-semibold">Glow Resume Draft</span>
              <div className="flex gap-2">
                <button
                  onClick={copyToClipboard}
                  className="flex items-center gap-1 px-3 py-1 bg-slate-50 hover:bg-slate-100 dark:bg-slate-900 dark:hover:bg-slate-800 text-xs text-slate-700 dark:text-slate-300 font-semibold border border-slate-200 dark:border-white/5 rounded-lg"
                >
                  {copied ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" /> : <Clipboard className="w-3.5 h-3.5" />}
                  {copied ? "Copied!" : "Copy MD"}
                </button>
                <button
                  onClick={() => window.print()}
                  className="flex items-center gap-1 px-3 py-1 bg-slate-50 hover:bg-slate-100 dark:bg-slate-900 dark:hover:bg-slate-800 text-xs text-slate-700 dark:text-slate-300 font-semibold border border-slate-200 dark:border-white/5 rounded-lg"
                >
                  <Printer className="w-3.5 h-3.5" /> Print
                </button>
              </div>
            </div>
            <div className="prose prose-slate dark:prose-invert">
              <SimpleMarkdown text={resumeText} />
            </div>
          </>
        ) : (
          <div className="h-full flex flex-col justify-center items-center text-center text-slate-400">
            <FileText className="w-16 h-16 text-indigo-100 dark:text-slate-800 mb-3" />
            <h4 className="font-semibold text-slate-600 dark:text-slate-400">Professional Harvard PDF Ready Output</h4>
            <p className="text-xs text-slate-500 mt-1 max-w-xs">
              Complete the left criteria values and press build to formulate your industry-matched resume instantly.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

// -----------------------------------------------------------------
// 3. AI ROADMAP MAKER
// -----------------------------------------------------------------
function AiRoadmapGenerator() {
  const [goal, setGoal] = useState("Full Stack MERN Developer");
  const [level, setLevel] = useState("Beginner");
  const [roadmapText, setRoadmapText] = useState("");
  const [loading, setLoading] = useState(false);

  const handleGenerate = async () => {
    if (!goal.trim()) return;
    setLoading(true);
    try {
      const response = await fetch("/api/gemini/roadmap", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ goal, currentLevel: level })
      });
      if (!response.ok) throw new Error("Roadmap service failed");
      const data = await response.json();
      setRoadmapText(data.roadmap);
    } catch (e) {
      setRoadmapText("### Service failure generating roadmap. Please retry later.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      {/* Design Goal Inputs */}
      <div className="space-y-4 bg-slate-50 dark:bg-slate-900/40 p-5 rounded-2xl border border-slate-150 dark:border-white/5 h-fit">
        <h3 className="font-semibold text-slate-800 dark:text-slate-100 flex items-center gap-1.5">
          <Compass className="w-4 h-4 text-indigo-500" /> Career Roadmap Outline
        </h3>
        <div>
          <label className="block text-xs text-slate-500 mb-1">Target Student Goal</label>
          <input
            type="text"
            className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
            value={goal}
            onChange={(e) => setGoal(e.target.value)}
            placeholder="E.g., Quantum ML Engineer, Cloud Native Admin..."
          />
        </div>
        <div>
          <label className="block text-xs text-slate-500 mb-1">Your Present Level</label>
          <select
            className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
            value={level}
            onChange={(e) => setLevel(e.target.value)}
          >
            <option value="Beginner">Beginner (No background programming)</option>
            <option value="Intermediate">Intermediate (Already built 1-2 small projects)</option>
            <option value="Advanced">Advanced (Ready for production industry internships)</option>
          </select>
        </div>
        <button
          onClick={handleGenerate}
          disabled={loading}
          className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-xl text-sm transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer"
        >
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" /> Engineering Roadmap Timeline...
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4" /> Synthesize Study Curriculum
            </>
          )}
        </button>
      </div>

      {/* Render Roadmap */}
      <div className="border border-slate-150 dark:border-white/5 rounded-2xl bg-white dark:bg-slate-950 p-6 h-[500px] overflow-y-auto">
        {roadmapText ? (
          <div>
            <h3 className="text-xl font-display font-semibold text-indigo-600 dark:text-indigo-400 mb-4 flex items-center gap-2">
              <Bot className="w-5 h-5 text-indigo-500" /> AI Career Roadmap Recommendation
            </h3>
            <SimpleMarkdown text={roadmapText} />
          </div>
        ) : (
          <div className="h-full flex flex-col justify-center items-center text-center text-slate-400">
            <Compass className="w-16 h-16 text-indigo-100 dark:text-slate-800 mb-3 animate-spin duration-1000" />
            <h4 className="font-semibold text-slate-600 dark:text-slate-400 font-display">Personalized Phase Curriculums</h4>
            <p className="text-xs text-slate-500 mt-1 max-w-xs">
              Formulate sequential month-by-month, project-oriented courses specific to your professional ambitions.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

// -----------------------------------------------------------------
// 4. AI INTERVIEW PREPARATION SHEETS
// -----------------------------------------------------------------
function AiInterviewPrep() {
  const [role, setRole] = useState("React Developer");
  const [industry, setIndustry] = useState("FinTech");
  const [questions, setQuestions] = useState("");
  const [loading, setLoading] = useState(false);

  const handleGenerate = async () => {
    if (!role.trim()) return;
    setLoading(true);
    try {
      const response = await fetch("/api/gemini/interview", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ role, industry })
      });
      if (!response.ok) throw new Error("Interview endpoint failure");
      const data = await response.json();
      setQuestions(data.interviewQuestions);
    } catch (e) {
      setQuestions("### Service failure generating mock questions. Please try again later.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      {/* Design Interview inputs */}
      <div className="space-y-4 bg-slate-50 dark:bg-slate-900/40 p-5 rounded-2xl border border-slate-150 dark:border-white/5 h-fit">
        <h3 className="font-semibold text-slate-800 dark:text-slate-100 flex items-center gap-1.5">
          <HelpCircle className="w-4 h-4 text-indigo-500" /> Technical Recruitment Board
        </h3>
        <div>
          <label className="block text-xs text-slate-500 mb-1">Target Placement Role / Subject</label>
          <input
            type="text"
            className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
            value={role}
            onChange={(e) => setRole(e.target.value)}
            placeholder="E.g., Backend Developer, ML Specialist, Java Expert..."
          />
        </div>
        <div>
          <label className="block text-xs text-slate-500 mb-1">Target Sector Industry</label>
          <input
            type="text"
            className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
            value={industry}
            onChange={(e) => setIndustry(e.target.value)}
            placeholder="E.g., FAANG, Banking, Web3 Startup..."
          />
        </div>
        <button
          onClick={handleGenerate}
          disabled={loading}
          className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-xl text-sm transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer"
        >
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" /> Recruiting Top Technical Mock Questions...
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4" /> Generate Recruitment Mock Set
            </>
          )}
        </button>
      </div>

      {/* Interview Display */}
      <div className="border border-slate-150 dark:border-white/5 rounded-2xl bg-white dark:bg-slate-950 p-6 h-[500px] overflow-y-auto">
        {questions ? (
          <div>
            <h3 className="text-xl font-display font-semibold text-indigo-600 dark:text-indigo-400 mb-4 flex items-center gap-2">
              <Bot className="w-5 h-5 text-indigo-300" /> AI Mock Board Questions
            </h3>
            <SimpleMarkdown text={questions} />
          </div>
        ) : (
          <div className="h-full flex flex-col justify-center items-center text-center text-slate-400">
            <HelpCircle className="w-16 h-16 text-indigo-100 dark:text-slate-800 mb-3" />
            <h4 className="font-semibold text-slate-600 dark:text-slate-400 font-display">Targeted Technical Prep Sheets</h4>
            <p className="text-xs text-slate-500 mt-1 max-w-xs">
              Request industry-curated technical coding interview mock questionnaires corresponding to your desired position.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
