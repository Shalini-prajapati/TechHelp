import React, { useState } from "react";
import { PlusCircle, Trash2, Shield, BarChart3, Users, Briefcase, FileDown, BookOpen, Sparkles, CheckCircle2 } from "lucide-react";
import { Internship, Job, StudyMaterial, Blog } from "../types";

interface AdminPanelProps {
  user: any;
  isAdmin: boolean;
  internships: Internship[];
  jobs: Job[];
  notes: StudyMaterial[];
  blogs: Blog[];
  onAddInternship: (item: Omit<Internship, "id">) => Promise<void>;
  onDeleteInternship: (id: string) => Promise<void>;
  onAddJob: (item: Omit<Job, "id">) => Promise<void>;
  onDeleteJob: (id: string) => Promise<void>;
  onAddNote: (item: Omit<StudyMaterial, "id">) => Promise<void>;
  onAddBlog: (item: Omit<Blog, "id">) => Promise<void>;
}

export default function AdminPanel({
  user,
  isAdmin,
  internships,
  jobs,
  notes,
  blogs,
  onAddInternship,
  onDeleteInternship,
  onAddJob,
  onDeleteJob,
  onAddNote,
  onAddBlog
}: AdminPanelProps) {

  // Current sub-tab
  const [adminTab, setAdminTab] = useState<'dashboard' | 'addJob' | 'addInternship' | 'addNote' | 'addBlog'>('dashboard');

  // Input states
  const [internshipForm, setInternshipForm] = useState({
    title: "",
    companyName: "",
    stipend: "",
    location: "",
    duration: "",
    applyUrl: "",
    logoUrl: ""
  });

  const [jobForm, setJobForm] = useState({
    role: "",
    companyName: "",
    salary: "",
    location: "",
    applyUrl: "",
    logoUrl: ""
  });

  const [noteForm, setNoteForm] = useState({
    title: "",
    category: "notes" as any,
    subject: "",
    branch: "",
    downloadUrl: "",
  });

  const [blogForm, setBlogForm] = useState({
    title: "",
    summary: "",
    content: "",
    imageUrl: "",
    author: ""
  });

  const [actionSuccess, setActionSuccess] = useState("");

  const handleCreateInternship = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const payload = {
        ...internshipForm,
        logoUrl: internshipForm.logoUrl || "https://images.unsplash.com/photo-1549692520-acc6669e2f0c?auto=format&fit=crop&w=120&h=120&q=80",
        createdAt: new Date().toISOString()
      };
      await onAddInternship(payload);
      setInternshipForm({
        title: "",
        companyName: "",
        stipend: "",
        location: "",
        duration: "",
        applyUrl: "",
        logoUrl: ""
      });
      triggerStatus("Internship listing created successfully!");
    } catch (err) {
      alert("Error: " + err);
    }
  };

  const handleCreateJob = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const payload = {
        ...jobForm,
        logoUrl: jobForm.logoUrl || "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=120&h=120&q=80",
        createdAt: new Date().toISOString()
      };
      await onAddJob(payload);
      setJobForm({
        role: "",
        companyName: "",
        salary: "",
        location: "",
        applyUrl: "",
        logoUrl: ""
      });
      triggerStatus("Job listing created successfully!");
    } catch (err) {
      alert("Error: " + err);
    }
  };

  const handleCreateNote = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const payload = {
        ...noteForm,
        downloadsCount: 0,
        uploadedBy: user?.displayName || "Administrator",
        createdAt: new Date().toISOString()
      };
      await onAddNote(payload);
      setNoteForm({
        title: "",
        category: "notes",
        subject: "",
        branch: "",
        downloadUrl: ""
      });
      triggerStatus("Study material listing published!");
    } catch (err) {
      alert("Error: " + err);
    }
  };

  const handleCreateBlog = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const payload = {
        ...blogForm,
        imageUrl: blogForm.imageUrl || "https://images.unsplash.com/photo-1457369804613-52c61a468e7d?auto=format&fit=crop&w=400&h=250&q=80",
        author: blogForm.author || user?.displayName || "Admin Team",
        createdAt: new Date().toISOString()
      };
      await onAddBlog(payload);
      setBlogForm({
        title: "",
        summary: "",
        content: "",
        imageUrl: "",
        author: ""
      });
      triggerStatus("Academic blog post created successfully!");
    } catch (err) {
      alert("Error: " + err);
    }
  };

  const triggerStatus = (msg: string) => {
    setActionSuccess(msg);
    setTimeout(() => {
      setActionSuccess("");
      setAdminTab('dashboard');
    }, 2500);
  };

  // KPI Calculations
  const totalDownloadsSum = notes.reduce((sum, n) => sum + (n.downloadsCount || 0), 0);

  return (
    <div className="rounded-2xl glass p-6 md:p-8 shadow-xl border border-white/20 dark:border-white/5 transition-all">
      
      {/* Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <h2 className="text-3xl font-display font-medium text-slate-900 dark:text-white flex items-center gap-1.5">
            <Shield className="w-7 h-7 text-rose-500 animate-pulse" /> TechHelp Administration Board
          </h2>
          <p className="text-slate-600 dark:text-slate-400 mt-1">
            Publish educational curriculum, job postings, internship lists and study notes.
          </p>
        </div>

        {/* Warning Badge */}
        {!isAdmin && (
          <div className="bg-amber-50 dark:bg-amber-950/30 text-amber-600 dark:text-amber-400 border border-amber-200 dark:border-white/5 py-1.5 px-4 rounded-xl text-xs font-semibold">
            🔓 Simulated Admin Sandbox Mode Active
          </div>
        )}
      </div>

      {/* Admin Tabs */}
      <div className="flex flex-wrap gap-2 border-b border-slate-100 dark:border-white/5 pb-4 mb-6">
        <button
          onClick={() => setAdminTab('dashboard')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
            adminTab === 'dashboard' ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <BarChart3 className="w-3.5 h-3.5" /> Dashboard Metrics
        </button>
        <button
          onClick={() => setAdminTab('addInternship')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
            adminTab === 'addInternship' ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <PlusCircle className="w-3.5 h-3.5 text-blue-500" /> Add Internship
        </button>
        <button
          onClick={() => setAdminTab('addJob')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
            adminTab === 'addJob' ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <PlusCircle className="w-3.5 h-3.5 text-indigo-500" /> Add Job
        </button>
        <button
          onClick={() => setAdminTab('addNote')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
            adminTab === 'addNote' ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <PlusCircle className="w-3.5 h-3.5 text-emerald-500" /> Share Study Note
        </button>
        <button
          onClick={() => setAdminTab('addBlog')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
            adminTab === 'addBlog' ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <PlusCircle className="w-3.5 h-3.5 text-purple-500" /> Add Blog Article
        </button>
      </div>

      {actionSuccess && (
        <div className="mb-6 p-3 bg-emerald-50 dark:bg-emerald-950/20 text-emerald-600 dark:text-emerald-400 border border-emerald-250 dark:border-white/5 rounded-xl text-xs font-bold flex items-center gap-1.5">
          <CheckCircle2 className="w-4 h-4" /> {actionSuccess}
        </div>
      )}

      {/* Render tabs */}
      <div className="transition-all duration-300">
        {adminTab === 'dashboard' && (
          <div className="space-y-8">
            {/* KPI metrics row */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
              <div className="bg-white dark:bg-slate-950 p-5 rounded-2xl border border-slate-150 dark:border-white/5 shadow-sm">
                <Users className="w-6 h-6 text-blue-500 mb-2" />
                <span className="text-[11px] font-mono uppercase tracking-wider text-slate-500 font-semibold block">Total Student Users</span>
                <span className="text-3xl font-display font-bold text-slate-900 dark:text-white mt-1 block">142</span>
              </div>
              <div className="bg-white dark:bg-slate-950 p-5 rounded-2xl border border-slate-150 dark:border-white/5 shadow-sm">
                <Briefcase className="w-6 h-6 text-indigo-500 mb-2" />
                <span className="text-[11px] font-mono uppercase tracking-wider text-slate-500 font-semibold block">Total Jobs Listed</span>
                <span className="text-3xl font-display font-bold text-slate-900 dark:text-white mt-1 block">{jobs.length}</span>
              </div>
              <div className="bg-white dark:bg-slate-950 p-5 rounded-2xl border border-slate-150 dark:border-white/5 shadow-sm">
                <BookOpen className="w-6 h-6 text-purple-500 mb-2" />
                <span className="text-[11px] font-mono uppercase tracking-wider text-slate-500 font-semibold block">Total Internships</span>
                <span className="text-3xl font-display font-bold text-slate-900 dark:text-white mt-1 block">{internships.length}</span>
              </div>
              <div className="bg-white dark:bg-slate-950 p-5 rounded-2xl border border-slate-150 dark:border-white/5 shadow-sm">
                <FileDown className="w-6 h-6 text-emerald-500 mb-2" />
                <span className="text-[11px] font-mono uppercase tracking-wider text-slate-500 font-semibold block">Total Note Downloads</span>
                <span className="text-3xl font-display font-bold text-slate-900 dark:text-white mt-1 block">{totalDownloadsSum}</span>
              </div>
            </div>

            {/* List and manage panels */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Internship List Panel */}
              <div className="bg-slate-50 dark:bg-slate-900/40 border border-slate-150 dark:border-white/5 p-5 rounded-2xl">
                <h3 className="font-semibold text-slate-800 dark:text-slate-150 mb-3 text-sm">Manage Active Internships</h3>
                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {internships.map((item) => (
                    <div key={item.id} className="bg-white dark:bg-slate-950 p-3 rounded-xl flex items-center justify-between border border-slate-100 dark:border-white/5">
                      <div>
                        <h4 className="font-bold text-xs text-slate-800 dark:text-slate-100">{item.title}</h4>
                        <span className="text-[10px] text-slate-500 block">{item.companyName} • {item.location}</span>
                      </div>
                      <button
                        onClick={() => onDeleteInternship(item.id)}
                        className="p-1 px-2 hover:bg-rose-50 text-rose-500 rounded-lg text-xs font-semibold flex items-center gap-1 cursor-pointer transition-all"
                      >
                        <Trash2 className="w-3.5 h-3.5" /> Wipe
                      </button>
                    </div>
                  ))}
                  {internships.length === 0 && (
                    <span className="text-xs text-slate-400 italic text-center block py-4">No active internships logged.</span>
                  )}
                </div>
              </div>

              {/* Jobs List Panel */}
              <div className="bg-slate-50 dark:bg-slate-900/40 border border-slate-150 dark:border-white/5 p-5 rounded-2xl">
                <h3 className="font-semibold text-slate-800 dark:text-slate-150 mb-3 text-sm">Manage Active Jobs</h3>
                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {jobs.map((item) => (
                    <div key={item.id} className="bg-white dark:bg-slate-950 p-3 rounded-xl flex items-center justify-between border border-slate-100 dark:border-white/5">
                      <div>
                        <h4 className="font-bold text-xs text-slate-800 dark:text-slate-100">{item.role}</h4>
                        <span className="text-[10px] text-slate-500 block">{item.companyName} • {item.location}</span>
                      </div>
                      <button
                        onClick={() => onDeleteJob(item.id)}
                        className="p-1 px-2 hover:bg-rose-50 text-rose-500 rounded-lg text-xs font-semibold flex items-center gap-1 cursor-pointer transition-all"
                      >
                        <Trash2 className="w-3.5 h-3.5" /> Wipe
                      </button>
                    </div>
                  ))}
                  {jobs.length === 0 && (
                    <span className="text-xs text-slate-400 italic text-center block py-4">No active jobs logged.</span>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Form add internship */}
        {adminTab === 'addInternship' && (
          <form onSubmit={handleCreateInternship} className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-white/5 p-6 rounded-2xl space-y-4 max-w-xl mx-auto">
            <h3 className="font-bold text-slate-900 dark:text-white text-sm">Add Internship Listing</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs text-slate-500 mb-1">Company Offeror</label>
                <input
                  type="text" required placeholder="E.g., Adobe"
                  value={internshipForm.companyName}
                  onChange={(e) => setInternshipForm({...internshipForm, companyName: e.target.value})}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>
              <div>
                <label className="block text-xs text-slate-500 mb-1">Position / Title</label>
                <input
                  type="text" required placeholder="E.g., Research Intern"
                  value={internshipForm.title}
                  onChange={(e) => setInternshipForm({...internshipForm, title: e.target.value})}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs text-slate-500 mb-1">Monthly Stipend</label>
                <input
                  type="text" placeholder="E.g., $4,000 / month"
                  value={internshipForm.stipend}
                  onChange={(e) => setInternshipForm({...internshipForm, stipend: e.target.value})}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>
              <div>
                <label className="block text-xs text-slate-500 mb-1">Geographic Location</label>
                <input
                  type="text" required placeholder="E.g., Delhi, NCR (Office)"
                  value={internshipForm.location}
                  onChange={(e) => setInternshipForm({...internshipForm, location: e.target.value})}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs text-slate-500 mb-1">Internship Duration</label>
                <input
                  type="text" placeholder="E.g., 6 Months"
                  value={internshipForm.duration}
                  onChange={(e) => setInternshipForm({...internshipForm, duration: e.target.value})}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>
              <div>
                <label className="block text-xs text-slate-500 mb-1">Applications URL / Link</label>
                <input
                  type="text" required placeholder="https://adobe.com/careers"
                  value={internshipForm.applyUrl}
                  onChange={(e) => setInternshipForm({...internshipForm, applyUrl: e.target.value})}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>
            </div>
            <button
              type="submit"
              className="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg text-xs shadow-md mt-4 cursor-pointer"
            >
              Add Internship
            </button>
          </form>
        )}

        {/* Form add Job */}
        {adminTab === 'addJob' && (
          <form onSubmit={handleCreateJob} className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-white/5 p-6 rounded-2xl space-y-4 max-w-xl mx-auto">
            <h3 className="font-bold text-slate-900 dark:text-white text-sm">Add Job Opening Listing</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs text-slate-500 mb-1">Company Offeror</label>
                <input
                  type="text" required placeholder="E.g., Apple"
                  value={jobForm.companyName}
                  onChange={(e) => setJobForm({...jobForm, companyName: e.target.value})}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>
              <div>
                <label className="block text-xs text-slate-500 mb-1">Role / Position</label>
                <input
                  type="text" required placeholder="E.g., Junior iOS Engineer"
                  value={jobForm.role}
                  onChange={(e) => setJobForm({...jobForm, role: e.target.value})}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs text-slate-500 mb-1">Annual Salary Packages</label>
                <input
                  type="text" placeholder="E.g., $140,000 / year"
                  value={jobForm.salary}
                  onChange={(e) => setJobForm({...jobForm, salary: e.target.value})}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>
              <div>
                <label className="block text-xs text-slate-500 mb-1">Role Office Location</label>
                <input
                  type="text" required placeholder="E.g., Cupertino, CA"
                  value={jobForm.location}
                  onChange={(e) => setJobForm({...jobForm, location: e.target.value})}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>
            </div>
            <div>
              <label className="block text-xs text-slate-500 mb-1">Applications Link / Portal URL</label>
              <input
                type="text" required placeholder="https://apple.com/careers"
                value={jobForm.applyUrl}
                onChange={(e) => setJobForm({...jobForm, applyUrl: e.target.value})}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
              />
            </div>
            <button
              type="submit"
              className="w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg text-xs shadow-md mt-4 cursor-pointer"
            >
              Add Job Opening
            </button>
          </form>
        )}

        {/* Form add Study notes */}
        {adminTab === 'addNote' && (
          <form onSubmit={handleCreateNote} className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-white/5 p-6 rounded-2xl space-y-4 max-w-xl mx-auto">
            <h3 className="font-bold text-slate-900 dark:text-white text-sm">Upload Study Material listing</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs text-slate-500 mb-1">Study Material Title</label>
                <input
                  type="text" required placeholder="E.g., Operating Systems Unit 1 Notes"
                  value={noteForm.title}
                  onChange={(e) => setNoteForm({...noteForm, title: e.target.value})}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>
              <div>
                <label className="block text-xs text-slate-500 mb-1">Category Type</label>
                <select
                  value={noteForm.category}
                  onChange={(e) => setNoteForm({...noteForm, category: e.target.value as any})}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                >
                  <option value="notes">📘 Study Lecture Notes</option>
                  <option value="pyq">📝 PYQ Previous Years Question Exam</option>
                  <option value="syllabus">📋 Academic Syllabus</option>
                  <option value="quantum">📕 BK AKTU Quantum Series Books</option>
                  <option value="ebook">📚 Free E-Books</option>
                </select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs text-slate-500 mb-1">Relative Subject Name</label>
                <input
                  type="text" required placeholder="E.g., Operating Systems (CS-304)"
                  value={noteForm.subject}
                  onChange={(e) => setNoteForm({...noteForm, subject: e.target.value})}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>
              <div>
                <label className="block text-xs text-slate-500 mb-1">Eligible Branch / Discipline</label>
                <input
                  type="text" required placeholder="E.g., BCA, B.Tech CSE, MCA"
                  list="branch-options"
                  value={noteForm.branch}
                  onChange={(e) => setNoteForm({...noteForm, branch: e.target.value})}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
                <datalist id="branch-options">
                  <option value="BCA" />
                  <option value="B.Tech CSE" />
                  <option value="MCA" />
                  <option value="MBA" />
                  <option value="B.Pharm" />
                  <option value="All Branches" />
                </datalist>
              </div>
            </div>
            <div>
              <label className="block text-xs text-slate-500 mb-1">Download Material Hyperlink URL</label>
              <input
                type="text" required placeholder="https://example.com/notes.pdf"
                value={noteForm.downloadUrl}
                onChange={(e) => setNoteForm({...noteForm, downloadUrl: e.target.value})}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
              />
            </div>
            <button
              type="submit"
              className="w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-lg text-xs shadow-md mt-4 cursor-pointer"
            >
              Publish Material
            </button>
          </form>
        )}

        {/* Form add blog article */}
        {adminTab === 'addBlog' && (
          <form onSubmit={handleCreateBlog} className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-white/5 p-6 rounded-2xl space-y-4 max-w-xl mx-auto">
            <h3 className="font-bold text-slate-900 dark:text-white text-sm">Add Academic Blog Post</h3>
            <div>
              <label className="block text-xs text-slate-500 mb-1">Blog Article Title</label>
              <input
                type="text" required placeholder="E.g., Roadmap for becoming DevOps Engineer in 4 month"
                value={blogForm.title}
                onChange={(e) => setBlogForm({...blogForm, title: e.target.value})}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-xs text-slate-500 mb-1">One-line brief summary / subtitle</label>
              <input
                type="text" required placeholder="E.g., Key tools, Docker, Kubernetes steps analyzed..."
                value={blogForm.summary}
                onChange={(e) => setBlogForm({...blogForm, summary: e.target.value})}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-xs text-slate-500 mb-1">Full Article Writing (Markdown supported)</label>
              <textarea
                required rows={5} placeholder="Full content goes here..."
                value={blogForm.content}
                onChange={(e) => setBlogForm({...blogForm, content: e.target.value})}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
              />
            </div>
            <button
              type="submit"
              className="w-full py-2 bg-purple-600 hover:bg-purple-700 text-white font-semibold rounded-lg text-xs shadow-md mt-4 cursor-pointer"
            >
              Publish Article
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
