import React, { useState, useEffect } from "react";
import { MessageSquare, ThumbsUp, PlusCircle, ArrowRight, UserCircle, Send, CheckCircle, Award } from "lucide-react";
import { Discussion, Comment } from "../types";
import { getDiscussions, addDiscussion, upvoteDiscussion, addCommentToDiscussion } from "../dbService";
import { auth } from "../firebase";
import { motion, AnimatePresence } from "motion/react";

interface CommunityProps {
  user: any;
}

export default function StudentCommunity({ user }: CommunityProps) {
  const [forumTab, setForumTab] = useState<'threads' | 'success'>('threads');

  return (
    <div className="space-y-8">
      {/* Community Section Headers */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-3xl font-display font-medium text-slate-900 dark:text-white">
            TechHelp Lounge & Forums
          </h2>
          <p className="text-slate-600 dark:text-slate-400 mt-1">
            Connect with peers, share academic knowledge, and read real student triumphs.
          </p>
        </div>

        <div className="flex bg-slate-100 dark:bg-slate-900/50 p-1 rounded-xl w-full md:w-auto">
          <button
            onClick={() => setForumTab('threads')}
            className={`flex items-center gap-2 px-5 py-2 rounded-lg font-medium text-sm transition-all flex-1 md:flex-none ${
              forumTab === 'threads' ? 'bg-white dark:bg-slate-800 text-blue-600 dark:text-blue-400 shadow-sm' : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            <MessageSquare className="w-4 h-4" /> Discussion Board
          </button>
          <button
            onClick={() => setForumTab('success')}
            className={`flex items-center gap-2 px-5 py-2 rounded-lg font-medium text-sm transition-all flex-1 md:flex-none ${
              forumTab === 'success' ? 'bg-white dark:bg-slate-800 text-blue-600 dark:text-blue-400 shadow-sm' : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            <Award className="w-4 h-4" /> Success Stories
          </button>
        </div>
      </div>

      <div className="transition-all duration-300">
        {forumTab === 'threads' ? (
          <DiscussionBoard user={user} />
        ) : (
          <SuccessStories />
        )}
      </div>
    </div>
  );
}

// -----------------------------------------------------------------
// DISCUSSION BOARD COMPONENT
// -----------------------------------------------------------------
function DiscussionBoard({ user }: { user: any }) {
  const [threads, setThreads] = useState<Discussion[]>([]);
  const [loading, setLoading] = useState(true);
  
  // New Thread inputs
  const [showAddForm, setShowAddForm] = useState(false);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [category, setCategory] = useState<'general' | 'jobs' | 'btech' | 'notes' | 'resources'>('general');

  // Selected thread view
  const [selectedThread, setSelectedThread] = useState<Discussion | null>(null);
  const [commentText, setCommentText] = useState("");

  const refreshThreads = async () => {
    setLoading(true);
    try {
      const dbThreads = await getDiscussions();
      setThreads(dbThreads);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refreshThreads();
  }, []);

  const handleCreateThread = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      alert("Please sign in to start a new discussion!");
      return;
    }
    if (!title.trim() || !content.trim()) return;

    try {
      await addDiscussion({
        title: title.trim(),
        content: content.trim(),
        category,
        authorId: user.uid,
        authorName: user.displayName || user.email || "Anonymous Student",
        authorPhoto: user.photoURL || undefined,
        createdAt: new Date().toISOString()
      });
      setTitle("");
      setContent("");
      setShowAddForm(false);
      refreshThreads();
    } catch (err) {
      alert("Failed to start thread: " + err);
    }
  };

  const handleUpvote = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      await upvoteDiscussion(id);
      // Optimistic update
      setThreads(threads.map(t => t.id === id ? { ...t, upvotes: t.upvotes + 1 } : t));
      if (selectedThread && selectedThread.id === id) {
        setSelectedThread({ ...selectedThread, upvotes: selectedThread.upvotes + 1 });
      }
    } catch (error) {
      console.error("Upvote failed:", error);
    }
  };

  const handleAddComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      alert("Please sign in to participate in the conversation.");
      return;
    }
    if (!commentText.trim() || !selectedThread) return;

    const newComment: Comment = {
      id: Math.random().toString(36).substring(2),
      authorId: user.uid,
      authorName: user.displayName || user.email || "Student",
      authorPhoto: user.photoURL || undefined,
      content: commentText.trim(),
      createdAt: new Date().toISOString()
    };

    try {
      await addCommentToDiscussion(selectedThread.id, newComment);
      const updatedComments = [...(selectedThread.comments || []), newComment];
      setSelectedThread({ ...selectedThread, comments: updatedComments });
      setCommentText("");
      
      // Sync on main list
      setThreads(threads.map(t => t.id === selectedThread.id ? { ...t, comments: updatedComments } : t));
    } catch (err) {
      alert("Comment failed: " + err);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
      {/* Threads list (2cols) */}
      <div className="lg:col-span-2 space-y-4">
        <div className="flex justify-between items-center bg-slate-50 dark:bg-slate-900/40 p-4 rounded-xl border border-slate-100 dark:border-white/5">
          <span className="text-sm font-semibold text-slate-800 dark:text-slate-200">
            {threads.length} Threads available
          </span>
          <button
            onClick={() => {
              if (!user) {
                alert("Please sign in first!");
                return;
              }
              setShowAddForm(!showAddForm);
              setSelectedThread(null);
            }}
            className="flex items-center gap-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-semibold cursor-pointer shadow-sm transition-all"
          >
            <PlusCircle className="w-4 h-4" /> Start Discussion
          </button>
        </div>

        {/* Modal-like form in-place */}
        <AnimatePresence>
          {showAddForm && (
            <motion.form 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              onSubmit={handleCreateThread}
              className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-white/5 p-5 rounded-2xl space-y-4 shadow-md"
            >
              <h3 className="font-semibold text-slate-800 dark:text-slate-150 text-sm">Create New Forum Topic</h3>
              <div>
                <label className="block text-xs text-slate-500 mb-1">Thread Subject / Title</label>
                <input
                  type="text"
                  required
                  placeholder="E.g., Tips for preparing OS examinations in 3 days?"
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs text-slate-500 mb-1">Topic Category</label>
                  <select
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                    value={category}
                    onChange={(e: any) => setCategory(e.target.value)}
                  >
                    <option value="general">🌍 General Discussion</option>
                    <option value="btech">🎓 BTech Academics</option>
                    <option value="jobs">💼 Career & Jobs</option>
                    <option value="notes">📘 study Material</option>
                    <option value="resources">🛠️ Coding Resources</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-xs text-slate-500 mb-1">Content / Message</label>
                <textarea
                  required
                  placeholder="Explain your queries or share useful insights detail here..."
                  rows={4}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                />
              </div>
              <div className="flex gap-2 justify-end">
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="px-4 py-2 border border-slate-200 dark:border-white/10 rounded-xl text-xs text-slate-600 dark:text-slate-400 font-semibold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-semibold cursor-pointer shadow-sm"
                >
                  Publish Topic
                </button>
              </div>
            </motion.form>
          )}
        </AnimatePresence>

        {/* Threads List */}
        {loading ? (
          <div className="py-12 text-center text-slate-500">
            <LoaderComponent />
          </div>
        ) : threads.length === 0 ? (
          <div className="py-12 text-center text-slate-400 bg-slate-50 dark:bg-slate-900/20 rounded-2xl border border-dashed border-slate-200 dark:border-white/5">
            <MessageSquare className="w-12 h-12 mx-auto mb-2 text-slate-300" />
            <p className="font-semibold text-slate-600 dark:text-slate-400">No discussion topics launched yet.</p>
            <p className="text-xs mt-1">Be the very first To start the discussion among peers!</p>
          </div>
        ) : (
          <div className="space-y-3">
            {threads.map((item) => (
              <div
                key={item.id}
                onClick={() => {
                  setSelectedThread(item);
                  setShowAddForm(false);
                }}
                className={`bg-white dark:bg-slate-950 p-5 rounded-2xl border transition-all cursor-pointer shadow-sm hover:border-blue-400 dark:hover:border-blue-500 ${
                  selectedThread?.id === item.id 
                    ? 'border-blue-500 dark:border-blue-500 ring-1 ring-blue-500/20' 
                    : 'border-slate-150 dark:border-white/5'
                }`}
              >
                <div className="flex gap-3 items-start justify-between">
                  <div className="space-y-1">
                    <span className="inline-block text-[10px] uppercase font-mono tracking-wider text-blue-600 dark:text-blue-400 font-semibold bg-blue-50 dark:bg-blue-950/40 px-2 py-0.5 rounded-full">
                      #{item.category}
                    </span>
                    <h4 className="font-semibold text-slate-900 dark:text-white hover:text-blue-600 transition-colors">
                      {item.title}
                    </h4>
                    <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2">
                      {item.content}
                    </p>
                    <div className="flex items-center gap-2 pt-3 text-[11px] text-slate-500">
                      <UserCircle className="w-3.5 h-3.5" />
                      <span className="font-medium text-slate-700 dark:text-slate-300">{item.authorName}</span>
                      <span>•</span>
                      <span>{new Date(item.createdAt).toLocaleDateString()}</span>
                    </div>
                  </div>

                  <div className="flex flex-col items-center gap-2 select-none">
                    <button
                      onClick={(e) => handleUpvote(item.id, e)}
                      className="p-2 border border-slate-100 dark:border-white/5 hover:border-blue-400 dark:hover:border-blue-500 hover:text-blue-500 hover:bg-blue-50 dark:hover:bg-blue-950/30 rounded-xl transition-all flex flex-col items-center gap-0.5"
                    >
                      <ThumbsUp className="w-3.5 h-3.5" />
                      <span className="text-[10px] font-bold">{item.upvotes || 0}</span>
                    </button>
                    <div className="text-[10px] text-slate-500 font-medium">
                      {(item.comments || []).length} comments
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Selected Thread Comments Drawer (1col) */}
      <div className="lg:col-span-1">
        {selectedThread ? (
          <div className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-white/5 rounded-2xl p-5 shadow-sm space-y-4">
            <h3 className="font-display font-semibold text-slate-900 dark:text-white border-b border-slate-100 dark:border-white/5 pb-2">
              Viewing Forum Topic
            </h3>

            <div className="space-y-1">
              <span className="inline-block text-[10px] font-semibold uppercase tracking-wider font-mono px-2 py-0.5 bg-blue-100 text-blue-700 rounded-full">
                {selectedThread.category}
              </span>
              <h4 className="font-bold text-slate-800 dark:text-slate-100 text-sm">
                {selectedThread.title}
              </h4>
              <p className="text-xs text-slate-600 dark:text-slate-400 whitespace-pre-wrap pt-2">
                {selectedThread.content}
              </p>
              <div className="flex items-center gap-1.5 pt-3 text-[10px] text-slate-500">
                <span className="font-medium text-slate-700 dark:text-slate-300">{selectedThread.authorName}</span>
                <span>•</span>
                <span>{new Date(selectedThread.createdAt).toLocaleString()}</span>
              </div>
            </div>

            {/* Replies section */}
            <div className="border-t border-slate-100 dark:border-white/5 pt-4 space-y-3">
              <h5 className="text-xs uppercase tracking-wider font-mono text-slate-500 font-semibold mb-2">
                Peer Responses ({(selectedThread.comments || []).length})
              </h5>

              <div className="space-y-2.5 max-h-48 overflow-y-auto pr-1">
                {(selectedThread.comments || []).map((comm) => (
                  <div key={comm.id} className="bg-slate-50 dark:bg-slate-900/50 p-2.5 rounded-xl border border-slate-100 dark:border-white/5">
                    <p className="text-xs text-slate-800 dark:text-slate-200">{comm.content}</p>
                    <div className="flex items-center gap-1.5 mt-2 text-[9px] text-slate-500">
                      <span className="font-semibold text-slate-700 dark:text-slate-300">{comm.authorName}</span>
                      <span>•</span>
                      <span>{new Date(comm.createdAt).toLocaleDateString()}</span>
                    </div>
                  </div>
                ))}
                {(selectedThread.comments || []).length === 0 && (
                  <p className="text-xs text-slate-400 italic text-center py-4">No responses yet. Share your guidance!</p>
                )}
              </div>

              {/* Add comment Form */}
              <form onSubmit={handleAddComment} className="flex gap-2 pt-2 border-t border-slate-100 dark:border-white/5">
                <input
                  type="text"
                  required
                  placeholder="Write a peer response..."
                  className="flex-1 px-3 py-1.5 text-xs rounded-lg border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-1 focus:ring-blue-500 focus:outline-none"
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                />
                <button
                  type="submit"
                  className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold flex items-center justify-center cursor-pointer shadow-sm"
                >
                  <Send className="w-3 h-3" />
                </button>
              </form>
            </div>
          </div>
        ) : (
          <div className="bg-slate-50 dark:bg-slate-900/30 border border-dashed border-slate-200 dark:border-white/5 rounded-2xl p-6 text-center text-slate-500 flex flex-col justify-center items-center h-48">
            <MessageSquare className="w-10 h-10 mb-2 text-slate-400" />
            <h4 className="font-semibold text-xs text-slate-700 dark:text-slate-300">Select standard Thread</h4>
            <span className="text-[10px] mt-1">Tap indices to expand total comment strings.</span>
          </div>
        )}
      </div>
    </div>
  );
}

// -----------------------------------------------------------------
// SUCCESS STORIES COMPONENT
// -----------------------------------------------------------------
function SuccessStories() {
  const stories = [
    {
      name: "Shruti Sharma",
      college: "BITS Pilani, CSE-2025",
      placements: "Google Software Engineer Placement",
      story: "TechHelp study materials and PYQ papers were instrumental! I downloaded the complete DSA previous year questions MIT collections, which lined up fully with my actual Google interviews. Truly a lifesaver resource center!",
      photo: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=120&h=120&q=80",
      stipend: "Package: ₹42 Lakhs / Year"
    },
    {
      name: "Saurav Iyer",
      college: "VTU Karnataka, IT-2026",
      placements: "Microsoft PM Internship",
      story: "The AI Career Roadmap Generator mapped out exactly what product designs I must structure and build inside 3 months. Combined with active portfolio templates, I secured the Microsoft PM Internship shortlist effortlessly!",
      photo: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=120&h=120&q=80",
      stipend: "Stipend: ₹1,20,000 / Month"
    },
    {
      name: "Anjali Prasad",
      college: "DY Patil Pune, ECE-2025",
      placements: "Associate Frontend Developer at Stripe",
      story: "Using both the Harvard ATS Resume Builder tool and the Attendance Tracker daily of this amazing platform kept myself completely clear and prepared for Stripe interview sessions. Massive thanks to TechHelp Creators!",
      photo: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=120&h=120&q=80",
      stipend: "Package: $115,000 / Year"
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {stories.map((s, i) => (
        <div key={i} className="bg-white dark:bg-slate-950 p-6 rounded-2xl border border-slate-150 dark:border-white/5 shadow-sm space-y-4 hover:shadow-md transition-shadow relative overflow-hidden">
          <div className="absolute top-0 right-0 py-1 px-4 text-[10px] font-bold text-amber-600 bg-amber-50 dark:bg-amber-950/30 rounded-bl-xl font-mono">
            Placed Successfully!
          </div>

          <div className="flex gap-4 items-center">
            <img src={s.photo} alt={s.name} className="w-12 h-12 rounded-full object-cover ring-2 ring-blue-500/10" referrerPolicy="no-referrer" />
            <div>
              <h4 className="font-bold text-slate-800 dark:text-slate-100 text-sm leading-tight">{s.name}</h4>
              <span className="text-xs text-slate-500 leading-tight block">{s.college}</span>
            </div>
          </div>

          <div className="bg-blue-50/50 dark:bg-blue-950/20 p-2.5 rounded-lg border border-blue-100/50 dark:border-white/5">
            <span className="text-[11px] font-bold text-blue-600 dark:text-blue-400 block">{s.placements}</span>
            <span className="text-[10px] text-slate-500 font-semibold uppercase tracking-wider font-mono block mt-0.5">{s.stipend}</span>
          </div>

          <p className="text-xs text-slate-600 dark:text-slate-400 italic">
            "{s.story}"
          </p>
        </div>
      ))}
    </div>
  );
}

// Simple loader helper
function LoaderComponent() {
  return (
    <div className="flex flex-col justify-center items-center gap-1.5 py-6">
      <div className="w-6 h-6 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin" />
      <span className="text-xs text-slate-500">Retrieving Community Lounge data...</span>
    </div>
  );
}
