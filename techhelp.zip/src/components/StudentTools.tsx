import React, { useState } from "react";
import { Calculator, Percent, Sparkles, Trophy, Plus, Trash2, CheckCircle2 } from "lucide-react";
import { motion } from "motion/react";

export default function StudentTools() {
  const [activeTab, setActiveTab] = useState<'cgpa' | 'percent' | 'attendance' | 'coding'>('cgpa');

  return (
    <div className="rounded-2xl glass p-6 md:p-8 shadow-xl border border-white/20 dark:border-white/5 transition-all">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <h2 className="text-3xl font-display font-medium text-slate-900 dark:text-white">
            Smart Student Tools
          </h2>
          <p className="text-slate-600 dark:text-slate-400 mt-1">
            Calculate your academic performance and manage your educational progress.
          </p>
        </div>
        
        {/* Tab Switchers */}
        <div className="flex flex-wrap gap-2 bg-slate-100 dark:bg-slate-900/50 p-1 rounded-xl w-full md:w-auto">
          <button
            onClick={() => setActiveTab('cgpa')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium text-sm transition-all flex-1 md:flex-none ${
              activeTab === 'cgpa'
                ? 'bg-white dark:bg-slate-800 text-blue-600 dark:text-blue-400 shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Calculator className="w-4 h-4" /> CGPA
          </button>
          <button
            onClick={() => setActiveTab('percent')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium text-sm transition-all flex-1 md:flex-none ${
              activeTab === 'percent'
                ? 'bg-white dark:bg-slate-800 text-blue-600 dark:text-blue-400 shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Percent className="w-4 h-4" /> Percentage
          </button>
          <button
            onClick={() => setActiveTab('attendance')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium text-sm transition-all flex-1 md:flex-none ${
              activeTab === 'attendance'
                ? 'bg-white dark:bg-slate-800 text-blue-600 dark:text-blue-400 shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Sparkles className="w-4 h-4" /> Attendance (75%)
          </button>
          <button
            onClick={() => setActiveTab('coding')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium text-sm transition-all flex-1 md:flex-none ${
              activeTab === 'coding'
                ? 'bg-white dark:bg-slate-800 text-blue-600 dark:text-blue-400 shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Trophy className="w-4 h-4" /> Coding Tracker
          </button>
        </div>
      </div>

      {/* Render Active Tool */}
      <motion.div
        key={activeTab}
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.2 }}
      >
        {activeTab === 'cgpa' && <CgpaCalculator />}
        {activeTab === 'percent' && <PercentageCalculatorTool />}
        {activeTab === 'attendance' && <AttendanceCalculatorTool />}
        {activeTab === 'coding' && <CodingPracticeTrackerTool />}
      </motion.div>
    </div>
  );
}

// -----------------------------------------------------------------
// SUB-COMPONENT: CGPA CALCULATOR
// -----------------------------------------------------------------
function CgpaCalculator() {
  const [semesters, setSemesters] = useState<{ id: number; sgpa: string; credits: string }[]>([
    { id: 1, sgpa: "8.5", credits: "22" },
    { id: 2, sgpa: "8.8", credits: "22" },
  ]);

  const addSemester = () => {
    const nextId = semesters.length ? Math.max(...semesters.map(s => s.id)) + 1 : 1;
    setSemesters([...semesters, { id: nextId, sgpa: "", credits: "" }]);
  };

  const removeSemester = (id: number) => {
    setSemesters(semesters.filter(s => s.id !== id));
  };

  const updateSemester = (id: number, field: 'sgpa' | 'credits', value: string) => {
    setSemesters(semesters.map(s => s.id === id ? { ...s, [field]: value } : s));
  };

  const calculateCGPA = () => {
    let totalGradePoints = 0;
    let totalCredits = 0;

    semesters.forEach(s => {
      const sgpa = parseFloat(s.sgpa);
      const credits = parseFloat(s.credits);
      if (!isNaN(sgpa) && !isNaN(credits)) {
        totalGradePoints += sgpa * credits;
        totalCredits += credits;
      }
    });

    return totalCredits > 0 ? (totalGradePoints / totalCredits).toFixed(2) : "0.00";
  };

  const finalCgpa = parseFloat(calculateCGPA());

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      <div className="lg:col-span-2 space-y-4">
        <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-200">Semesters List</h3>
        <div className="space-y-3 max-h-64 overflow-y-auto pr-2">
          {semesters.map((sem, index) => (
            <div key={sem.id} className="flex gap-4 items-center bg-slate-50 dark:bg-slate-900/40 p-3 rounded-xl border border-slate-100 dark:border-white/5">
              <span className="text-sm font-medium text-slate-500 w-16">Sem {index + 1}</span>
              <div className="flex-1 grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs text-slate-500 mb-1">SGPA (0-10)</label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    max="10"
                    placeholder="E.g., 8.5"
                    value={sem.sgpa}
                    onChange={(e) => updateSemester(sem.id, 'sgpa', e.target.value)}
                    className="w-full px-3 py-1.5 rounded-lg border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs text-slate-500 mb-1">Credits</label>
                  <input
                    type="number"
                    placeholder="E.g., 22"
                    value={sem.credits}
                    onChange={(e) => updateSemester(sem.id, 'credits', e.target.value)}
                    className="w-full px-3 py-1.5 rounded-lg border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>
              </div>
              <button
                onClick={() => removeSemester(sem.id)}
                className="p-2 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/30 rounded-lg mt-5"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
        <button
          onClick={addSemester}
          className="flex items-center gap-2 px-4 py-2 border border-dashed border-blue-200 dark:border-slate-700 hover:border-blue-500 hover:text-blue-600 dark:hover:text-blue-400 rounded-xl text-sm font-medium text-slate-600 dark:text-slate-400 w-full justify-center transition-all"
        >
          <Plus className="w-4 h-4" /> Add Semester
        </button>
      </div>

      <div className="bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-950/30 dark:to-indigo-950/30 p-6 rounded-2xl border border-blue-100/50 dark:border-white/5 flex flex-col justify-between">
        <div>
          <h3 className="text-xl font-display font-medium text-slate-800 dark:text-slate-200">
            Performance Summary
          </h3>
          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
            Calculated as a weighted average of your semester SGPA and credits.
          </p>
        </div>

        <div className="my-8 text-center">
          <span className="block text-xs text-slate-500 font-mono tracking-wider uppercase mb-1">
            Cumulative CGPA
          </span>
          <span className="text-6xl font-display font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-600 dark:from-blue-400 dark:to-indigo-400">
            {finalCgpa}
          </span>
          <span className="block text-sm text-slate-500 mt-2">
            {finalCgpa >= 9 ? "🌟 Exceptional! Outstanding Performance" : finalCgpa >= 8 ? "🚀 Great job! Keep it up" : finalCgpa >= 7 ? "👍 Decent. Aim higher!" : "✍️ Keep studying hard!"}
          </span>
        </div>

        <div className="bg-white/80 dark:bg-slate-900/40 p-4 rounded-xl text-center border border-white dark:border-white/5">
          <span className="text-xs text-slate-500 block">Approx. Percentage conversion</span>
          <span className="text-lg font-semibold text-slate-800 dark:text-slate-100 block">
            {(finalCgpa * 9.5).toFixed(1)}% <span className="text-xs text-slate-500 font-normal">(CGPA × 9.5)</span>
          </span>
        </div>
      </div>
    </div>
  );
}

// -----------------------------------------------------------------
// SUB-COMPONENT: PERCENTAGE CALCULATOR
// -----------------------------------------------------------------
function PercentageCalculatorTool() {
  const [mode, setMode] = useState<'marks' | 'cgpa'>('marks');
  const [marksObtained, setMarksObtained] = useState("412");
  const [maxMarks, setMaxMarks] = useState("500");
  const [inputCgpa, setInputCgpa] = useState("8.5");

  const percentageFromMarks = maxMarks && parseFloat(maxMarks) > 0 
    ? ((parseFloat(marksObtained) / parseFloat(maxMarks)) * 100).toFixed(2) 
    : "0.00";

  const percentageFromCgpa = (parseFloat(inputCgpa) * 9.5).toFixed(2);

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
      <div className="space-y-6">
        <div className="flex gap-4 p-1 bg-slate-100 dark:bg-slate-900/50 rounded-xl">
          <button
            onClick={() => setMode('marks')}
            className={`flex-1 py-2 rounded-lg font-medium text-sm transition-all ${
              mode === 'marks' ? 'bg-white dark:bg-slate-800 text-blue-600 shadow-sm' : 'text-slate-600'
            }`}
          >
            From Total Marks
          </button>
          <button
            onClick={() => setMode('cgpa')}
            className={`flex-1 py-2 rounded-lg font-medium text-sm transition-all ${
              mode === 'cgpa' ? 'bg-white dark:bg-slate-800 text-blue-600 shadow-sm' : 'text-slate-600'
            }`}
          >
            From CGPA (9.5 Scale)
          </button>
        </div>

        {mode === 'marks' ? (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
                Marks Obtained
              </label>
              <input
                type="number"
                value={marksObtained}
                onChange={(e) => setMarksObtained(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                placeholder="E.g., 412"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
                Maximum Total Marks
              </label>
              <input
                type="number"
                value={maxMarks}
                onChange={(e) => setMaxMarks(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                placeholder="E.g., 500"
              />
            </div>
          </div>
        ) : (
          <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
              Your CGPA (0 to 10)
            </label>
            <input
              type="number"
              step="0.01"
              value={inputCgpa}
              onChange={(e) => setInputCgpa(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
              placeholder="E.g., 8.5"
            />
          </div>
        )}
      </div>

      <div className="flex flex-col justify-center items-center bg-gradient-to-br from-indigo-50 to-purple-50 dark:from-indigo-950/20 dark:to-purple-950/20 p-8 rounded-2xl border border-indigo-150/40 dark:border-white/5">
        <span className="text-xs uppercase font-mono tracking-wider text-slate-500 mb-2">
          Calculated Percentage
        </span>
        <span className="text-6xl font-display font-bold text-indigo-600 dark:text-indigo-400">
          {mode === 'marks' ? percentageFromMarks : percentageFromCgpa}%
        </span>
        <span className="text-sm text-slate-500 mt-4 text-center">
          {mode === 'marks' 
            ? `You scored ${marksObtained} out of ${maxMarks} marks.`
            : `CGPA of ${inputCgpa} multiplied by conversion factor of 9.5`}
        </span>
      </div>
    </div>
  );
}

// -----------------------------------------------------------------
// SUB-COMPONENT: ATTENDANCE CALCULATOR
// -----------------------------------------------------------------
function AttendanceCalculatorTool() {
  const [attended, setAttended] = useState("32");
  const [total, setTotal] = useState("40");
  const [requiredPercent, setRequiredPercent] = useState(75);

  const att = parseFloat(attended);
  const tot = parseFloat(total);

  const currentPercent = tot > 0 ? (att / tot) * 100 : 0;

  // Calculate recommendation
  let statusText = "";
  let suggestion = "";

  if (!isNaN(att) && !isNaN(tot) && tot > 0) {
    if (currentPercent >= requiredPercent) {
      // User has enough. How many classes can they afford to skip?
      let tempTotal = tot;
      let tempAttended = att;
      let skipCount = 0;
      
      while (tempTotal > 0) {
        const nextTotal = tempTotal + 1;
        if ((tempAttended / nextTotal) * 100 >= requiredPercent) {
          skipCount++;
          tempTotal = nextTotal;
        } else {
          break;
        }
      }
      statusText = `🎉 Safe! Your current attendance is ${currentPercent.toFixed(1)}%.`;
      suggestion = skipCount > 0 
        ? `You can safely skip the next ${skipCount} classes and still maintain above ${requiredPercent}% attendance.`
        : `Your attendance is right on the boundary. Do not miss any upcoming classes!`;
    } else {
      // User is short. How many consecutive classes must they attend?
      let tempTotal = tot;
      let tempAttended = att;
      let attendCount = 0;
      
      while ((tempAttended / tempTotal) * 100 < requiredPercent && attendCount < 100) {
        tempAttended += 1;
        tempTotal += 1;
        attendCount++;
      }
      statusText = `⚠️ Detained Alert! Your attendance is ${currentPercent.toFixed(1)}%.`;
      suggestion = `You need to attend the next ${attendCount} classes consecutively to cross the ${requiredPercent}% requirement.`;
    }
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
            Required Attendance Percentage
          </label>
          <div className="flex gap-4">
            {[75, 80, 85].map(p => (
              <button
                key={p}
                onClick={() => setRequiredPercent(p)}
                className={`flex-1 py-1 px-3 rounded-lg font-semibold text-sm transition-all border ${
                  requiredPercent === p
                    ? 'bg-blue-500 text-white border-blue-500 shadow-sm'
                    : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-400 border-slate-200 dark:border-white/10'
                }`}
              >
                {p}% Goal
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
              Classes Attended
            </label>
            <input
              type="number"
              value={attended}
              onChange={(e) => setAttended(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
              placeholder="32"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
              Total Classes Conducted
            </label>
            <input
              type="number"
              value={total}
              onChange={(e) => setTotal(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
              placeholder="40"
            />
          </div>
        </div>
      </div>

      <div className="flex flex-col justify-between bg-white dark:bg-slate-900/50 p-6 rounded-2xl border border-slate-150 dark:border-white/5 shadow-inner">
        <div className="text-center md:text-left">
          <span className="text-xs uppercase font-mono text-slate-500 block">Current Attendance</span>
          <span className={`text-5xl font-display font-medium mt-1 inline-block ${
            currentPercent >= requiredPercent ? 'text-emerald-500' : 'text-rose-500'
          }`}>
            {currentPercent.toFixed(1)}%
          </span>
        </div>

        <div className="bg-slate-50 dark:bg-slate-800/50 p-4 rounded-xl border border-slate-100 dark:border-white/5 my-4">
          <h4 className="text-sm font-semibold text-slate-800 dark:text-slate-200">{statusText}</h4>
          <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">{suggestion}</p>
        </div>

        <div className="text-xs text-slate-400 font-serif">
          * Calculated assuming attendance logs are perfect. Do not miss key lab examinations or internals!
        </div>
      </div>
    </div>
  );
}

// -----------------------------------------------------------------
// SUB-COMPONENT: CODING TRACKER
// -----------------------------------------------------------------
interface CodingLog {
  site: string;
  count: number;
  goal: number;
}

function CodingPracticeTrackerTool() {
  const [logs, setLogs] = useState<CodingLog[]>([
    { site: 'LeetCode', count: 145, goal: 200 },
    { site: 'GeeksForGeeks', count: 82, goal: 150 },
    { site: 'Codeforces', count: 12, goal: 30 },
  ]);

  const [newSite, setNewSite] = useState('');
  const [newCount, setNewCount] = useState('');
  const [newGoal, setNewGoal] = useState('');

  const addLog = () => {
    if (!newSite) return;
    const countVal = parseInt(newCount) || 0;
    const goalVal = parseInt(newGoal) || 50;
    setLogs([...logs, { site: newSite, count: countVal, goal: goalVal }]);
    setNewSite('');
    setNewCount('');
    setNewGoal('');
  };

  const incrementCount = (index: number) => {
    setLogs(logs.map((l, i) => i === index ? { ...l, count: l.count + 1 } : l));
  };

  const removeLog = (index: number) => {
    setLogs(logs.filter((_, i) => i !== index));
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      {/* Logs tracking list */}
      <div className="lg:col-span-2 space-y-4">
        <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-200">Logged Platforms</h3>
        <div className="space-y-3">
          {logs.map((item, index) => {
            const percent = Math.min((item.count / item.goal) * 100, 100);
            return (
              <div key={index} className="bg-white dark:bg-slate-900 border border-slate-150 dark:border-white/5 p-4 rounded-xl shadow-sm space-y-2">
                <div className="flex justify-between items-center">
                  <div>
                    <h4 className="font-semibold text-slate-800 dark:text-slate-200">{item.site}</h4>
                    <span className="text-xs text-slate-500">
                      Problems: {item.count} / {item.goal}
                    </span>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => incrementCount(index)}
                      className="px-3 py-1 bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400 hover:bg-blue-100 rounded-lg text-sm font-medium transition-all"
                    >
                      +1 Solved
                    </button>
                    <button
                      onClick={() => removeLog(index)}
                      className="p-1 px-2 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/45 rounded-lg"
                    >
                      Delete
                    </button>
                  </div>
                </div>

                {/* Progress bar */}
                <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div 
                    className="bg-blue-500 h-full rounded-full transition-all duration-300" 
                    style={{ width: `${percent}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Add Platform */}
      <div className="bg-slate-50 dark:bg-slate-900/40 p-5 rounded-2xl border border-slate-150 dark:border-white/5">
        <h3 className="font-semibold text-slate-800 dark:text-slate-100 mb-4 flex items-center gap-2">
          <Trophy className="w-4 h-4 text-amber-500" /> Start Tracking Platform
        </h3>
        <div className="space-y-3">
          <div>
            <label className="block text-xs text-slate-500 mb-1">Platform Name</label>
            <input
              type="text"
              placeholder="E.g., HackerRank"
              value={newSite}
              onChange={(e) => setNewSite(e.target.value)}
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-250 dark:border-white/10 bg-white dark:bg-slate-850 text-slate-900 dark:text-white"
            />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-xs text-slate-500 mb-1">Solved Already</label>
              <input
                type="number"
                placeholder="0"
                value={newCount}
                onChange={(e) => setNewCount(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-250 dark:border-white/10 bg-white dark:bg-slate-850 text-slate-900 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-xs text-slate-500 mb-1">Your Target Goal</label>
              <input
                type="number"
                placeholder="100"
                value={newGoal}
                onChange={(e) => setNewGoal(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-250 dark:border-white/10 bg-white dark:bg-slate-850 text-slate-900 dark:text-white"
              />
            </div>
          </div>
          <button
            onClick={addLog}
            className="w-full py-2 bg-gradient-to-r from-blue-600 to-indigo-600 dark:from-blue-500 dark:to-indigo-500 text-white rounded-lg text-sm font-semibold hover:shadow-lg transition-all mt-2"
          >
            Add Platform
          </button>
        </div>
      </div>
    </div>
  );
}
