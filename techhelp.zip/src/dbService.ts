import { 
  db, 
  handleFirestoreError, 
  OperationType 
} from "./firebase";
import { 
  collection, 
  getDocs, 
  getDoc,
  setDoc,
  addDoc, 
  updateDoc, 
  deleteDoc, 
  doc, 
  query, 
  where, 
  orderBy,
  increment
} from "firebase/firestore";
import { 
  Internship, 
  Job, 
  UserProfile, 
  StudyMaterial, 
  Blog, 
  Discussion, 
  Comment,
  Hackathon
} from "./types";

import { 
  ALL_DEFAULT_MATERIALS, 
  ALL_DEFAULT_JOBS, 
  ALL_DEFAULT_INTERNSHIPS 
} from "./data/portalData";

// Standard Collections Paths
const INTERNSHIPS_PATH = "internships";
const JOBS_PATH = "jobs";
const STUDY_MATERIALS_PATH = "studyMaterials";
const BLOGS_PATH = "blogs";
const DISCUSSIONS_PATH = "discussions";
const USER_PROFILES_PATH = "userProfiles";

// Standard Error Helper Wrapper
async function safeDbCall<T>(op: () => Promise<T>, type: OperationType, path: string): Promise<T> {
  try {
    return await op();
  } catch (error) {
    handleFirestoreError(error, type, path);
    throw error;
  }
}

// -----------------------------------------------------------------
// 1. INTERNSHIPS
// -----------------------------------------------------------------
export async function getInternships(): Promise<Internship[]> {
  return safeDbCall(async () => {
    const snap = await getDocs(collection(db, INTERNSHIPS_PATH));
    const items: Internship[] = [];
    snap.forEach((doc) => {
      items.push({ id: doc.id, ...doc.data() } as Internship);
    });

    // Merge defaults not already in Firestore
    const existingKeys = new Set(items.map(i => `${i.companyName}-${i.title}`.toLowerCase()));
    const defaults = ALL_DEFAULT_INTERNSHIPS
      .filter(i => !existingKeys.has(`${i.companyName}-${i.title}`.toLowerCase()))
      .map((item, idx) => ({ id: `def-intern-${idx}`, ...item } as Internship));

    return [...items, ...defaults];
  }, OperationType.GET, INTERNSHIPS_PATH);
}

export async function addInternship(item: Omit<Internship, "id">): Promise<string> {
  return safeDbCall(async () => {
    const docRef = await addDoc(collection(db, INTERNSHIPS_PATH), item);
    return docRef.id;
  }, OperationType.CREATE, INTERNSHIPS_PATH);
}

export async function deleteInternship(id: string): Promise<void> {
  return safeDbCall(async () => {
    await deleteDoc(doc(db, INTERNSHIPS_PATH, id));
  }, OperationType.DELETE, `${INTERNSHIPS_PATH}/${id}`);
}

// -----------------------------------------------------------------
// 2. JOBS
// -----------------------------------------------------------------
export async function getJobs(): Promise<Job[]> {
  return safeDbCall(async () => {
    const snap = await getDocs(collection(db, JOBS_PATH));
    const items: Job[] = [];
    snap.forEach((doc) => {
      items.push({ id: doc.id, ...doc.data() } as Job);
    });

    // Merge defaults not already in Firestore
    const existingKeys = new Set(items.map(j => `${j.companyName}-${j.role}`.toLowerCase()));
    const defaults = ALL_DEFAULT_JOBS
      .filter(j => !existingKeys.has(`${j.companyName}-${j.role}`.toLowerCase()))
      .map((item, idx) => ({ id: `def-job-${idx}`, ...item } as Job));

    return [...items, ...defaults];
  }, OperationType.GET, JOBS_PATH);
}

export async function addJob(item: Omit<Job, "id">): Promise<string> {
  return safeDbCall(async () => {
    const docRef = await addDoc(collection(db, JOBS_PATH), item);
    return docRef.id;
  }, OperationType.CREATE, JOBS_PATH);
}

export async function deleteJob(id: string): Promise<void> {
  return safeDbCall(async () => {
    await deleteDoc(doc(db, JOBS_PATH, id));
  }, OperationType.DELETE, `${JOBS_PATH}/${id}`);
}

// -----------------------------------------------------------------
// 3. STUDY MATERIALS
// -----------------------------------------------------------------
export async function getStudyMaterials(): Promise<StudyMaterial[]> {
  return safeDbCall(async () => {
    const snap = await getDocs(collection(db, STUDY_MATERIALS_PATH));
    const items: StudyMaterial[] = [];
    snap.forEach((doc) => {
      items.push({ id: doc.id, ...doc.data() } as StudyMaterial);
    });

    // Merge comprehensive defaults (BCA, B.Tech, MCA, MBA, B.Pharm)
    const existingTitles = new Set(items.map(m => m.title.trim().toLowerCase()));
    const defaults = ALL_DEFAULT_MATERIALS
      .filter(m => !existingTitles.has(m.title.trim().toLowerCase()))
      .map((item, idx) => ({ id: `def-mat-${idx}`, ...item } as StudyMaterial));

    return [...items, ...defaults];
  }, OperationType.GET, STUDY_MATERIALS_PATH);
}

export async function addStudyMaterial(item: Omit<StudyMaterial, "id">): Promise<string> {
  return safeDbCall(async () => {
    const docRef = await addDoc(collection(db, STUDY_MATERIALS_PATH), item);
    return docRef.id;
  }, OperationType.CREATE, STUDY_MATERIALS_PATH);
}

export async function incrementDownloadCounter(id: string): Promise<void> {
  return safeDbCall(async () => {
    if (id.startsWith("def-")) return; // skip for in-memory defaults
    const docRef = doc(db, STUDY_MATERIALS_PATH, id);
    await updateDoc(docRef, { downloadsCount: increment(1) });
  }, OperationType.UPDATE, `${STUDY_MATERIALS_PATH}/${id}`);
}

// -----------------------------------------------------------------
// 4. BLOGS
// -----------------------------------------------------------------
export async function getBlogs(): Promise<Blog[]> {
  return safeDbCall(async () => {
    const snap = await getDocs(collection(db, BLOGS_PATH));
    const items: Blog[] = [];
    snap.forEach((doc) => {
      items.push({ id: doc.id, ...doc.data() } as Blog);
    });
    return items;
  }, OperationType.GET, BLOGS_PATH);
}

export async function addBlog(item: Omit<Blog, "id">): Promise<string> {
  return safeDbCall(async () => {
    const docRef = await addDoc(collection(db, BLOGS_PATH), item);
    return docRef.id;
  }, OperationType.CREATE, BLOGS_PATH);
}

// -----------------------------------------------------------------
// 5. DISCUSSIONS & COMMUNITY FORUMS
// -----------------------------------------------------------------
export async function getDiscussions(): Promise<Discussion[]> {
  return safeDbCall(async () => {
    const snap = await getDocs(collection(db, DISCUSSIONS_PATH));
    const items: Discussion[] = [];
    snap.forEach((doc) => {
      items.push({ id: doc.id, ...doc.data() } as Discussion);
    });
    // Sort client-side by newest by default
    return items.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }, OperationType.GET, DISCUSSIONS_PATH);
}

export async function addDiscussion(item: Omit<Discussion, "id" | "comments" | "upvotes">): Promise<string> {
  return safeDbCall(async () => {
    const thread = {
      ...item,
      upvotes: 0,
      comments: []
    };
    const docRef = await addDoc(collection(db, DISCUSSIONS_PATH), thread);
    return docRef.id;
  }, OperationType.CREATE, DISCUSSIONS_PATH);
}

export async function upvoteDiscussion(id: string): Promise<void> {
  return safeDbCall(async () => {
    const docRef = doc(db, DISCUSSIONS_PATH, id);
    await updateDoc(docRef, { upvotes: increment(1) });
  }, OperationType.UPDATE, `${DISCUSSIONS_PATH}/${id}/upvote`);
}

export async function addCommentToDiscussion(discussionId: string, comment: Comment): Promise<void> {
  return safeDbCall(async () => {
    const docRef = doc(db, DISCUSSIONS_PATH, discussionId);
    const snap = await getDoc(docRef);
    if (snap.exists()) {
      const data = snap.data() as Discussion;
      const currentComments = data.comments || [];
      await updateDoc(docRef, {
        comments: [...currentComments, comment]
      });
    }
  }, OperationType.UPDATE, `${DISCUSSIONS_PATH}/${discussionId}/comment`);
}

// -----------------------------------------------------------------
// 6. USER PROFILES & BOOKMARKS/APPLICATIONS
// -----------------------------------------------------------------
export async function fetchUserProfile(uid: string): Promise<UserProfile | null> {
  return safeDbCall(async () => {
    const docRef = doc(db, USER_PROFILES_PATH, uid);
    const snap = await getDoc(docRef);
    if (snap.exists()) {
      return snap.data() as UserProfile;
    }
    return null;
  }, OperationType.GET, `${USER_PROFILES_PATH}/${uid}`);
}

export async function saveUserProfile(profile: UserProfile): Promise<void> {
  return safeDbCall(async () => {
    const docRef = doc(db, USER_PROFILES_PATH, profile.uid);
    await setDoc(docRef, profile, { merge: true });
  }, OperationType.WRITE, `${USER_PROFILES_PATH}/${profile.uid}`);
}

// -----------------------------------------------------------------
// SEEPING INITIAL MOCK DATA IF DISCOVERED BLANK
// -----------------------------------------------------------------
export async function initializeMockDataIfNeeded() {
  try {
    const internshipsSnap = await getDocs(collection(db, INTERNSHIPS_PATH));
    if (internshipsSnap.empty) {
      console.log("[TechHelp] Database is empty. Seeding gorgeous mock items...");

      // 1. Seed Internships
      for (const item of ALL_DEFAULT_INTERNSHIPS) {
        await addDoc(collection(db, INTERNSHIPS_PATH), item);
      }

      // 2. Seed Jobs
      for (const item of ALL_DEFAULT_JOBS) {
        await addDoc(collection(db, JOBS_PATH), item);
      }

      // 3. Seed Study Materials
      for (const item of ALL_DEFAULT_MATERIALS) {
        await addDoc(collection(db, STUDY_MATERIALS_PATH), item);
      }

      // 4. Seed Blogs
      const dummyBlogs: Omit<Blog, "id">[] = [
        {
          title: "AKTU Notice 2026: Answer Copy में Mobile Number या पहचान संबंधी जानकारी लिखने पर होगा UFM Case, विश्वविद्यालय ने जारी किए सख्त निर्देश",
          summary: "डॉ. ए.पी.जे. अब्दुल कलाम प्राविधिक विश्वविद्यालय (AKTU) लखनऊ ने परीक्षा शुचिता बनाए रखने के लिए एक विशेष कड़ा निर्देश जारी किया है। सभी मूल्यांकन केंद्रों को निर्देश दिए गए हैं कि परीक्षा प्रतियों में मोबाइल नंबर या किसी प्रकार की व्यक्तिगत पहचान की जानकारी पाए जाने पर सीधे UFM (Unfair Means) केस दर्ज करें।",
          content: `डॉ. ए.पी.जे. अब्दुल कलाम प्राविधिक विश्वविद्यालय, उत्तर प्रदेश (AKTU), लखनऊ की ओर से शैक्षिक सत्र 2025-2026 के संबंध में एक अत्यंत महत्वपूर्ण एवं अतिआवश्यक निर्देश पत्र जारी किया गया है।

मुख्य परीक्षा नियंत्रक प्रो. दीपक नगरिया द्वारा जारी किए गए पत्र संख्या ए.के.टी.यू./प.नि.का./2026/2919 के तहत, समस्त राजकीय एवं निजी संबद्ध संस्थानों के निदेशकों/प्राचार्यों तथा मूल्यांकन समन्वयकों को डिजिटल मूल्यांकन प्रणाली के दौरान बरतने योग्य सावधानियां प्रेषित की गई हैं।

### कड़े निर्देश की मुख्य बातें:

1. **UFM (Unfair Means) केस का पंजीकरण:** यदि कोई छात्र/छात्रा अपनी उत्तर पुस्तिका (Answer Copy) में परीक्षा के दौरान अपना मोबाइल नंबर, अनुक्रमांक (Roll Number) के अतिरिक्त कोई पहचान, ईमेल आईडी, धार्मिक चिह्न या भावुक संदेश लिखता है, तो उसे निष्पक्ष परीक्षा प्रणाली का गंभीर उल्लंघन मानते हुए सीधे **UFM श्रेणी** में वर्गीकृत कर दिया जाएगा।

2. **शिक्षकों को सख़्त निर्देश:** डिजिटल मूल्यांकन में संलग्न सभी निरीक्षकों और परीक्षकों को निर्देश दिए गए हैं कि वे ऐसे वाक्यों या दूरभाष अंकों को तुरंत फ्लैग करें और मूल्यांकन समन्वयक को रिपोर्ट करें।

3. **कठोर अनुशासनात्मक कार्रवाई:** UFM केस लगने पर संबंधित विषय की परीक्षा निरस्त हो सकती है, अथवा पूरे सेमेस्टर की परीक्षाओं का परिणाम शून्य किया जा सकता है।

### छात्रों के लिए आवश्यक सुझाव:
* उत्तर पुस्तिका में केवल उत्तर लिखें, किसी भी प्रकार की रिश्वत (रुपए), "पास कर दीजिए" जैसी विनती या धमकी लिखने की भूल न करें।
* अपना मोबाइल नंबर कतई न लिखें; परीक्षा केंद्र से आपका पूरा पंजीकरण ट्रैक किया जा सकता है।
* विश्वविद्यालय द्वारा जारी किए गए नियमों का पूरी तरह अनुपालन करें। "Study Smart. Grow Fast." - परीक्षा के लिए शुभकामनाएं!`,
          imageUrl: "https://images.unsplash.com/photo-1434030216411-0b793f4b4173?auto=format&fit=crop&w=800&h=500&q=80",
          author: "Abhishek Maurya",
          createdAt: "2026-06-02T15:00:00Z",
          category: "notice",
          officialsLetterNo: "ए.के.टी.यू./प.नि.का./2026/2919"
        },
        {
          title: "How to Land a Big Tech Internship in 2026",
          summary: "An intensive strategy guide covering resume framing, DSA selection patterns, referral outreach, and mock interviews.",
          content: `Getting an internship at a major technological corporation requires an organized, focused preparation structure. Here is how to achieve it: \n\n### 1. Resume Preparation\nAn executive-styled Harvard template is highly favored because of its scannability. Keep layout consistent. Include quantified results.\n\n### 2. Solved Coding Patterns\nFocus on templates like Graph BFS/DFS, Binary Search, Sliding Window, and Dynamic Programming. \n\n### 3. Systematic Mock Testing\nDo at least two peer mocks every single week. Use our AI tools!`,
          imageUrl: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=400&h=250&q=80",
          author: "Anjali Mehta (Ex-Google PM)",
          createdAt: new Date().toISOString(),
          category: "blog"
        },
        {
          title: "The Ultimate Guide to Modern System Architecture",
          summary: "Learn dynamic server setups, reverse routing caching mechanisms, and load balancer clusters that scale automatically.",
          content: `System scale is key to massive user applications. Microservices handle separated subdomains effortlessly. \n\n### Primary Layers:\n- Reverse Proxy (Nginx / Cloudflare)\n- Backend API Layer (Node.js, Go or Python)\n- NoSQL Key-value or Relational storage (Firestore, Spanner)`,
          imageUrl: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=400&h=250&q=80",
          author: "Siddharth Sen (Director of Engg)",
          createdAt: new Date().toISOString(),
          category: "blog"
        }
      ];
      for (const item of dummyBlogs) {
        await addDoc(collection(db, BLOGS_PATH), item);
      }

      // 5. Seed Discussions
      const dummyDiscussions: Omit<Discussion, "id" | "comments" | "upvotes">[] = [
        {
          title: "Which DSA sheet is best for BTech CSE students?",
          content: "Hey community, I am in my third year of BTech CSE. Striver's sheet vs Love Babbar's sheet – which one do you recommend for placement prep?",
          category: "btech",
          authorId: "seeder_user",
          authorName: "Rohit Krishnan",
          createdAt: new Date().toISOString()
        },
        {
          title: "Upcoming Smart India Hackathon discussion space",
          content: "Anyone interested in teaming up for the Smart India Hackathon? I am a master in React frontend and Tailwind and need backend/ML team mates.",
          category: "general",
          authorId: "seeder_user_2",
          authorName: "Preeti Shenoy",
          createdAt: new Date().toISOString()
        }
      ];
      for (const item of dummyDiscussions) {
        await addDoc(collection(db, DISCUSSIONS_PATH), item);
      }
      
      console.log("[TechHelp] Database finished seeding!");
    }
  } catch (error) {
    console.warn("[TechHelp] Skip seeding check due to read limits or permissions:", error);
  }
}
