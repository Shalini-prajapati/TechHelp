export interface Internship {
  id: string;
  companyName: string;
  logoUrl?: string;
  title: string;
  stipend: string;
  location: string;
  duration: string;
  applyUrl: string;
  createdAt: string;
  eligibility?: string;
  category?: string;
}

export interface Job {
  id: string;
  companyName: string;
  logoUrl?: string;
  role: string;
  salary: string;
  location: string;
  applyUrl: string;
  createdAt: string;
  eligibility?: string;
  category?: string;
  expLevel?: string;
}

export interface Hackathon {
  id: string;
  title: string;
  date: string;
  prizePool: string;
  registerUrl: string;
  description: string;
}

export interface Event {
  id: string;
  title: string;
  date: string;
  time?: string;
  location?: string;
  registerUrl: string;
  description: string;
  createdAt: string;
}

export interface StudyMaterial {
  id: string;
  title: string;
  category: "notes" | "pyq" | "syllabus" | "ebook" | "quantum";
  subject: string;
  branch: string;
  downloadUrl: string;
  downloadsCount: number;
  uploadedBy: string;
  createdAt: string;
  semester?: string;
  units?: string;
}

export interface Blog {
  id: string;
  title: string;
  summary: string;
  content: string;
  imageUrl?: string;
  author: string;
  createdAt: string;
  category?: "news" | "blog" | "notice";
  officialsLetterNo?: string;
}

export interface Comment {
  id: string;
  authorId: string;
  authorName: string;
  authorPhoto?: string;
  content: string;
  createdAt: string;
}

export interface Discussion {
  id: string;
  title: string;
  content: string;
  category: 'general' | 'jobs' | 'btech' | 'notes' | 'resources';
  authorId: string;
  authorName: string;
  authorPhoto?: string;
  createdAt: string;
  upvotes: number;
  comments: Comment[];
}

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  photoURL?: string;
  college?: string;
  branch?: string;
  year?: string;
  bio?: string;
  bookmarks: string[]; // List of post or item IDs
  trackedApplications: {
    itemId: string;
    itemType: 'job' | 'internship';
    title: string;
    company: string;
    status: 'applied' | 'interviewing' | 'accepted' | 'rejected';
    appliedAt: string;
  }[];
}
