import React, { useState, useEffect } from "react";
import { 
  BookOpen, 
  Search, 
  Sun, 
  Moon, 
  Menu, 
  X, 
  Briefcase, 
  Award, 
  MapPin, 
  DollarSign, 
  Calendar, 
  ChevronRight, 
  FileText, 
  User, 
  Share2, 
  ExternalLink, 
  Bookmark, 
  MessageCircle, 
  Database,
  Lock,
  Compass,
  Trophy,
  Activity,
  LogOut,
  Send,
  Sparkles,
  ClipboardList,
  Heart,
  Download,
  Newspaper,
  GraduationCap,
  AlertTriangle,
  Building,
  Phone,
  Code,
  Laptop,
  CheckCircle2,
  Filter,
  Layers
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { 
  getInternships, 
  getJobs, 
  getStudyMaterials, 
  getBlogs,
  addInternship,
  deleteInternship,
  addJob,
  deleteJob,
  addStudyMaterial,
  addBlog,
  incrementDownloadCounter,
  fetchUserProfile,
  saveUserProfile,
  initializeMockDataIfNeeded 
} from "./dbService";
import { 
  signInWithGoogle, 
  logoutUser, 
  auth 
} from "./firebase";
import { onAuthStateChanged, User as FirebaseUser } from "firebase/auth";
import { Internship, Job, StudyMaterial, Blog, UserProfile } from "./types";
import { PREP_KITS, OFF_CAMPUS_DRIVES, PrepKit, OffCampusDrive } from "./data/portalData";
import StudentTools from "./components/StudentTools";
import AiTools from "./components/AiTools";
import StudentCommunity from "./components/StudentCommunity";
import AdminPanel from "./components/AdminPanel";
import { formatDate } from "./utils";

export default function App() {
  // Theme state
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    const saved = localStorage.getItem("techhelp_theme");
    // Default to false for premium clean white background, dark black text and blue highlights
    return saved === "dark";
  });

  // User and Profile tracking
  const [currUser, setCurrUser] = useState<FirebaseUser | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [profileLoading, setProfileLoading] = useState(false);

  // General Database lists
  const [internships, setInternships] = useState<Internship[]>([]);
  const [jobs, setJobs] = useState<Job[]>([]);
  const [notes, setNotes] = useState<StudyMaterial[]>([]);
  const [blogs, setBlogs] = useState<Blog[]>([]);
  const [loading, setLoading] = useState(true);

  // Active Routing state
  const [activeTab, setActiveTab] = useState<string>("home");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Filters for BCA, Notes, and Jobs
  const [bcaSemesterFilter, setBcaSemesterFilter] = useState<string>("All");
  const [bcaCategoryFilter, setBcaCategoryFilter] = useState<string>("all");
  const [notesBranchFilter, setNotesBranchFilter] = useState<string>("All");
  const [jobsSearchTerm, setJobsSearchTerm] = useState<string>("");
  const [jobTypeFilter, setJobTypeFilter] = useState<string>("all");
  const [prepCategory, setPrepCategory] = useState<string>("all");

  // Global live search states
  const [searchQuery, setSearchQuery] = useState("");
  const [showSearchResults, setShowSearchResults] = useState(false);

  // Community Chat Widget state
  const [chatWidgetOpen, setChatWidgetOpen] = useState(false);
  const [chatMessages, setChatMessages] = useState<{ id: string; user: string; text: string; time: string }[]>([
    { id: "1", user: "Vikram (CSE)", text: "Hey! Can anyone please share database management notes for unit 3?", time: "3:14 PM" },
    { id: "2", user: "Shalini (IT)", text: "Just added UW database notes in Notes tab. Let me know if that helps!", time: "3:16 PM" },
    { id: "3", user: "Rahul", text: "Stripe just started hiring for frontend development intern on the platform, check it out guys!", time: "3:18 PM" }
  ]);
  const [chatInput, setChatInput] = useState("");

  // Details expander states
  const [selectedBlog, setSelectedBlog] = useState<Blog | null>(null);

  // Fetch application references
  const refreshAllDbLists = async () => {
    setLoading(true);
    try {
      // Step 1: Initialize mocked entries on Firestore if empty
      await initializeMockDataIfNeeded();

      // Step 2: Query databases
      const fetchedInternships = await getInternships();
      const fetchedJobs = await getJobs();
      const fetchedNotes = await getStudyMaterials();
      const fetchedBlogs = await getBlogs();

      setInternships(fetchedInternships);
      setJobs(fetchedJobs);
      setNotes(fetchedNotes);
      setBlogs(fetchedBlogs);
    } catch (e) {
      console.error("Transmission retrieval failure:", e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refreshAllDbLists();
  }, []);

  // Sync auth status
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (user) => {
      setCurrUser(user);
      if (user) {
        setProfileLoading(true);
        try {
          const userProf = await fetchUserProfile(user.uid);
          if (userProf) {
            setProfile(userProf);
          } else {
            // Create default profile for first time users
            const defaultProf: UserProfile = {
              uid: user.uid,
              email: user.email || "",
              displayName: user.displayName || user.email?.split("@")[0] || "Student",
              photoURL: user.photoURL || undefined,
              bookmarks: [],
              trackedApplications: []
            };
            await saveUserProfile(defaultProf);
            setProfile(defaultProf);
          }
        } catch (err) {
          console.error("Profilers sync error:", err);
        } finally {
          setProfileLoading(false);
        }
      } else {
        setProfile(null);
      }
    });
    return () => unsub();
  }, []);

  // Update themes
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add("dark");
      localStorage.setItem("techhelp_theme", "dark");
    } else {
      document.documentElement.classList.remove("dark");
      localStorage.setItem("techhelp_theme", "light");
    }
  }, [darkMode]);

  const handleApplyClick = async (item: any, type: 'job' | 'internship') => {
    if (!currUser) {
      alert("Please sign in first to track and record your job applications!");
      return;
    }
    if (!profile) return;

    // Check if duplicate
    const isAlreadyTracked = profile.trackedApplications.some(app => app.itemId === item.id);
    if (isAlreadyTracked) {
      // Still open link
      window.open(item.applyUrl, "_blank");
      return;
    }

    const nextApplication = {
      itemId: item.id,
      itemType: type,
      title: type === 'job' ? item.role : item.title,
      company: item.companyName,
      status: 'applied' as any,
      appliedAt: new Date().toISOString()
    };

    const updatedProfile = {
      ...profile,
      trackedApplications: [...profile.trackedApplications, nextApplication]
    };

    try {
      await saveUserProfile(updatedProfile);
      setProfile(updatedProfile);
      alert(`Success! "${nextApplication.title}" logged in your Applications dashboard tracking chart.`);
      // Open link
      window.open(item.applyUrl, "_blank");
    } catch (e) {
      console.error(e);
      window.open(item.applyUrl, "_blank");
    }
  };

  const toggleBookmark = async (id: string) => {
    if (!currUser) {
      alert("SignIn with Google to bookmark listings!");
      return;
    }
    if (!profile) return;

    let updatedBookmarks;
    if (profile.bookmarks.includes(id)) {
      updatedBookmarks = profile.bookmarks.filter(b => b !== id);
    } else {
      updatedBookmarks = [...profile.bookmarks, id];
    }

    const updatedProfile = {
      ...profile,
      bookmarks: updatedBookmarks
    };

    try {
      await saveUserProfile(updatedProfile);
      setProfile(updatedProfile);
    } catch (e) {
      console.error(e);
    }
  };

  const handleDownloadTrigger = async (noteId: string) => {
    try {
      await incrementDownloadCounter(noteId);
      // Update local state list downloads count
      setNotes(notes.map(n => n.id === noteId ? { ...n, downloadsCount: (n.downloadsCount || 0) + 1 } : n));
    } catch (e) {
      console.error(e);
    }
  };

  const handleAddCommunityMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;

    const name = currUser ? currUser.displayName || currUser.email?.split("@")[0] || "Student" : "Guest Student";
    const newMessage = {
      id: Math.random().toString(),
      user: name,
      text: chatInput.trim(),
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setChatMessages([...chatMessages, newMessage]);
    setChatInput("");
  };

  // Profile fields save
  const handleSaveProfileDetails = async (display: string, college: string, branch: string, year: string, bio: string) => {
    if (!currUser || !profile) return;
    const updated = {
      ...profile,
      displayName: display,
      college,
      branch,
      year,
      bio
    };
    try {
      await saveUserProfile(updated);
      setProfile(updated);
      alert("Academic student profile updated successfully!");
    } catch (e) {
      alert("Failed updating details: " + e);
    }
  };

  // Admin writes wrappers
  const handleAdminAddInternship = async (item: Omit<Internship, "id">) => {
    await addInternship(item);
    await refreshAllDbLists();
  };

  const handleAdminDeleteInternship = async (id: string) => {
    await deleteInternship(id);
    await refreshAllDbLists();
  };

  const handleAdminAddJob = async (item: Omit<Job, "id">) => {
    await addJob(item);
    await refreshAllDbLists();
  };

  const handleAdminDeleteJob = async (id: string) => {
    await deleteJob(id);
    await refreshAllDbLists();
  };

  const handleAdminAddNote = async (item: Omit<StudyMaterial, "id">) => {
    await addStudyMaterial(item);
    await refreshAllDbLists();
  };

  const handleAdminAddBlog = async (item: Omit<Blog, "id">) => {
    await addBlog(item);
    await refreshAllDbLists();
  };

  const handleShareOnSocial = (platform: 'wa' | 'tele' | 'li' | 'tw') => {
    const url = window.location.href;
    const shareText = "Check out TechHelp, the ultimate student hub! Find internships, jobs, hackathons, notes, percentage tools, and AI study bots: " + url;
    let shareUrl = "";

    switch (platform) {
      case 'wa':
        shareUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(shareText)}`;
        break;
      case 'tele':
        shareUrl = `https://t.me/share/url?url=${encodeURIComponent(url)}&text=${encodeURIComponent("TechHelp: One platform for every student need!")}`;
        break;
      case 'li':
        shareUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}`;
        break;
      case 'tw':
        shareUrl = `https://twitter.com/intent/tweet?url=${encodeURIComponent(url)}&text=${encodeURIComponent("TechHelp student portal!")}`;
        break;
    }
    window.open(shareUrl, "_blank");
  };

  // Searches filtering
  const filteredInternships = internships.filter(item => 
    item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    item.companyName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    item.location.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredJobs = jobs.filter(item => 
    item.role.toLowerCase().includes(searchQuery.toLowerCase()) ||
    item.companyName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    item.location.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredNotes = notes.filter(item => 
    item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    item.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
    item.branch.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredBlogs = blogs.filter(item => 
    item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    item.summary.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const totalResultsCount = filteredInternships.length + filteredJobs.length + filteredNotes.length + filteredBlogs.length;

  const isAdmin = currUser?.email === "5pshraddha55@gmail.com";

  return (
    <div className="min-h-screen bg-white text-slate-950 font-sans flex flex-col justify-between selection:bg-blue-100 selection:text-blue-900">
      
      {/* Info Modal state helper */}
      {(() => {
        const modalContent = (() => {
          switch (activeTab) {
            case "info_about":
              return {
                title: "About Notes Gallery",
                desc: "Notes Gallery is the premier digital library and study resource companion for technical and professional course students. Founded with the mission 'Study Smart. Grow Fast.', we provide unit-wise class notebooks, official syllabus frameworks, previous year examination papers, and the highly essential Quantum Series solved references.",
                highlight: "Helping over 50,000+ college students succeed in university evaluations seamlessly."
              };
            case "info_contact":
              return {
                title: "Contact Notes Gallery",
                desc: "We are always here to answer your academic preparation questions and support colleges! For partnership notices, syllabus additions, or study material submissions, reach out to our team:",
                email: "support@notesgallery.com",
                phone: "+91 98765 43210",
                address: "Sector-11, Jankipuram Vistar, Lucknow, UP - 226031"
              };
            case "info_privacy":
              return {
                title: "Privacy Policy",
                desc: "Your academic profile privacy and document downloads security are essential to us. We secure your authenticated Google login credentials securely and protect any user logs from external leaks. We do not sell user profiling parameters to marketing networks.",
                highlight: "Fully compliant with digital student education safety protocols."
              };
            case "info_terms":
              return {
                title: "Terms and Conditions",
                desc: "All content study materials, including handcrafted student notes, syllabus copies, and reference files are uploaded strictly for personal educational guidelines and non-commercial learning reference. Students are requested to adhere to exam guidelines and university conduct.",
                highlight: "Always avoid plagiarism; prepare hard, study smart and follow university mandates."
              };
            default:
              return null;
          }
        })();

        if (!modalContent) return null;

        return (
          <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/60 backdrop-blur-sm flex justify-center items-center p-4">
            <div className="bg-white border border-slate-200 max-w-lg w-full rounded-2xl p-6 space-y-4 shadow-xl">
              <div className="flex justify-between items-center border-b border-slate-100 pb-3">
                <h3 className="font-bold text-lg text-blue-600">{modalContent.title}</h3>
                <button
                  onClick={() => setActiveTab("home")}
                  className="p-1 px-2 hover:bg-slate-50 rounded-md text-xs font-semibold"
                >
                  Close
                </button>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed font-sans">{modalContent.desc}</p>
              
              {"highlight" in modalContent && (
                <div className="bg-blue-50 p-3 rounded-lg border border-blue-100 text-[11px] text-blue-700 font-semibold">
                  {modalContent.highlight}
                </div>
              )}

              {"email" in modalContent && (
                <div className="space-y-1.5 text-xs text-slate-600 border-t border-slate-100 pt-3">
                  <p>📧 Email: <strong className="text-slate-900">{modalContent.email}</strong></p>
                  <p>📞 Phone: <strong className="text-slate-900">{modalContent.phone}</strong></p>
                  <p>📍 Location: <strong>{modalContent.address}</strong></p>
                </div>
              )}
            </div>
          </div>
        );
      })()}

      {/* ------------------------------------------------------------- */}
      {/* 1. TOP UTILITY INFORMATION BAR */}
      {/* ------------------------------------------------------------- */}
      <div className="bg-white text-slate-950 text-[10.5px] border-b border-slate-200 py-1">
        <div className="max-w-7xl mx-auto px-4 h-8 flex items-center justify-between font-sans">
          <div className="flex items-center gap-4">
            {[
              { id: "info_about", label: "About Notesgallery" },
              { id: "info_contact", label: "Contact Us" },
              { id: "info_privacy", label: "Privacy Policy" },
              { id: "info_terms", label: "Terms and Conditions" }
            ].map(link => (
              <button
                key={link.id}
                onClick={() => setActiveTab(link.id)}
                className="hover:text-blue-600 font-bold transition-colors cursor-pointer"
              >
                {link.label}
              </button>
            ))}
          </div>
          <div className="hidden sm:inline-flex items-center gap-1.5 text-blue-600 font-extrabold text-[11px]">
            <span className="w-2 h-2 bg-blue-600 rounded-full animate-pulse" />
            AKTU Portal Live Hub: 2026 Academic Session
          </div>
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* 2. MAIN BRAND LOGO & CENTERED SEARCH ROW */}
      {/* ------------------------------------------------------------- */}
      <header className="w-full bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex flex-col md:flex-row gap-4 items-center justify-between">
          
          {/* Notes Gallery Logo Container */}
          <div className="flex items-center gap-3 cursor-pointer select-none" onClick={() => { setActiveTab("home"); setSearchQuery(""); setShowSearchResults(false); }}>
            <div className="w-9 h-9 rounded-xl bg-blue-600 flex items-center justify-center text-white shadow-md">
              <ClipboardList className="w-5 h-5" />
            </div>
            <div>
              <h1 className="font-display font-extrabold text-xl leading-none tracking-tight text-slate-950">
                Notes <span className="text-blue-600">Gallery</span>
              </h1>
              <span className="font-sans text-[10px] tracking-wider text-slate-500 font-bold block mt-0.5">
                Study Smart. Grow Fast.
              </span>
            </div>
          </div>

          {/* Centered Large Screen Search Input ("search here...") */}
          <div className="w-full md:max-w-md relative flex items-center">
            <Search className="absolute left-3.5 w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder="search here..."
              className="w-full text-xs pl-10 pr-16 py-2.5 border border-slate-200 rounded-full bg-white focus:outline-none focus:ring-2 focus:ring-blue-600/10 focus:border-blue-600 text-slate-950 font-medium transition-all shadow-sm"
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setShowSearchResults(e.target.value.trim().length > 0);
              }}
            />
            {searchQuery ? (
              <button 
                onClick={() => { setSearchQuery(""); setShowSearchResults(false); }}
                className="absolute right-4 text-xs font-bold text-slate-400 hover:text-slate-600"
              >
                Clear
              </button>
            ) : (
              <span className="absolute right-4 text-[9px] font-mono font-bold text-slate-400 bg-slate-100 px-1.5 py-0.5 rounded">
                Ctrl+K
              </span>
            )}
          </div>

          {/* Right Action Widgets */}
          <div className="flex items-center gap-3.5">
            
            {/* Theme switcher */}
            <button
              onClick={() => setDarkMode(!darkMode)}
              className="p-2 hover:bg-slate-150 rounded-lg transition-colors cursor-pointer text-slate-600"
              title="Toggle Theme Mode"
            >
              {darkMode ? <Sun className="w-4 h-4 text-blue-600" /> : <Moon className="w-4 h-4 text-blue-600" />}
            </button>

            {/* Auth displays */}
            {currUser ? (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setActiveTab("profile")}
                  className="flex items-center gap-1.5 p-1 px-2.5 bg-blue-50 rounded-full border border-blue-100 cursor-pointer hover:bg-blue-100 transition-all"
                >
                  <img src={currUser.photoURL || undefined} alt={currUser.displayName || "user"} className="w-5 h-5 rounded-full object-cover" referrerPolicy="no-referrer" />
                  <span className="text-[11px] font-bold text-slate-900 hidden sm:inline max-w-20 truncate">{currUser.displayName || "Student"}</span>
                </button>
                <button 
                  onClick={logoutUser}
                  className="p-1.5 text-slate-500 hover:text-rose-500 rounded-lg cursor-pointer transition-colors"
                  title="Logout Account"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button
                onClick={signInWithGoogle}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold shadow hover:shadow-md cursor-pointer transition-all"
              >
                <User className="w-3.5 h-3.5" /> Sign In
              </button>
            )}

            {/* Mobile Drawer trigger */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 hover:bg-slate-150 rounded-lg transition-colors cursor-pointer text-slate-600"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* ------------------------------------------------------------- */}
        {/* 3. PRIMARY HORIZONTAL NAVIGATION BAR */}
        {/* ------------------------------------------------------------- */}
        <nav className="bg-white border-t border-b border-slate-200 transition-colors">
          <div className="max-w-7xl mx-auto px-4 flex items-center justify-between overflow-x-auto scrollbar-none gap-2 py-0.5">
            <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none py-1.5">
              {[
                { id: "home", label: "Home" },
                { id: "bca", label: "BCA 🎓" },
                { id: "btech", label: "B.Tech" },
                { id: "mca", label: "MCA" },
                { id: "mba", label: "MBA" },
                { id: "bpharm", label: "B.Pharm" },
                { id: "jobs", label: "Jobs & Careers 💼" },
                { id: "notes_category", label: "Notes" },
                { id: "pyqs", label: "PYQs" },
                { id: "quantum", label: "Quantum" },
                { id: "syllabus_category", label: "Syllabus" },
                { id: "prepkits", label: "Prep & Drives 🚀" },
                { id: "news", label: "News & Alerts" },
                { id: "community", label: "Lounge" },
                { id: "aisuite", label: "AI Suite ✦" },
                { id: "tools", label: "Tools" },
                { id: "admin", label: "Admin Panel" }
              ].map(tab => (
                <button
                  key={tab.id}
                  onClick={() => { setActiveTab(tab.id); setSearchQuery(""); setShowSearchResults(false); }}
                  className={`text-[10.5px] uppercase font-extrabold tracking-wider px-3.5 py-1.5 rounded-lg transition-all cursor-pointer whitespace-nowrap ${
                    activeTab === tab.id || (tab.id === 'jobs' && (activeTab === 'placement' || activeTab === 'internships'))
                      ? 'bg-blue-600 text-white shadow-md'
                      : 'text-slate-950 hover:text-blue-600 hover:bg-blue-50/50'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>
        </nav>
      </header>

      {/* Mobile Drawer list menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="md:hidden fixed z-30 top-[110px] left-0 w-full bg-white shadow-xl border-b border-slate-200 p-5 space-y-4 font-sans"
          >
            <div className="grid grid-cols-2 gap-2">
              {[
                { id: "home", label: "Home" },
                { id: "bca", label: "BCA 🎓" },
                { id: "btech", label: "B.Tech" },
                { id: "mca", label: "MCA" },
                { id: "mba", label: "MBA" },
                { id: "bpharm", label: "B.Pharm" },
                { id: "jobs", label: "Jobs & Careers 💼" },
                { id: "notes_category", label: "Notes" },
                { id: "pyqs", label: "PYQs" },
                { id: "quantum", label: "Quantum" },
                { id: "syllabus_category", label: "Syllabus" },
                { id: "prepkits", label: "Prep & Drives 🚀" },
                { id: "news", label: "News & Alerts" },
                { id: "community", label: "Lounge" },
                { id: "aisuite", label: "AI Suite ✦" },
                { id: "tools", label: "Tools" },
                { id: "admin", label: "Admin Panel" }
              ].map(tab => (
                <button
                  key={tab.id}
                  onClick={() => { 
                    setActiveTab(tab.id); 
                    setMobileMenuOpen(false); 
                    setSearchQuery("");
                    setShowSearchResults(false);
                  }}
                  className={`py-2 px-3 text-[10.5px] font-bold uppercase tracking-wide text-center rounded-lg border cursor-pointer transition-all ${
                    activeTab === tab.id || (tab.id === 'jobs' && (activeTab === 'placement' || activeTab === 'internships'))
                      ? 'bg-blue-600 text-white border-blue-600'
                      : 'text-slate-900 border-slate-200 hover:bg-blue-50/50'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ------------------------------------------------------------- */}
      {/* FLOATERS: SOCIAL SHARING BUTTONS */}
      {/* ------------------------------------------------------------- */}
      <div className="fixed left-4 bottom-24 z-30 flex flex-col gap-2 bg-white/80 dark:bg-slate-900/80 p-2 rounded-2xl shadow-lg border border-slate-200/50 dark:border-white/5 backdrop-blur-md hidden sm:flex">
        <button
          onClick={() => handleShareOnSocial("wa")}
          className="p-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-600 dark:bg-emerald-950/40 dark:text-emerald-400 rounded-xl cursor-pointer transition-all hover:scale-105"
          title="Share via WhatsApp"
        >
          <Share2 className="w-4 h-4" />
        </button>
        <button
          onClick={() => handleShareOnSocial("tele")}
          className="p-2 bg-sky-50 hover:bg-sky-100 text-sky-500 dark:bg-sky-950/40 dark:text-sky-300 rounded-xl cursor-pointer transition-all hover:scale-105"
          title="Share on Telegram"
        >
          <ExternalLink className="w-4 h-4" />
        </button>
        <button
          onClick={() => handleShareOnSocial("li")}
          className="p-2 bg-blue-50 hover:bg-blue-100 text-blue-600 dark:bg-blue-950/40 dark:text-blue-400 rounded-xl cursor-pointer transition-all hover:scale-105"
          title="Share on LinkedIn"
        >
          <Award className="w-4 h-4" />
        </button>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* MAIN LAYOUT CANVAS */}
      {/* ------------------------------------------------------------- */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12 transition-all">
        
        {/* SEARCH MODE WINDOW (Expanded search query takes priority) */}
        {showSearchResults ? (
          <div className="space-y-6">
            <div className="flex justify-between items-center bg-blue-50/50 dark:bg-blue-950/20 p-4 rounded-xl border border-blue-100/50 dark:border-white/5">
              <h3 className="font-semibold text-sm">
                🔍 Displaying {totalResultsCount} results matching "{searchQuery}"
              </h3>
              <button 
                onClick={() => { setSearchQuery(""); setShowSearchResults(false); }}
                className="px-3 py-1 border rounded-lg text-xs font-semibold cursor-pointer"
              >
                Exit Search
              </button>
            </div>

            {/* Results sections */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* Internships/Jobs outputs */}
              <div className="space-y-4">
                <h4 className="text-sm uppercase font-mono tracking-wider font-semibold text-slate-500">
                  Internships & Jobs ({filteredInternships.length + filteredJobs.length})
                </h4>
                <div className="space-y-3">
                  {filteredInternships.map(item => (
                    <div key={item.id} className="bg-white dark:bg-slate-950 p-4 rounded-xl border border-slate-150 dark:border-white/5 flex gap-4">
                      <img src={item.logoUrl} alt={item.companyName} className="w-10 h-10 object-cover rounded-lg" referrerPolicy="no-referrer" />
                      <div className="flex-1">
                        <span className="text-[10px] font-bold text-blue-500">INTERNSHIP</span>
                        <h5 className="font-bold text-xs text-slate-800 dark:text-slate-150">{item.title}</h5>
                        <p className="text-[10px] text-slate-500 mt-0.5">{item.companyName} • {item.location}</p>
                        <button
                          onClick={() => handleApplyClick(item, 'internship')}
                          className="mt-2 text-[10px] font-semibold text-blue-600 dark:text-blue-400 flex items-center gap-0.5"
                        >
                          Apply now <ChevronRight className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  ))}
                  {filteredJobs.map(item => (
                    <div key={item.id} className="bg-white dark:bg-slate-950 p-4 rounded-xl border border-slate-150 dark:border-white/5 flex gap-4">
                      <img src={item.logoUrl} alt={item.companyName} className="w-10 h-10 object-cover rounded-lg" referrerPolicy="no-referrer" />
                      <div className="flex-1">
                        <span className="text-[10px] font-bold text-indigo-500 font-mono">JOB OPENING</span>
                        <h5 className="font-bold text-xs text-slate-800 dark:text-slate-150">{item.role}</h5>
                        <p className="text-[10px] text-slate-500 mt-0.5">{item.companyName} • {item.location}</p>
                        <button
                          onClick={() => handleApplyClick(item, 'job')}
                          className="mt-2 text-[10px] font-semibold text-indigo-600 dark:text-indigo-400 flex items-center gap-0.5"
                        >
                          Apply now <ChevronRight className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Study materials / Academic Notes outputs */}
              <div className="space-y-4">
                <h4 className="text-sm uppercase font-mono tracking-wider font-semibold text-slate-500">
                  Study Materials & E-Books ({filteredNotes.length})
                </h4>
                <div className="space-y-2">
                  {filteredNotes.map(item => (
                    <div key={item.id} className="bg-white dark:bg-slate-950 p-4 rounded-xl border border-slate-150 dark:border-white/5 space-y-1">
                      <span className="inline-block px-1.5 py-0.5 rounded text-[10px] bg-slate-100 dark:bg-slate-900 font-bold uppercase text-slate-500 font-mono">
                        {item.category}
                      </span>
                      <h5 className="font-bold text-slate-900 dark:text-white text-xs">{item.title}</h5>
                      <span className="text-[10px] text-slate-500 block">Subject: {item.subject} • Branch: {item.branch}</span>
                      <a
                        href={item.downloadUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        onClick={() => handleDownloadTrigger(item.id)}
                        className="inline-block text-[10px] font-semibold text-emerald-500 dark:text-emerald-400 mt-2"
                      >
                        Download Asset
                      </a>
                    </div>
                  ))}
                  {filteredNotes.length === 0 && (
                    <span className="text-xs text-slate-400 italic">No academic resources matched the search string parameters.</span>
                  )}
                </div>
              </div>
            </div>
          </div>
        ) : (
          <AnimatePresence mode="wait">
            
            {/* ------------------------------------------------------------- */}
            {/* TAB: HOME */}
            {/* ------------------------------------------------------------- */}
            {activeTab === "home" && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="space-y-16"
              >
                {/* Hero Section */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center bg-gradient-to-br from-blue-50/50 via-indigo-50/20 to-transparent dark:from-indigo-950/10 dark:via-transparent dark:to-transparent rounded-3xl p-6 md:p-12 border border-slate-200/40 dark:border-white/5 relative overflow-hidden transition-all">
                  
                  {/* Absolute backgrounds decoration */}
                  <div className="absolute top-0 right-0 w-64 h-64 bg-blue-500/5 rounded-full blur-3xl pointer-events-none" />
                  <div className="absolute bottom-0 left-0 w-48 h-48 bg-indigo-500/5 rounded-full blur-3xl pointer-events-none" />

                  <div className="space-y-6 text-center md:text-left">
                    <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-blue-100/60 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400 text-xs font-bold rounded-full">
                      <Sparkles className="w-3.5 h-3.5" /> Direct College Student Platform
                    </div>
                    <h1 className="text-4xl md:text-5xl font-display font-medium tracking-tight text-slate-900 dark:text-white leading-tight">
                      One Platform for Every Student Need
                    </h1>
                    <p className="text-base text-slate-600 dark:text-slate-400">
                      Find internships, premier jobs, active hackathons, PYQ examinations, course notes, and explore powerful AI interview roadmap calculators!
                    </p>
                    
                    {/* Buttons */}
                    <div className="flex flex-col sm:flex-row gap-3 justify-center md:justify-start">
                      <button
                        onClick={() => setActiveTab("internships")}
                        className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-sm font-semibold shadow-lg shadow-blue-500/15 cursor-pointer hover:scale-[1.01] transition-all"
                      >
                        Explore Opportunities
                      </button>
                      <button
                        onClick={() => setActiveTab("community")}
                        className="px-6 py-3 bg-white hover:bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-white/10 rounded-xl text-sm font-semibold cursor-pointer hover:border-slate-350 transition-all text-slate-700 dark:text-slate-300"
                      >
                        Join Student Lounge
                      </button>
                    </div>
                  </div>

                  {/* Attractive Illustration Mock */}
                  <div className="flex justify-center md:justify-end">
                    <div className="relative w-full max-w-sm rounded-2xl glass p-6 border border-white/40 dark:border-white/5 shadow-xl space-y-4">
                      <div className="flex items-center gap-3">
                        <div className="w-3 h-3 rounded-full bg-rose-500" />
                        <div className="w-3 h-3 rounded-full bg-amber-500" />
                        <div className="w-3 h-3 rounded-full bg-emerald-500" />
                        <span className="text-[10px] font-mono text-slate-400 ml-auto">TechHelp Live Desktop</span>
                      </div>
                      
                      <div className="bg-slate-950 p-4 rounded-xl font-mono text-xs text-emerald-400 space-y-1.5 select-none shadow-inner">
                        <p className="text-slate-500">// Student Preparation Hub</p>
                        <p>&gt; npm run prepare --for-placement</p>
                        <p>&gt; <span className="text-white font-semibold">Ready:</span> Active DSA sheets loaded</p>
                        <p>&gt; <span className="text-indigo-400 font-semibold">Gemini API:</span> Career roadmaps configured</p>
                        <p>&gt; <span className="text-sky-400 font-semibold">Firebase:</span> Database synced</p>
                      </div>

                      <div className="bg-gradient-to-r from-blue-500 to-indigo-500 p-3 rounded-xl text-white flex justify-between items-center shadow-md">
                        <div>
                          <span className="text-[10px] opacity-80 block">Upcoming Hackathon</span>
                          <span className="text-xs font-semibold block">Smart India Hackathon</span>
                        </div>
                        <button onClick={() => setActiveTab("community")} className="p-1.5 bg-white/20 hover:bg-white/30 rounded-lg">
                          <ChevronRight className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>

                {/* ------------------------------------------------------------- */}
                {/* HOMEPAGE FEATURED SECTIONS */}
                {/* ------------------------------------------------------------- */}
                
                {/* Section: Featured Internships */}
                <div className="space-y-6">
                  <div className="flex justify-between items-center">
                    <div>
                      <h3 className="text-2xl font-display font-medium text-slate-800 dark:text-slate-200">
                        Featured Internship Placements
                      </h3>
                      <p className="text-xs text-slate-500">Accelerate your practical field credentials.</p>
                    </div>
                    <button onClick={() => setActiveTab("internships")} className="text-xs font-semibold text-blue-600 dark:text-blue-400 flex items-center gap-0.5 hover:underline">
                      View all ({internships.length}) <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {internships.slice(0, 3).map((item) => (
                      <div key={item.id} className="bg-white dark:bg-slate-950 p-5 rounded-2xl border border-slate-150 dark:border-white/5 shadow-sm hover:shadow-md hover:border-slate-300 dark:hover:border-slate-800 transition-all flex flex-col justify-between">
                        <div className="space-y-3">
                          <div className="flex justify-between items-center">
                            <img src={item.logoUrl} alt={item.companyName} className="w-10 h-10 object-cover rounded-xl" referrerPolicy="no-referrer" />
                            <button onClick={() => toggleBookmark(item.id)} className="p-1.5 hover:bg-slate-50 dark:hover:bg-slate-900 border border-slate-100 dark:border-white/5 rounded-lg text-slate-400 hover:text-rose-500 cursor-pointer">
                              <Heart className={`w-4 h-4 ${profile?.bookmarks.includes(item.id) ? 'fill-rose-500 text-rose-500' : ''}`} />
                            </button>
                          </div>
                          <div>
                            <span className="text-[10px] uppercase font-mono tracking-wider font-semibold text-blue-600 dark:text-blue-400">
                              {item.duration || "2 Months"} Internship
                            </span>
                            <h4 className="font-bold text-sm tracking-tight text-slate-800 dark:text-slate-150 block mt-0.5 truncate0">
                              {item.title}
                            </h4>
                            <span className="text-xs text-slate-500 font-semibold block">{item.companyName}</span>
                          </div>
                        </div>

                        <div className="border-t border-slate-100 dark:border-white/5 pt-3 mt-4 space-y-3">
                          <div className="flex justify-between items-center text-xs text-slate-600 dark:text-slate-400">
                            <span className="flex items-center gap-1"><MapPin className="w-3.5 h-3.5" /> {item.location}</span>
                            <span className="font-semibold text-emerald-500 dark:text-emerald-400">{item.stipend}</span>
                          </div>
                          <button
                            onClick={() => handleApplyClick(item, 'internship')}
                            className="w-full py-2 bg-slate-900 text-white dark:bg-white dark:text-slate-950 rounded-xl text-xs font-semibold cursor-pointer shadow-sm hover:bg-blue-600 dark:hover:bg-blue-500 dark:hover:text-white transition-all text-center block"
                          >
                            Apply Internship
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Section: Latest Jobs */}
                <div className="space-y-6">
                  <div className="flex justify-between items-center">
                    <div>
                      <h3 className="text-2xl font-display font-medium text-slate-800 dark:text-slate-200">
                        Latest Entry-Level Jobs
                      </h3>
                      <p className="text-xs text-slate-500">Kickstart your coding career path with direct opportunities.</p>
                    </div>
                    <button onClick={() => setActiveTab("jobs")} className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 flex items-center gap-0.5 hover:underline">
                      View all ({jobs.length}) <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {jobs.slice(0, 3).map((item) => (
                      <div key={item.id} className="bg-white dark:bg-slate-950 p-5 rounded-2xl border border-slate-150 dark:border-white/5 shadow-sm hover:shadow-md hover:border-slate-300 dark:hover:border-slate-800 transition-all flex flex-col justify-between">
                        <div className="space-y-3">
                          <div className="flex justify-between items-center">
                            <img src={item.logoUrl} alt={item.companyName} className="w-10 h-10 object-cover rounded-xl" referrerPolicy="no-referrer" />
                            <button onClick={() => toggleBookmark(item.id)} className="p-1.5 hover:bg-slate-50 dark:hover:bg-slate-900 border border-slate-100 dark:border-white/5 rounded-lg text-slate-400 hover:text-rose-500 cursor-pointer">
                              <Heart className={`w-4 h-4 ${profile?.bookmarks.includes(item.id) ? 'fill-rose-500 text-rose-500' : ''}`} />
                            </button>
                          </div>
                          <div>
                            <span className="text-[10px] uppercase font-mono tracking-wider font-semibold text-indigo-600 dark:text-indigo-400">
                              Full-time Job
                            </span>
                            <h4 className="font-bold text-sm tracking-tight text-slate-800 dark:text-slate-150 block mt-0.5 truncate">
                              {item.role}
                            </h4>
                            <span className="text-xs text-slate-500 font-semibold block">{item.companyName}</span>
                          </div>
                        </div>

                        <div className="border-t border-slate-100 dark:border-white/5 pt-3 mt-4 space-y-3">
                          <div className="flex justify-between items-center text-xs text-slate-600 dark:text-slate-400">
                            <span className="flex items-center gap-1"><MapPin className="w-3.5 h-3.5" /> {item.location}</span>
                            <span className="font-semibold text-blue-500 dark:text-blue-400">{item.salary}</span>
                          </div>
                          <button
                            onClick={() => handleApplyClick(item, 'job')}
                            className="w-full py-2 bg-slate-900 text-white dark:bg-white dark:text-slate-950 rounded-xl text-xs font-semibold cursor-pointer shadow-sm hover:bg-indigo-600 dark:hover:bg-indigo-500 dark:hover:text-white transition-all text-center block"
                          >
                            Apply Role
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Section: Upcoming Hackathons */}
                <div className="space-y-6">
                  <div>
                    <h3 className="text-2xl font-display font-medium text-slate-800 dark:text-slate-200">
                      Upcoming Active Hackathons 2026
                    </h3>
                    <p className="text-xs text-slate-500">Participate in hackathons to polish practical group skills and earn bounties.</p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-6 rounded-2xl text-white shadow-md relative overflow-hidden flex flex-col justify-between h-48">
                      <div className="absolute right-0 bottom-0 opacity-10">
                        <Trophy className="w-48 h-48" />
                      </div>
                      <div className="space-y-1">
                        <span className="inline-block text-[10px] font-mono bg-white/20 py-0.5 px-2 rounded">National Level Hackathon</span>
                        <h4 className="text-xl font-display font-bold">Smart India Hackathon (SIH) 2026</h4>
                        <p className="text-xs text-slate-100 max-w-sm line-clamp-2">India's most significant coding initiative to solve real governance system bottlenecks.</p>
                      </div>
                      <div className="flex justify-between items-center mt-4">
                        <span className="text-xs font-mono">Prize Pool: ₹10,00,000</span>
                        <a href="https://sih.gov.in" target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 px-4 py-1.5 bg-white text-slate-900 rounded-lg text-xs font-bold shadow-sm hover:bg-slate-100 transition-all">
                          Register <ChevronRight className="w-3.5 h-3.5" />
                        </a>
                      </div>
                    </div>

                    <div className="bg-gradient-to-r from-purple-600 to-pink-600 p-6 rounded-2xl text-white shadow-md relative overflow-hidden flex flex-col justify-between h-48">
                      <div className="absolute right-0 bottom-0 opacity-10">
                        <Award className="w-48 h-48" />
                      </div>
                      <div className="space-y-1">
                        <span className="inline-block text-[10px] font-mono bg-white/20 py-0.5 px-2 rounded">Global MLH League</span>
                        <h4 className="text-xl font-display font-bold">Local Hack Day 2026</h4>
                        <p className="text-xs text-slate-100 max-w-sm line-clamp-2">Major League Hacking's primary 24hour community sprints centered on global student solutions.</p>
                      </div>
                      <div className="flex justify-between items-center mt-4">
                        <span className="text-xs font-mono">Prize Pool: $5,000</span>
                        <a href="https://mlh.io" target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 px-4 py-1.5 bg-white text-slate-900 rounded-lg text-xs font-bold shadow-sm hover:bg-slate-100 transition-all">
                          Register <ChevronRight className="w-3.5 h-3.5" />
                        </a>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Section: Study Materials */}
                <div className="space-y-6">
                  <div className="flex justify-between items-center">
                    <div>
                      <h3 className="text-2xl font-display font-medium text-slate-800 dark:text-slate-200 font-display">
                        Quick Study Handouts
                      </h3>
                      <p className="text-xs text-slate-500">Download Syllabus, notes, previous year exams compiled to your branch.</p>
                    </div>
                    <button onClick={() => setActiveTab("notes_category")} className="text-xs font-semibold text-blue-600 flex items-center gap-0.5 hover:underline">
                      See curriculum downloads ({notes.length}) <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {/* Degree Portals Grid */}
                  <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
                    {[
                      { tab: 'bca', label: 'BCA Hub', desc: 'Computer Apps', count: notes.filter(n => n.branch.toLowerCase().includes('bca')).length, icon: '💻', badge: 'New Degree' },
                      { tab: 'btech', label: 'B.Tech CSE', desc: 'Engineering', count: notes.filter(n => n.branch.toLowerCase().includes('b.tech') || n.branch.toLowerCase().includes('computer')).length, icon: '🎓', badge: 'Core Tech' },
                      { tab: 'mca', label: 'MCA Portal', desc: 'Software PG', count: notes.filter(n => n.branch.toLowerCase().includes('mca')).length, icon: '⚡', badge: 'Postgraduate' },
                      { tab: 'mba', label: 'MBA Class', desc: 'Management', count: notes.filter(n => n.branch.toLowerCase().includes('mba')).length, icon: '📈', badge: 'Business' },
                      { tab: 'bpharm', label: 'B.Pharm', desc: 'Pharma Sciences', count: notes.filter(n => n.branch.toLowerCase().includes('pharm')).length, icon: '💊', badge: 'Medical' },
                      { tab: 'jobs', label: 'Job Portal', desc: 'Careers & Hiring', count: jobs.length + internships.length, icon: '💼', badge: 'Active Openings' }
                    ].map((deg, idx) => (
                      <div
                        key={idx}
                        onClick={() => setActiveTab(deg.tab)}
                        className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm text-center cursor-pointer hover:border-blue-600 hover:shadow-md hover:-translate-y-0.5 transition-all relative overflow-hidden"
                      >
                        <span className="text-2xl block">{deg.icon}</span>
                        <h4 className="font-extrabold text-slate-900 text-xs mt-2">{deg.label}</h4>
                        <p className="text-[10px] text-slate-500 font-medium">{deg.desc}</p>
                        <span className="inline-block mt-2 text-[9px] font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full">
                          {deg.count} Resources
                        </span>
                      </div>
                    ))}
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6 mt-4">
                    {[
                      { tab: 'quantum', label: 'Solved Quantum Books', count: notes.filter(n => n.category === 'quantum').length, icon: '📚' },
                      { tab: 'pyqs', label: 'Previous Year Exams', count: notes.filter(n => n.category === 'pyq').length, icon: '📄' },
                      { tab: 'syllabus_category', label: 'Official Syllabus Lists', count: notes.filter(n => n.category === 'syllabus').length, icon: '📋' },
                      { tab: 'notes_category', label: 'Branch Scholar Notes', count: notes.filter(n => n.category === 'notes').length, icon: '📘' }
                    ].map((sec, idx) => (
                      <div
                        key={idx}
                        onClick={() => setActiveTab(sec.tab)}
                        className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm text-center cursor-pointer hover:shadow-md hover:border-blue-600 hover:-translate-y-0.5 transition-all"
                      >
                        <span className="text-3xl block filter drop-shadow">{sec.icon}</span>
                        <h4 className="font-extrabold text-slate-900 text-xs mt-3">{sec.label}</h4>
                        <span className="text-[10px] text-slate-500 font-bold block mt-1">{sec.count || "Multiple"} Items loaded</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Section: Placement Preparation Blogs */}
                <div className="space-y-6">
                  <div className="flex justify-between items-center">
                    <div>
                      <h3 className="text-2xl font-display font-medium text-slate-800 dark:text-slate-200">
                        Student Career Insights
                      </h3>
                      <p className="text-xs text-slate-500">Strategy journals authored by toppers and placement mentors.</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {blogs.map((b) => (
                      <div key={b.id} className="bg-white dark:bg-slate-950 rounded-2xl overflow-hidden border border-slate-150 dark:border-white/5 shadow-sm flex flex-col md:flex-row hover:shadow-md transition-shadow">
                        <img src={b.imageUrl} alt={b.title} className="w-full md:w-44 h-44 object-cover" referrerPolicy="no-referrer" />
                        <div className="p-5 flex flex-col justify-between">
                          <div className="space-y-1.5">
                            <span className="text-[9px] font-mono tracking-wider font-bold uppercase text-indigo-600 dark:text-indigo-400">Featured Article</span>
                            <h4 className="font-bold text-sm text-slate-900 dark:text-white leading-tight">{b.title}</h4>
                            <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2">{b.summary}</p>
                          </div>
                          <div className="flex items-center justify-between pt-4 border-t border-slate-100 dark:border-white/5">
                            <span className="text-[10px] text-slate-500 font-medium font-mono">By {b.author}</span>
                            <button
                              onClick={() => setSelectedBlog(b)}
                              className="text-xs font-bold text-blue-600 dark:text-blue-400 flex items-center gap-0.5 hover:underline cursor-pointer"
                            >
                              Read More
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

              </motion.div>
            )}

            {/* ------------------------------------------------------------- */}
            {/* TAB: BCA (BACHELOR OF COMPUTER APPLICATIONS) ACADEMIC PORTAL */}
            {/* ------------------------------------------------------------- */}
            {activeTab === "bca" && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
                {/* Hero Header Banner */}
                <div className="bg-gradient-to-r from-blue-700 via-indigo-700 to-slate-900 rounded-2xl p-6 md:p-8 text-white shadow-md relative overflow-hidden">
                  <div className="relative z-10 space-y-3 max-w-3xl">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-[10px] uppercase font-mono tracking-wider bg-white/20 px-2.5 py-0.5 rounded-full inline-block font-extrabold">
                        Undergraduate 3-Year Computer Applications Degree
                      </span>
                      <span className="text-[10px] bg-emerald-400 text-slate-950 font-bold px-2.5 py-0.5 rounded-full">
                        AKTU & State University Syllabus
                      </span>
                      <span className="text-[10px] bg-white/10 px-2 py-0.5 rounded-full font-mono">
                        6 Semesters Covered
                      </span>
                    </div>

                    <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold tracking-tight">
                      BCA Academic Portal & Study Library
                    </h2>
                    
                    <p className="text-xs sm:text-sm text-blue-100 font-sans leading-relaxed">
                      Complete study ecosystem for BCA scholars: hand-written unit notes, solved programming labs (C, C++, Data Structures, Java, Python, Web Tech), university PYQ exam papers, solved quantum booklets, and capstone project guidelines.
                    </p>

                    <div className="flex flex-wrap gap-2 pt-1">
                      <button 
                        onClick={() => { setBcaCategoryFilter("notes"); setBcaSemesterFilter("All"); }}
                        className="px-3 py-1.5 bg-white/10 hover:bg-white/20 rounded-lg text-xs font-bold backdrop-blur-sm transition-all flex items-center gap-1.5"
                      >
                        <BookOpen className="w-3.5 h-3.5" /> All BCA Notes ({notes.filter(n => n.branch.toLowerCase().includes("bca") && n.category === "notes").length})
                      </button>
                      <button 
                        onClick={() => { setBcaCategoryFilter("pyq"); setBcaSemesterFilter("All"); }}
                        className="px-3 py-1.5 bg-white/10 hover:bg-white/20 rounded-lg text-xs font-bold backdrop-blur-sm transition-all flex items-center gap-1.5"
                      >
                        <FileText className="w-3.5 h-3.5" /> Solved PYQs
                      </button>
                      <button 
                        onClick={() => { setBcaCategoryFilter("quantum"); setBcaSemesterFilter("All"); }}
                        className="px-3 py-1.5 bg-white/10 hover:bg-white/20 rounded-lg text-xs font-bold backdrop-blur-sm transition-all flex items-center gap-1.5"
                      >
                        <Award className="w-3.5 h-3.5" /> Solved Quantum
                      </button>
                      <button 
                        onClick={() => setActiveTab("jobs")}
                        className="px-3.5 py-1.5 bg-amber-400 hover:bg-amber-300 text-slate-950 rounded-lg text-xs font-extrabold transition-all shadow-sm flex items-center gap-1"
                      >
                        <Briefcase className="w-3.5 h-3.5" /> BCA Freshers Jobs ({jobs.length})
                      </button>
                    </div>
                  </div>
                  <Laptop className="absolute right-4 bottom-2 opacity-10 w-56 h-56 pointer-events-none" />
                </div>

                {/* BCA Quick Career & Practical Launchers */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div 
                    onClick={() => { setBcaCategoryFilter("notes"); setBcaSemesterFilter("Sem 1"); }}
                    className="bg-white border border-slate-200 p-4 rounded-xl shadow-sm hover:border-blue-600 hover:shadow-md cursor-pointer transition-all"
                  >
                    <span className="text-2xl block mb-2">💻</span>
                    <h4 className="font-extrabold text-xs text-slate-900">C & C++ Programming Lab</h4>
                    <p className="text-[11px] text-slate-500 mt-0.5">Top 50 algorithm codes, pointers, files, and solved exercises.</p>
                    <span className="text-[10px] font-bold text-blue-600 mt-2 block">Sem 1 & 2 Handouts →</span>
                  </div>

                  <div 
                    onClick={() => { setBcaCategoryFilter("notes"); setBcaSemesterFilter("Sem 3"); }}
                    className="bg-white border border-slate-200 p-4 rounded-xl shadow-sm hover:border-blue-600 hover:shadow-md cursor-pointer transition-all"
                  >
                    <span className="text-2xl block mb-2">🗄️</span>
                    <h4 className="font-extrabold text-xs text-slate-900">DBMS & SQL 50 Queries</h4>
                    <p className="text-[11px] text-slate-500 mt-0.5">Normalization, Joins, ER Diagrams, and solved lab tests.</p>
                    <span className="text-[10px] font-bold text-blue-600 mt-2 block">Sem 3 Notes & Queries →</span>
                  </div>

                  <div 
                    onClick={() => { setBcaCategoryFilter("pyq"); setBcaSemesterFilter("All"); }}
                    className="bg-white border border-slate-200 p-4 rounded-xl shadow-sm hover:border-blue-600 hover:shadow-md cursor-pointer transition-all"
                  >
                    <span className="text-2xl block mb-2">📄</span>
                    <h4 className="font-extrabold text-xs text-slate-900">5-Year Solved Exam Papers</h4>
                    <p className="text-[11px] text-slate-500 mt-0.5">Model university question banks with step-by-step marking schemes.</p>
                    <span className="text-[10px] font-bold text-blue-600 mt-2 block">University PYQ Bank →</span>
                  </div>

                  <div 
                    onClick={() => setActiveTab("jobs")}
                    className="bg-white border border-slate-200 p-4 rounded-xl shadow-sm hover:border-blue-600 hover:shadow-md cursor-pointer transition-all"
                  >
                    <span className="text-2xl block mb-2">🚀</span>
                    <h4 className="font-extrabold text-xs text-slate-900">BCA Placement Pipeline</h4>
                    <p className="text-[11px] text-slate-500 mt-0.5">Wipro WILP, TCS Smart Hiring, Infosys, and Startup positions.</p>
                    <span className="text-[10px] font-bold text-blue-600 mt-2 block">Explore BCA Careers →</span>
                  </div>
                </div>

                {/* Filter and Semester Toolbar */}
                <div className="bg-white border border-slate-200 p-4 rounded-xl shadow-sm flex flex-col md:flex-row gap-4 justify-between items-center">
                  {/* Semester buttons */}
                  <div className="flex items-center gap-1.5 overflow-x-auto w-full md:w-auto pb-1 md:pb-0">
                    <span className="text-xs font-bold text-slate-700 whitespace-nowrap mr-1 flex items-center gap-1">
                      <GraduationCap className="w-3.5 h-3.5 text-blue-600" /> Sem:
                    </span>
                    {["All", "Sem 1", "Sem 2", "Sem 3", "Sem 4", "Sem 5", "Sem 6"].map(sem => (
                      <button
                        key={sem}
                        onClick={() => setBcaSemesterFilter(sem)}
                        className={`px-3 py-1 text-xs font-extrabold rounded-lg cursor-pointer transition-all whitespace-nowrap ${
                          bcaSemesterFilter === sem
                            ? 'bg-blue-600 text-white shadow-sm'
                            : 'bg-slate-100 text-slate-800 hover:bg-slate-200'
                        }`}
                      >
                        {sem}
                      </button>
                    ))}
                  </div>

                  {/* Category Filter */}
                  <div className="flex items-center gap-1.5 overflow-x-auto w-full md:w-auto">
                    <span className="text-xs font-bold text-slate-700 whitespace-nowrap mr-1 flex items-center gap-1">
                      <Filter className="w-3.5 h-3.5 text-blue-600" /> Filter:
                    </span>
                    {[
                      { id: "all", label: "All Items" },
                      { id: "notes", label: "Notes" },
                      { id: "pyq", label: "PYQs" },
                      { id: "quantum", label: "Quantum" },
                      { id: "syllabus", label: "Syllabus" }
                    ].map(cat => (
                      <button
                        key={cat.id}
                        onClick={() => setBcaCategoryFilter(cat.id)}
                        className={`px-3 py-1 text-xs font-extrabold rounded-lg cursor-pointer transition-all whitespace-nowrap ${
                          bcaCategoryFilter === cat.id
                            ? 'bg-slate-950 text-white shadow-sm'
                            : 'bg-slate-100 text-slate-800 hover:bg-slate-200'
                        }`}
                      >
                        {cat.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* BCA Notes and Material Cards Grid */}
                {(() => {
                  const bcaItems = notes.filter(n => {
                    const isBca = n.branch.toLowerCase().includes("bca");
                    const matchesCategory = bcaCategoryFilter === "all" || n.category === bcaCategoryFilter;
                    const matchesSemester = bcaSemesterFilter === "All" || (n.semester && n.semester.includes(bcaSemesterFilter)) || n.title.includes(bcaSemesterFilter);
                    return isBca && matchesCategory && matchesSemester;
                  });

                  if (bcaItems.length === 0) {
                    return (
                      <div className="text-center py-12 bg-white border border-slate-200 rounded-2xl p-8 space-y-3">
                        <span className="text-4xl block">🔍</span>
                        <h4 className="font-extrabold text-base text-slate-900">No items found matching the selected filters</h4>
                        <p className="text-xs text-slate-500 max-w-sm mx-auto">
                          Try selecting "All" semesters or "All Items" to browse the complete BCA library.
                        </p>
                        <button
                          onClick={() => { setBcaSemesterFilter("All"); setBcaCategoryFilter("all"); }}
                          className="px-4 py-2 bg-blue-600 text-white rounded-lg text-xs font-bold hover:bg-blue-700 transition-all shadow-sm"
                        >
                          Reset Filters
                        </button>
                      </div>
                    );
                  }

                  return (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {bcaItems.map(item => (
                        <div key={item.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between hover:shadow-md hover:border-blue-600 transition-all">
                          <div className="space-y-3">
                            <div className="flex justify-between items-start">
                              <div className="flex items-center gap-2">
                                <span className={`text-[10px] font-mono font-bold uppercase py-0.5 px-2.5 rounded-md ${
                                  item.category === 'quantum' ? 'bg-rose-50 text-rose-700 border border-rose-200' :
                                  item.category === 'pyq' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' :
                                  item.category === 'syllabus' ? 'bg-amber-50 text-amber-700 border border-amber-200' :
                                  'bg-blue-50 text-blue-700 border border-blue-200'
                                }`}>
                                  {item.category === 'quantum' ? '📕 QUANTUM' : item.category === 'pyq' ? '📝 PYQ EXAM' : item.category === 'syllabus' ? '📋 SYLLABUS' : '📘 STUDY NOTE'}
                                </span>
                                {item.semester && (
                                  <span className="text-[10px] font-bold bg-slate-100 text-slate-800 px-2 py-0.5 rounded">
                                    {item.semester}
                                  </span>
                                )}
                              </div>
                              <span className="text-[10px] text-slate-400 font-mono">📥 {item.downloadsCount || 10} hits</span>
                            </div>

                            <div>
                              <h4 className="font-extrabold text-base text-slate-950 leading-snug">{item.title}</h4>
                              <p className="text-xs text-blue-600 font-bold mt-1">Course: {item.subject}</p>
                              {item.units && (
                                <p className="text-[11px] text-slate-500 mt-0.5">Syllabus Scope: {item.units}</p>
                              )}
                            </div>
                          </div>

                          <div className="border-t border-slate-100 pt-4 mt-5 flex justify-between items-center">
                            <span className="text-[10px] font-mono font-bold text-slate-500">
                              By {item.uploadedBy || "Faculty Panel"}
                            </span>
                            <a
                              href={item.downloadUrl}
                              target="_blank"
                              rel="noreferrer"
                              onClick={() => handleDownloadTrigger(item.id)}
                              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all shadow-sm"
                            >
                              <Download className="w-3.5 h-3.5" /> PDF Download
                            </a>
                          </div>
                        </div>
                      ))}
                    </div>
                  );
                })()}

                {/* 3-Year BCA Roadmap Guide */}
                <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-4">
                  <div className="flex items-center gap-2">
                    <Laptop className="w-5 h-5 text-blue-600" />
                    <h3 className="font-extrabold text-base text-slate-900">BCA 3-Year Curriculum & Subject Roadmap (AKTU & UGC)</h3>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 text-xs">
                    <div className="bg-slate-50 p-4 rounded-xl border border-slate-150">
                      <span className="font-extrabold text-blue-600 block mb-1">Year 1 (Sem 1 & 2)</span>
                      <p className="text-slate-700 leading-relaxed">
                        • C Programming & Problem Solving<br />
                        • Computer Fundamentals & Digital Electronics<br />
                        • Discrete Mathematics & Calculus<br />
                        • Data Structures Using C/C++
                      </p>
                    </div>
                    <div className="bg-slate-50 p-4 rounded-xl border border-slate-150">
                      <span className="font-extrabold text-blue-600 block mb-1">Year 2 (Sem 3 & 4)</span>
                      <p className="text-slate-700 leading-relaxed">
                        • Database Management Systems (SQL)<br />
                        • Computer Networks & OSI Model<br />
                        • Java & Object Oriented Design<br />
                        • Web Technologies (HTML5/CSS/JS/PHP)
                      </p>
                    </div>
                    <div className="bg-slate-50 p-4 rounded-xl border border-slate-150">
                      <span className="font-extrabold text-blue-600 block mb-1">Year 3 (Sem 5 & 6)</span>
                      <p className="text-slate-700 leading-relaxed">
                        • Python for Data & Automation<br />
                        • Software Engineering & Agile Testing<br />
                        • Cloud Computing & Virtualization<br />
                        • Major Industry Capstone Project
                      </p>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* ------------------------------------------------------------- */}
            {/* TAB: B.TECH CSE / ENGINEERING ZONE */}
            {/* ------------------------------------------------------------- */}
            {activeTab === "btech" && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
                <div className="bg-gradient-to-r from-blue-700 to-indigo-800 rounded-2xl p-6 text-white shadow-md relative overflow-hidden">
                  <div className="relative z-10 space-y-2">
                    <span className="text-[10px] uppercase font-mono tracking-wider bg-white/20 px-2.5 py-0.5 rounded-full inline-block font-bold">AKTU Affiliated Engineering</span>
                    <h2 className="text-2xl sm:text-3xl font-bold tracking-tight">B.Tech Corporate Curriculum Zone</h2>
                    <p className="text-xs text-indigo-100 max-w-xl">Accelerate engineering preparation with semester sorted notebooks, official syllabus indices, reference books, and resolved exam questions.</p>
                  </div>
                  <GraduationCap className="absolute right-4 bottom-2 opacity-10 w-44 h-44" />
                </div>

                {/* Sub Filters */}
                <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-white/5 p-4 rounded-xl flex flex-col sm:flex-row gap-4 items-center justify-between shadow-sm">
                  <div className="flex items-center gap-2 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0 font-sans">
                    <span className="text-xs font-bold text-slate-500 whitespace-nowrap">Semesters:</span>
                    {["All", "Sem 1", "Sem 2", "Sem 3", "Sem 4", "Sem 5", "Sem 6", "Sem 7", "Sem 8"].map(sem => (
                      <button
                        key={sem}
                        onClick={() => {
                          // Filter simulated via internal state or search query
                          setSearchQuery(sem === "All" ? "" : sem);
                        }}
                        className={`px-2.5 py-1 text-xs font-semibold rounded cursor-pointer transition-all ${
                          searchQuery === sem || (sem === "All" && !searchQuery)
                            ? 'bg-blue-600 text-white'
                            : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-350 hover:bg-slate-200'
                        }`}
                      >
                        {sem}
                      </button>
                    ))}
                  </div>
                  <div className="text-xs text-slate-500 font-medium">B.Tech Engineering: B.Tech CSE</div>
                </div>

                {/* Grid items */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {notes.filter(n => n.branch.toLowerCase().includes("b.tech") || n.branch.toLowerCase().includes("computer")).map(item => (
                    <div key={item.id} className="bg-white dark:bg-slate-950 p-5 rounded-2xl border border-slate-150 dark:border-white/5 flex flex-col justify-between hover:shadow-md transition-all">
                      <div className="space-y-3">
                        <div className="flex justify-between items-start">
                          <span className="text-[10px] font-mono font-bold uppercase py-0.5 px-2 bg-blue-50 dark:bg-blue-950 text-blue-600 dark:text-blue-400 rounded-md">
                            {item.category}
                          </span>
                          <span className="text-[10px] text-slate-400 font-mono">📥 {item.downloadsCount || 0} hits</span>
                        </div>
                        <div>
                          <h4 className="font-bold text-base text-slate-900 dark:text-white">{item.title}</h4>
                          <p className="text-xs text-slate-500 mt-1">Course: {item.subject}</p>
                        </div>
                      </div>
                      <div className="border-t border-slate-100 dark:border-white/5 pt-4 mt-5 flex justify-between items-center">
                        <span className="text-[10px] font-mono text-slate-500">{item.branch}</span>
                        <a
                          href={item.downloadUrl} target="_blank" rel="noreferrer" onClick={() => handleDownloadTrigger(item.id)}
                          className="px-3.5 py-1.5 bg-blue-600 text-white rounded-lg text-xs font-bold flex items-center gap-1 hover:bg-blue-700 transition-all shadow-sm"
                        >
                          <Download className="w-3.5 h-3.5" /> PDF Download
                        </a>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {/* ------------------------------------------------------------- */}
            {/* TAB: MCA COMPUTER APPLICATION ZONE */}
            {/* ------------------------------------------------------------- */}
            {activeTab === "mca" && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
                <div className="bg-gradient-to-r from-teal-700 via-emerald-800 to-emerald-950 rounded-2xl p-6 text-white shadow-md relative overflow-hidden">
                  <div className="relative z-10 space-y-2">
                    <span className="text-[10px] uppercase font-mono tracking-wider bg-white/20 px-2.5 py-0.5 rounded-full inline-block font-bold">Postgraduate Applications</span>
                    <h2 className="text-2xl sm:text-3xl font-bold tracking-tight">MCA Solved Library Portal</h2>
                    <p className="text-xs text-teal-100 max-w-xl font-sans">Acquire verified unit notes, object-oriented concepts, previous examinations, and software engineering books for the MCA degree.</p>
                  </div>
                  <Database className="absolute right-4 bottom-2 opacity-15 w-44 h-44" />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {notes.filter(n => n.branch.toLowerCase().includes("mca")).map(item => (
                    <div key={item.id} className="bg-white dark:bg-slate-950 p-5 rounded-2xl border border-slate-150 dark:border-white/5 flex flex-col justify-between hover:shadow-md transition-colors">
                      <div className="space-y-3">
                        <div className="flex justify-between items-start">
                          <span className="text-[10px] font-mono font-bold uppercase py-0.5 px-2 bg-teal-50 dark:bg-teal-950 text-teal-600 dark:text-teal-400 rounded-md">
                            {item.category}
                          </span>
                          <span className="text-[10px] text-slate-400 font-mono">📥 {item.downloadsCount || 0} hits</span>
                        </div>
                        <div>
                          <h4 className="font-bold text-base text-slate-900 dark:text-white">{item.title}</h4>
                          <p className="text-xs text-slate-500 mt-1">Course: {item.subject}</p>
                        </div>
                      </div>
                      <div className="border-t border-slate-100 dark:border-white/5 pt-4 mt-5 flex justify-between items-center">
                        <span className="text-[10px] font-mono text-slate-500">{item.branch}</span>
                        <a
                          href={item.downloadUrl} target="_blank" rel="noreferrer" onClick={() => handleDownloadTrigger(item.id)}
                          className="px-3.5 py-1.5 bg-teal-600 text-white rounded-lg text-xs font-bold flex items-center gap-1 hover:bg-teal-700 transition-all shadow-sm"
                        >
                          <Download className="w-3.5 h-3.5" /> PDF Download
                        </a>
                      </div>
                    </div>
                  ))}
                  {notes.filter(n => n.branch.toLowerCase().includes("mca")).length === 0 && (
                    <div className="col-span-2 text-center py-12 bg-white dark:bg-slate-900 border border-slate-150 dark:border-white/5 rounded-2xl text-slate-500">
                      Uploading latest MCA material listings. Check back shortly.
                    </div>
                  )}
                </div>
              </motion.div>
            )}

            {/* ------------------------------------------------------------- */}
            {/* TAB: MBA BUSINESS ZONE */}
            {/* ------------------------------------------------------------- */}
            {activeTab === "mba" && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
                <div className="bg-gradient-to-r from-purple-700 to-indigo-900 rounded-2xl p-6 text-white shadow-md relative overflow-hidden">
                  <div className="relative z-10 space-y-2">
                    <span className="text-[10px] uppercase font-mono tracking-wider bg-white/20 px-2.5 py-0.5 rounded-full inline-block font-bold">Business Management</span>
                    <h2 className="text-2xl sm:text-3xl font-bold tracking-tight">MBA Academic Masterclass</h2>
                    <p className="text-xs text-purple-100 max-w-xl">Succeed in MBA examinations with manager economics, strategy cases, business law summaries, and premium textbook guide units.</p>
                  </div>
                  <Briefcase className="absolute right-4 bottom-2 opacity-15 w-44 h-44" />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {notes.filter(n => n.branch.toLowerCase().includes("mba")).map(item => (
                    <div key={item.id} className="bg-white dark:bg-slate-950 p-5 rounded-2xl border border-slate-150 dark:border-white/5 flex flex-col justify-between hover:shadow-md transition-colors">
                      <div className="space-y-3">
                        <div className="flex justify-between items-start">
                          <span className="text-[10px] font-mono font-bold uppercase py-0.5 px-2 bg-purple-50 dark:bg-purple-950 text-purple-600 dark:text-purple-400 rounded-md">
                            {item.category}
                          </span>
                          <span className="text-[10px] text-slate-400 font-mono">📥 {item.downloadsCount || 0} hits</span>
                        </div>
                        <div>
                          <h4 className="font-bold text-base text-slate-900 dark:text-white">{item.title}</h4>
                          <p className="text-xs text-slate-500 mt-1">Course: {item.subject}</p>
                        </div>
                      </div>
                      <div className="border-t border-slate-100 dark:border-white/5 pt-4 mt-5 flex justify-between items-center">
                        <span className="text-[10px] font-mono text-slate-500">{item.branch}</span>
                        <a
                          href={item.downloadUrl} target="_blank" rel="noreferrer" onClick={() => handleDownloadTrigger(item.id)}
                          className="px-3.5 py-1.5 bg-purple-600 text-white rounded-lg text-xs font-bold flex items-center gap-1 hover:bg-purple-700 transition-all shadow-sm"
                        >
                          <Download className="w-3.5 h-3.5" /> PDF Download
                        </a>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {/* ------------------------------------------------------------- */}
            {/* TAB: B.PHARM PHARMACY ZONE */}
            {/* ------------------------------------------------------------- */}
            {activeTab === "bpharm" && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
                <div className="bg-gradient-to-r from-emerald-600 via-teal-700 to-indigo-900 rounded-xl p-6 text-white shadow-md relative overflow-hidden">
                  <div className="relative z-10 space-y-2">
                    <span className="text-[10px] uppercase font-mono tracking-wider bg-white/20 px-2.5 py-0.5 rounded-full inline-block font-bold">Pharmaceutical Sciences</span>
                    <h2 className="text-2xl sm:text-3xl font-bold tracking-tight">B.Pharm Pharmacology Portal</h2>
                    <p className="text-xs text-emerald-100 max-w-xl font-sans">Access pharmaceutical notes, pharmacology solved guides, anatomy references, and previous semester chemistry question models.</p>
                  </div>
                  <Activity className="absolute right-4 bottom-2 opacity-15 w-44 h-44" />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {notes.filter(n => n.branch.toLowerCase().includes("pharm") || n.branch.toLowerCase().includes("b.pharm")).map(item => (
                    <div key={item.id} className="bg-white dark:bg-slate-950 p-5 rounded-2xl border border-slate-150 dark:border-white/5 flex flex-col justify-between hover:shadow-md transition-colors">
                      <div className="space-y-3">
                        <div className="flex justify-between items-start">
                          <span className="text-[10px] font-mono font-bold uppercase py-0.5 px-2 bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 rounded-md">
                            {item.category}
                          </span>
                          <span className="text-[10px] text-slate-400 font-mono">📥 {item.downloadsCount || 0} hits</span>
                        </div>
                        <div>
                          <h4 className="font-bold text-base text-slate-900 dark:text-white">{item.title}</h4>
                          <p className="text-xs text-slate-500 mt-1">Course: {item.subject}</p>
                        </div>
                      </div>
                      <div className="border-t border-slate-100 dark:border-white/5 pt-4 mt-5 flex justify-between items-center">
                        <span className="text-[10px] font-mono text-slate-500">{item.branch}</span>
                        <a
                          href={item.downloadUrl} target="_blank" rel="noreferrer" onClick={() => handleDownloadTrigger(item.id)}
                          className="px-3.5 py-1.5 bg-emerald-600 text-white rounded-lg text-xs font-bold flex items-center gap-1 hover:bg-emerald-700 transition-all shadow-sm"
                        >
                          <Download className="w-3.5 h-3.5" /> PDF Download
                        </a>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {/* ------------------------------------------------------------- */}
            {/* TAB: NEWS & INTERACTIVE UNIVERSITY NOTICES HUB */}
            {/* ------------------------------------------------------------- */}
            {activeTab === "news" && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-8">
                <div>
                  <h2 className="text-2xl sm:text-3xl font-display font-medium text-slate-900 dark:text-white flex items-center gap-2">
                    <Newspaper className="w-7 h-7 text-blue-600" /> AKTU Notices & Student News Desk
                  </h2>
                  <p className="text-xs text-slate-500 mt-1">Real-time college dispatches, evaluation guidelines, and circulars updated directly from academic divisions.</p>
                </div>

                {/* HIGHLIGHTED: AKTU Notice 2026 Poster Card */}
                {blogs.filter(b => b.category === "notice" || b.title.includes("UFM")).map(notice => (
                  <div key={notice.id} className="bg-amber-50/50 dark:bg-slate-950/40 border border-amber-200 dark:border-amber-900/40 rounded-2xl p-6 shadow-sm flex flex-col md:flex-row gap-6 items-start relative overflow-hidden transition-all hover:border-amber-400">
                    <div className="absolute right-0 top-0 bg-amber-500 text-white px-4 py-1 text-[10px] uppercase tracking-wider font-extrabold rounded-bl-xl shadow flex items-center gap-1">
                      <AlertTriangle className="w-3 h-3 animate-pulse" /> Critical Alert
                    </div>

                    <img src={notice.imageUrl} alt={notice.title} className="w-full md:w-56 h-40 object-cover rounded-xl border border-amber-200/50" referrerPolicy="no-referrer" />
                    
                    <div className="space-y-3.5 flex-1">
                      <div className="flex flex-wrap items-center gap-3 text-[11px] text-slate-500 font-semibold font-mono">
                        <span className="bg-amber-500/10 text-amber-800 dark:text-amber-300 px-2 py-0.5 rounded-full">{notice.category?.toUpperCase() || "OFFICIAL"}</span>
                        <span>Date: June 02, 2026</span>
                        <span>Official Letter No: {notice.officialsLetterNo || "N/A"}</span>
                      </div>

                      <h3 className="text-xl font-extrabold text-slate-900 dark:text-amber-100 leading-tight">
                        {notice.title}
                      </h3>
                      
                      <p className="text-xs text-slate-600 dark:text-slate-350 leading-relaxed font-sans line-clamp-3">
                        {notice.summary}
                      </p>

                      <div className="flex items-center gap-3 pt-2">
                        <button
                          onClick={() => setSelectedBlog(notice)}
                          className="px-5 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold transition-all shadow-sm cursor-pointer"
                        >
                          Read Notice Details & हिंदी पत्र निर्देश
                        </button>
                        <span className="text-[10px] text-slate-500">By <strong>{notice.author}</strong> (University Coordinator)</span>
                      </div>
                    </div>
                  </div>
                ))}

                {/* Secondary list of notifications */}
                <div className="space-y-4">
                  <h3 className="font-bold text-slate-800 dark:text-slate-200 text-sm">Latest Digital Notice Board (2026)</h3>
                  {[
                    { title: "AKTU Even Semester Examination Scheduling Notice 2026", details: "Registration link active for regular/carry-over applications for engineering cycles.", date: "June 05, 2026", num: "ए.के.टी.यू./प.नि.का./2026/8949" },
                    { title: "UP Postmatrix Scholarship Student Portal Timeline Extended", details: "Mandatory Aadhaar linking and attendance threshold guidelines updated.", date: "May 28, 2026", num: "छात्र.वि./स.क./223-26" },
                    { title: "Admit Card Verification dispatch instructions to affiliated campuses", details: "Directors requested to clear system dues and cross-verify student registers.", date: "May 20, 2026", num: "ए.के.टी.यू./कुलस.का./2026/1129" }
                  ].map((not, idx) => (
                    <div key={idx} className="bg-white dark:bg-slate-950 p-4 rounded-xl border border-slate-150 dark:border-white/5 flex justify-between items-center gap-4 hover:border-blue-500 transition-colors">
                      <div className="space-y-1">
                        <span className="text-[9px] font-mono font-bold text-blue-600 bg-blue-50 dark:bg-blue-950/50 px-2 py-0.5 rounded">{not.num}</span>
                        <h4 className="font-bold text-xs text-slate-900 dark:text-white mt-1">{not.title}</h4>
                        <p className="text-[11px] text-slate-500">{not.details}</p>
                      </div>
                      <div className="text-right whitespace-nowrap">
                        <span className="text-[10px] text-slate-400 font-mono font-medium block">{not.date}</span>
                        <button onClick={() => alert(`Notice Reference: ${not.num}\n\n${not.title}\n\nStatus: Official dispatched copy with physical signature verified on original college portal.`)} className="text-[11px] text-blue-600 font-bold hover:underline mt-1 block">View</button>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {/* ------------------------------------------------------------- */}
            {/* TAB: PYQS PREVIOUS YEARS PAPERS ZONE */}
            {/* ------------------------------------------------------------- */}
            {activeTab === "pyqs" && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <h2 className="text-2xl sm:text-3xl font-display font-medium text-slate-900">
                      Previous Year Question Papers Hub (PYQs)
                    </h2>
                    <p className="text-xs text-slate-500 mt-1">Official AKTU/Board question model blueprints and answers solved by university gold medalists.</p>
                  </div>
                  {/* Branch Filter Tabs */}
                  <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                    <span className="text-xs font-bold text-slate-700 whitespace-nowrap mr-1">Stream:</span>
                    {["All", "BCA", "B.Tech", "MCA", "MBA", "B.Pharm"].map(br => (
                      <button
                        key={br}
                        onClick={() => setNotesBranchFilter(br)}
                        className={`px-3 py-1 text-xs font-bold rounded-lg cursor-pointer transition-all ${
                          notesBranchFilter === br ? 'bg-blue-600 text-white shadow-sm' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                        }`}
                      >
                        {br}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {notes.filter(n => {
                    const matchesCat = n.category === "pyq";
                    const matchesBr = notesBranchFilter === "All" || n.branch.toLowerCase().includes(notesBranchFilter.toLowerCase());
                    return matchesCat && matchesBr;
                  }).map(item => (
                    <div key={item.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between hover:shadow-md transition-shadow">
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <span className="inline-block text-[9px] text-emerald-700 font-bold font-mono px-2 py-0.5 bg-emerald-50 border border-emerald-200 rounded uppercase">AKTU PYQ MODEL</span>
                          <span className="text-[10px] text-slate-400 font-mono">📥 {item.downloadsCount || 0} hits</span>
                        </div>
                        <div>
                          <h4 className="font-bold text-sm text-slate-900">{item.title}</h4>
                          <span className="text-xs text-slate-500 font-medium block mt-1">Course: {item.subject}</span>
                        </div>
                      </div>
                      <div className="border-t border-slate-100 pt-4 mt-5 flex justify-between items-center">
                        <span className="text-[10px] font-mono text-slate-500 font-bold">{item.branch}</span>
                        <a
                          href={item.downloadUrl} target="_blank" rel="noreferrer" onClick={() => handleDownloadTrigger(item.id)}
                          className="px-3.5 py-1.5 bg-slate-900 hover:bg-emerald-600 text-white rounded-lg text-xs font-bold flex items-center gap-1 transition-all shadow-sm"
                        >
                          <Download className="w-3.5 h-3.5" /> Fast Download
                        </a>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {/* ------------------------------------------------------------- */}
            {/* TAB: AKTU QUANTUM SERIOUS SOLVED BOOKSHELF */}
            {/* ------------------------------------------------------------- */}
            {activeTab === "quantum" && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-8">
                <div className="bg-gradient-to-r from-red-800 to-rose-950 rounded-2xl p-6 text-white shadow-md relative overflow-hidden">
                  <div className="relative z-10 space-y-2">
                    <span className="text-[10px] uppercase font-mono tracking-wider bg-white/20 px-2.5 py-0.5 rounded-full inline-block font-bold">AKTU Last-Night Resource</span>
                    <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">AKTU Solved Quantum Series</h2>
                    <p className="text-xs text-rose-100 max-w-xl font-sans">The undisputed textbook companion. Comprehensive unit solved questions, exam-oriented frameworks, and concise chapter guides.</p>
                  </div>
                  <BookOpen className="absolute right-4 bottom-2 opacity-10 w-44 h-44 pointer-events-none" />
                </div>

                {/* Branch selector */}
                <div className="flex items-center gap-1.5 overflow-x-auto pb-1 bg-white p-3 rounded-xl border border-slate-200">
                  <span className="text-xs font-bold text-slate-700 whitespace-nowrap mr-1">Filter by Branch:</span>
                  {["All", "BCA", "B.Tech", "MCA", "MBA", "B.Pharm"].map(br => (
                    <button
                      key={br}
                      onClick={() => setNotesBranchFilter(br)}
                      className={`px-3 py-1 text-xs font-bold rounded-lg cursor-pointer transition-all ${
                        notesBranchFilter === br ? 'bg-rose-600 text-white shadow-sm' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                      }`}
                    >
                      {br}
                    </button>
                  ))}
                </div>

                {/* Bookshelf Shelf design */}
                <div className="bg-slate-50 p-6 rounded-3xl border border-slate-200 shadow-inner">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                    {notes.filter(n => {
                      const matchesCat = n.category === "quantum";
                      const matchesBr = notesBranchFilter === "All" || n.branch.toLowerCase().includes(notesBranchFilter.toLowerCase());
                      return matchesCat && matchesBr;
                    }).map((book, idx) => {
                      const colors = [
                        "from-rose-600 to-rose-900",
                        "from-blue-600 to-indigo-900",
                        "from-teal-600 to-emerald-900",
                        "from-amber-600 to-red-800",
                        "from-purple-600 to-indigo-950"
                      ];
                      const chosenColor = colors[idx % colors.length];

                      return (
                        <div key={book.id} className="group relative flex flex-col justify-between bg-white p-4 rounded-2xl border border-slate-200 hover:translate-y-[-4px] hover:shadow-xl transition-all">
                          {/* 3D-Look Hardcover Book Panel */}
                          <div className={`w-full aspect-[3/4] rounded-lg bg-gradient-to-br ${chosenColor} p-4 text-white relative shadow-md overflow-hidden flex flex-col justify-between group-hover:scale-[1.02] transition-transform`}>
                            <div className="absolute left-0 top-0 bottom-0 w-2.5 bg-black/20 shadow-r" />
                            
                            <div className="space-y-1 pl-2.5">
                              <span className="text-[8px] bg-white/25 px-1.5 py-0.5 rounded uppercase font-mono tracking-widest font-extrabold inline-block">QUANTUM SERIES</span>
                              <h4 className="text-sm font-extrabold tracking-tight line-clamp-3 font-serif mt-1">{book.subject}</h4>
                            </div>

                            <div className="pl-2.5 space-y-1.5 border-t border-white/20 pt-2">
                              <p className="text-[9px] font-mono text-white/80 uppercase font-semibold">{book.branch}</p>
                              <div className="flex justify-between items-center text-[8px] text-white/60">
                                <span>Verified Copy</span>
                                <span className="font-bold bg-white/10 px-1 py-0.5 rounded text-white font-sans">Sem {idx * 2 + 1 || 4}</span>
                              </div>
                            </div>
                          </div>

                          {/* Info area below book */}
                          <div className="mt-4 space-y-2 flex-1 flex flex-col justify-between">
                            <div>
                              <h5 className="font-extrabold text-xs text-slate-900 line-clamp-2">{book.title}</h5>
                              <div className="flex justify-between items-center text-[10px] text-slate-500 font-semibold font-mono mt-2">
                                <span>📥 {book.downloadsCount || 10} downloads</span>
                                <span className="text-rose-600 font-bold">Free PDF</span>
                              </div>
                            </div>

                            <a
                              href={book.downloadUrl}
                              target="_blank" rel="noreferrer" onClick={() => handleDownloadTrigger(book.id)}
                              className="w-full mt-3 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-[10px] font-extrabold text-center block shadow transition-all"
                            >
                              Download Solved PDF
                            </a>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </motion.div>
            )}

            {/* ------------------------------------------------------------- */}
            {/* TAB: NOTES ONLY */}
            {/* ------------------------------------------------------------- */}
            {activeTab === "notes_category" && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <h2 className="text-2xl sm:text-3xl font-display font-medium text-slate-900">
                      Class Notes & Lecture Slides
                    </h2>
                    <p className="text-xs text-slate-500 mt-1">Chapter wise handwritten outlines, slides, and cheatcards compiled by top scholars across all streams.</p>
                  </div>
                  {/* Branch Filter Tabs */}
                  <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                    <span className="text-xs font-bold text-slate-700 whitespace-nowrap mr-1">Stream:</span>
                    {["All", "BCA", "B.Tech", "MCA", "MBA", "B.Pharm"].map(br => (
                      <button
                        key={br}
                        onClick={() => setNotesBranchFilter(br)}
                        className={`px-3 py-1 text-xs font-bold rounded-lg cursor-pointer transition-all ${
                          notesBranchFilter === br ? 'bg-blue-600 text-white shadow-sm' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                        }`}
                      >
                        {br}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {notes.filter(n => {
                    const matchesCat = n.category === "notes";
                    const matchesBr = notesBranchFilter === "All" || n.branch.toLowerCase().includes(notesBranchFilter.toLowerCase());
                    return matchesCat && matchesBr;
                  }).map(item => (
                    <div key={item.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between hover:shadow-md transition-shadow">
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <span className="inline-block text-[9px] text-blue-700 font-bold font-mono px-2 py-0.5 bg-blue-50 border border-blue-200 rounded uppercase">SCHOLAR NOTES</span>
                          <span className="text-[10px] text-slate-400 font-mono">📥 {item.downloadsCount || 0} hits</span>
                        </div>
                        <div>
                          <h4 className="font-bold text-sm text-slate-900">{item.title}</h4>
                          <span className="text-xs text-slate-500 font-medium block mt-1">Designation: {item.subject}</span>
                        </div>
                      </div>
                      <div className="border-t border-slate-100 pt-4 mt-5 flex justify-between items-center">
                        <span className="text-[10px] font-mono text-slate-500 font-bold">{item.branch}</span>
                        <a
                          href={item.downloadUrl} target="_blank" rel="noreferrer" onClick={() => handleDownloadTrigger(item.id)}
                          className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold flex items-center gap-1 transition-all shadow-sm"
                        >
                          <Download className="w-3.5 h-3.5" /> PDF Download
                        </a>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {/* ------------------------------------------------------------- */}
            {/* TAB: SYLLABUS ONLY */}
            {/* ------------------------------------------------------------- */}
            {activeTab === "syllabus_category" && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <h2 className="text-2xl sm:text-3xl font-display font-medium text-slate-900">
                      Official Course Syllabi Blueprints
                    </h2>
                    <p className="text-xs text-slate-500 mt-1">The fundamental evaluation registers issued directly by state universities for BCA, BTech, MCA, MBA, and Pharmacy.</p>
                  </div>
                  {/* Branch Filter Tabs */}
                  <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                    <span className="text-xs font-bold text-slate-700 whitespace-nowrap mr-1">Stream:</span>
                    {["All", "BCA", "B.Tech", "MCA", "MBA", "B.Pharm"].map(br => (
                      <button
                        key={br}
                        onClick={() => setNotesBranchFilter(br)}
                        className={`px-3 py-1 text-xs font-bold rounded-lg cursor-pointer transition-all ${
                          notesBranchFilter === br ? 'bg-amber-600 text-white shadow-sm' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                        }`}
                      >
                        {br}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {notes.filter(n => {
                    const matchesCat = n.category === "syllabus";
                    const matchesBr = notesBranchFilter === "All" || n.branch.toLowerCase().includes(notesBranchFilter.toLowerCase());
                    return matchesCat && matchesBr;
                  }).map(item => (
                    <div key={item.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between hover:shadow-md transition-shadow">
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <span className="inline-block text-[9px] text-amber-700 font-bold font-mono px-2 py-0.5 bg-amber-50 border border-amber-200 rounded uppercase">UNIVERSITY SPEC</span>
                          <span className="text-[10px] text-slate-400 font-mono">📥 {item.downloadsCount || 0} hits</span>
                        </div>
                        <div>
                          <h4 className="font-bold text-sm text-slate-900">{item.title}</h4>
                          <span className="text-xs text-slate-500 font-medium block mt-1">Designation: {item.subject}</span>
                        </div>
                      </div>
                      <div className="border-t border-slate-100 pt-4 mt-5 flex justify-between items-center">
                        <span className="text-[10px] font-mono text-slate-500 font-bold">{item.branch}</span>
                        <a
                          href={item.downloadUrl} target="_blank" rel="noreferrer" onClick={() => handleDownloadTrigger(item.id)}
                          className="px-3.5 py-1.5 bg-slate-900 hover:bg-amber-600 text-white rounded-lg text-xs font-bold flex items-center gap-1 transition-all shadow-sm"
                        >
                          <Download className="w-3.5 h-3.5" /> PDF Download
                        </a>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {/* ------------------------------------------------------------- */}
            {/* TAB: JOBS & CAREERS COMBINED HUB */}
            {/* ------------------------------------------------------------- */}
            {(activeTab === "jobs" || activeTab === "placement" || activeTab === "internships") && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-8">
                {/* Hero Header */}
                <div className="bg-gradient-to-r from-blue-700 via-indigo-800 to-slate-900 rounded-2xl p-6 md:p-8 text-white shadow-md relative overflow-hidden">
                  <div className="space-y-3 relative z-10 max-w-2xl">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-[10px] uppercase font-mono tracking-wider bg-white/20 px-2.5 py-0.5 rounded-full inline-block font-extrabold">
                        Verified Placement Pipeline
                      </span>
                      <span className="text-[10px] bg-emerald-400 text-slate-950 font-bold px-2 py-0.5 rounded-full">
                        Freshers & Students (2025/2026)
                      </span>
                      <span className="text-[10px] bg-white/10 px-2 py-0.5 rounded-full font-mono">
                        {jobs.length + internships.length} Opportunities
                      </span>
                    </div>

                    <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold tracking-tight">
                      Tech Job Opportunities & Campus Hiring
                    </h2>
                    
                    <p className="text-xs sm:text-sm text-blue-100 max-w-xl leading-relaxed">
                      Handpicked careers and internships across leading technological companies (Google, Microsoft, Amazon, Stripe, Zomato, TCS, Infosys, and high-growth startups) eligible for BCA, B.Tech, and MCA graduates.
                    </p>

                    <div className="flex flex-wrap gap-2 pt-1">
                      <button 
                        onClick={() => setJobTypeFilter("all")}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${jobTypeFilter === "all" ? 'bg-white text-slate-900 shadow' : 'bg-white/10 hover:bg-white/20 text-white'}`}
                      >
                        All Opportunities ({jobs.length + internships.length})
                      </button>
                      <button 
                        onClick={() => setJobTypeFilter("jobs")}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${jobTypeFilter === "jobs" ? 'bg-white text-slate-900 shadow' : 'bg-white/10 hover:bg-white/20 text-white'}`}
                      >
                        Full-Time Jobs ({jobs.length})
                      </button>
                      <button 
                        onClick={() => setJobTypeFilter("internships")}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${jobTypeFilter === "internships" ? 'bg-white text-slate-900 shadow' : 'bg-white/10 hover:bg-white/20 text-white'}`}
                      >
                        Summer Internships ({internships.length})
                      </button>
                      <button 
                        onClick={() => setJobTypeFilter("bca")}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${jobTypeFilter === "bca" ? 'bg-amber-400 text-slate-950 shadow' : 'bg-white/10 hover:bg-white/20 text-white'}`}
                      >
                        BCA Eligible ({jobs.filter(j => j.eligibility?.includes("BCA")).length + internships.filter(i => i.eligibility?.includes("BCA")).length})
                      </button>
                    </div>
                  </div>
                  <Briefcase className="absolute right-4 bottom-2 opacity-10 w-52 h-52 pointer-events-none" />
                </div>

                {/* Filter and Search Bar */}
                <div className="bg-white border border-slate-200 p-4 rounded-xl shadow-sm flex flex-col md:flex-row gap-4 items-center justify-between">
                  <div className="relative w-full md:max-w-md">
                    <Search className="absolute left-3.5 top-2.5 w-4 h-4 text-slate-400" />
                    <input
                      type="text"
                      placeholder="Search company, skill, role (e.g. Google, Frontend, Python)..."
                      value={jobsSearchTerm}
                      onChange={(e) => setJobsSearchTerm(e.target.value)}
                      className="w-full text-xs pl-10 pr-4 py-2 border border-slate-200 rounded-lg bg-white focus:outline-none focus:border-blue-600 text-slate-900 font-medium"
                    />
                    {jobsSearchTerm && (
                      <button 
                        onClick={() => setJobsSearchTerm("")}
                        className="absolute right-3 top-2 text-xs font-bold text-slate-400 hover:text-slate-600"
                      >
                        ✕
                      </button>
                    )}
                  </div>

                  <div className="flex items-center gap-2 text-xs text-slate-500 font-bold whitespace-nowrap">
                    <span>Showing verified postings with direct application links</span>
                  </div>
                </div>

                {/* Section: Off-Campus Drives & Walk-ins */}
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <div>
                      <h3 className="text-xl font-bold text-slate-900 flex items-center gap-2">
                        <Building className="w-5 h-5 text-blue-600" /> Active Off-Campus Hiring Drives (2026)
                      </h3>
                      <p className="text-xs text-slate-500">Mass hiring programs and national eligibility tests open for registration.</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    {OFF_CAMPUS_DRIVES.map(drive => (
                      <div key={drive.id} className="bg-white border border-slate-200 p-4 rounded-xl shadow-sm hover:border-blue-600 hover:shadow-md transition-all flex flex-col justify-between">
                        <div className="space-y-2">
                          <div className="flex justify-between items-center">
                            <span className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded-full uppercase ${
                              drive.status === 'Active' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' :
                              drive.status === 'Closing Soon' ? 'bg-rose-50 text-rose-700 border border-rose-200' :
                              'bg-amber-50 text-amber-700 border border-amber-200'
                            }`}>
                              ● {drive.status}
                            </span>
                            <span className="text-[10px] text-slate-400 font-mono">{drive.batch}</span>
                          </div>
                          <div>
                            <h4 className="font-extrabold text-sm text-slate-950">{drive.company}</h4>
                            <p className="text-xs text-blue-600 font-bold">{drive.role}</p>
                            <span className="text-[11px] font-mono text-emerald-600 font-bold block mt-1">{drive.package}</span>
                          </div>
                          <p className="text-[10px] text-slate-500">
                            <strong>Eligibility:</strong> {drive.eligibility}
                          </p>
                        </div>
                        <div className="border-t border-slate-100 pt-3 mt-3 flex justify-between items-center">
                          <span className="text-[10px] text-slate-400 font-medium">{drive.deadline}</span>
                          <a
                            href={drive.applyUrl}
                            target="_blank"
                            rel="noreferrer"
                            className="px-3 py-1 bg-slate-900 hover:bg-blue-600 text-white rounded-lg text-xs font-bold transition-all"
                          >
                            Register →
                          </a>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Sub-toggle: Internships vs Jobs columns or combined list */}
                {(() => {
                  const filterQuery = jobsSearchTerm.toLowerCase();

                  const filteredJ = jobs.filter(j => {
                    const matchesSearch = !filterQuery || 
                      j.companyName.toLowerCase().includes(filterQuery) || 
                      j.role.toLowerCase().includes(filterQuery) ||
                      (j.eligibility && j.eligibility.toLowerCase().includes(filterQuery));
                    const matchesType = jobTypeFilter === "all" || jobTypeFilter === "jobs" || (jobTypeFilter === "bca" && j.eligibility?.includes("BCA"));
                    return matchesSearch && matchesType;
                  });

                  const filteredI = internships.filter(i => {
                    const matchesSearch = !filterQuery || 
                      i.companyName.toLowerCase().includes(filterQuery) || 
                      i.title.toLowerCase().includes(filterQuery) ||
                      (i.eligibility && i.eligibility.toLowerCase().includes(filterQuery));
                    const matchesType = jobTypeFilter === "all" || jobTypeFilter === "internships" || (jobTypeFilter === "bca" && i.eligibility?.includes("BCA"));
                    return matchesSearch && matchesType;
                  });

                  return (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      {/* Internships Column */}
                      {(jobTypeFilter === "all" || jobTypeFilter === "internships" || jobTypeFilter === "bca") && (
                        <div className="space-y-4">
                          <h3 className="text-lg font-extrabold text-slate-950 pb-2 border-b border-slate-200 flex justify-between items-center">
                            <span>🌞 Summer Internships ({filteredI.length})</span>
                            <span className="text-xs font-mono font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full">Stipend Verified</span>
                          </h3>
                          <div className="space-y-4">
                            {filteredI.map((item) => (
                              <div key={item.id} className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex flex-col justify-between hover:border-blue-600 hover:shadow-md transition-all">
                                <div className="space-y-3">
                                  <div className="flex justify-between items-center">
                                    <img src={item.logoUrl} alt={item.companyName} className="w-10 h-10 object-cover rounded-xl border border-slate-100" referrerPolicy="no-referrer" />
                                    <div className="flex items-center gap-1.5">
                                      {item.eligibility && (
                                        <span className="text-[9px] font-bold bg-slate-100 text-slate-700 px-2 py-0.5 rounded">
                                          {item.eligibility.split("/")[0]}
                                        </span>
                                      )}
                                      <button onClick={() => toggleBookmark(item.id)} className="p-1.5 hover:bg-slate-50 border border-slate-200 rounded-lg text-slate-400 hover:text-rose-500 cursor-pointer">
                                        <Heart className={`w-3.5 h-3.5 ${profile?.bookmarks.includes(item.id) ? 'fill-rose-500 text-rose-500' : ''}`} />
                                      </button>
                                    </div>
                                  </div>
                                  <div>
                                    <span className="text-[10px] uppercase font-mono tracking-wider font-extrabold text-blue-600 block">
                                      Stipend: {item.stipend || "Competitive"} | {item.duration || "Summer"}
                                    </span>
                                    <h4 className="font-extrabold text-sm text-slate-950 block mt-0.5">
                                      {item.title}
                                    </h4>
                                    <span className="text-xs text-slate-600 font-bold block">{item.companyName}</span>
                                    {item.eligibility && (
                                      <span className="text-[10px] text-slate-400 block mt-0.5">Eligible: {item.eligibility}</span>
                                    )}
                                  </div>
                                </div>
                                <div className="border-t border-slate-100 pt-3 mt-4 flex justify-between items-center text-xs text-slate-600">
                                  <span className="flex items-center gap-1 font-medium"><MapPin className="w-3.5 h-3.5 text-slate-400" /> {item.location}</span>
                                  <button
                                    onClick={() => handleApplyClick(item, 'internship')}
                                    className="px-4 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold cursor-pointer shadow-sm transition-all"
                                  >
                                    Apply Internship →
                                  </button>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Careers/Jobs Column */}
                      {(jobTypeFilter === "all" || jobTypeFilter === "jobs" || jobTypeFilter === "bca") && (
                        <div className="space-y-4">
                          <h3 className="text-lg font-extrabold text-slate-950 pb-2 border-b border-slate-200 flex justify-between items-center">
                            <span>💼 Full-Time Careers ({filteredJ.length})</span>
                            <span className="text-xs font-mono font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">Entry Level</span>
                          </h3>
                          <div className="space-y-4">
                            {filteredJ.map((item) => (
                              <div key={item.id} className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex flex-col justify-between hover:border-blue-600 hover:shadow-md transition-all">
                                <div className="space-y-3">
                                  <div className="flex justify-between items-center">
                                    <img src={item.logoUrl} alt={item.companyName} className="w-10 h-10 object-cover rounded-xl border border-slate-100" referrerPolicy="no-referrer" />
                                    <div className="flex items-center gap-1.5">
                                      {item.eligibility && (
                                        <span className="text-[9px] font-bold bg-blue-50 text-blue-700 border border-blue-200 px-2 py-0.5 rounded">
                                          {item.eligibility.includes("BCA") ? "BCA Eligible" : "Degree Eligible"}
                                        </span>
                                      )}
                                      <button onClick={() => toggleBookmark(item.id)} className="p-1.5 hover:bg-slate-50 border border-slate-200 rounded-lg text-slate-400 hover:text-rose-500 cursor-pointer">
                                        <Heart className={`w-3.5 h-3.5 ${profile?.bookmarks.includes(item.id) ? 'fill-rose-500 text-rose-500' : ''}`} />
                                      </button>
                                    </div>
                                  </div>
                                  <div>
                                    <span className="text-[10px] uppercase font-mono tracking-wider font-extrabold text-emerald-600 block">
                                      Compensation: {item.salary || "Competitive"}
                                    </span>
                                    <h4 className="font-extrabold text-sm text-slate-950 block mt-0.5">
                                      {item.role}
                                    </h4>
                                    <span className="text-xs text-slate-600 font-bold block">{item.companyName}</span>
                                    {item.eligibility && (
                                      <span className="text-[10px] text-slate-400 block mt-0.5">Eligible: {item.eligibility}</span>
                                    )}
                                  </div>
                                </div>
                                <div className="border-t border-slate-100 pt-3 mt-4 flex justify-between items-center text-xs text-slate-600">
                                  <span className="flex items-center gap-1 font-medium"><MapPin className="w-3.5 h-3.5 text-slate-400" /> {item.location}</span>
                                  <button
                                    onClick={() => handleApplyClick(item, 'job')}
                                    className="px-4 py-1.5 bg-slate-950 hover:bg-blue-600 text-white rounded-lg text-xs font-bold cursor-pointer shadow-sm transition-all"
                                  >
                                    Apply Position →
                                  </button>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })()}
              </motion.div>
            )}

            {/* ------------------------------------------------------------- */}
            {/* TAB: PREP KITS & OTHER OPTIONS */}
            {/* ------------------------------------------------------------- */}
            {activeTab === "prepkits" && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-8">
                {/* Hero Header */}
                <div className="bg-gradient-to-r from-indigo-700 via-blue-700 to-slate-900 rounded-2xl p-6 md:p-8 text-white shadow-md relative overflow-hidden">
                  <div className="space-y-3 relative z-10 max-w-2xl">
                    <span className="text-[10px] uppercase font-mono tracking-wider bg-white/20 px-2.5 py-0.5 rounded-full inline-block font-extrabold">
                      Interview & Placement Accelerator
                    </span>
                    <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold tracking-tight">
                      Interview Prep Kits & Student Resources
                    </h2>
                    <p className="text-xs sm:text-sm text-indigo-100 leading-relaxed">
                      Essential cheatcards, Blind 75 DSA patterns, top 100 SQL interview queries, Harvard ATS-friendly resume templates, and system design primers for freshers.
                    </p>
                    <div className="flex flex-wrap gap-2 pt-1">
                      {["all", "dsa", "sql", "system_design", "hr", "resume"].map(cat => (
                        <button
                          key={cat}
                          onClick={() => setPrepCategory(cat)}
                          className={`px-3 py-1 rounded-lg text-xs font-bold uppercase tracking-wider transition-all ${
                            prepCategory === cat ? 'bg-white text-slate-900 shadow' : 'bg-white/10 hover:bg-white/20 text-white'
                          }`}
                        >
                          {cat === "all" ? "All Kits" : cat.replace("_", " ")}
                        </button>
                      ))}
                    </div>
                  </div>
                  <Award className="absolute right-4 bottom-2 opacity-10 w-52 h-52 pointer-events-none" />
                </div>

                {/* Prep Kits Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {PREP_KITS.filter(k => prepCategory === "all" || k.category === prepCategory).map(kit => (
                    <div key={kit.id} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between hover:border-blue-600 hover:shadow-md transition-all">
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <span className="text-[9px] font-mono font-extrabold text-blue-600 bg-blue-50 border border-blue-200 px-2.5 py-0.5 rounded-full uppercase">
                            {kit.badge}
                          </span>
                          <span className="text-[10px] text-slate-400 font-mono font-semibold">{kit.readTime}</span>
                        </div>
                        <h4 className="font-extrabold text-base text-slate-950 leading-snug">{kit.title}</h4>
                        <p className="text-xs text-slate-600 leading-relaxed">{kit.description}</p>
                      </div>

                      <div className="border-t border-slate-100 pt-4 mt-5 flex justify-between items-center">
                        <span className="text-[10px] font-mono font-bold text-slate-400 uppercase">{kit.category.replace("_", " ")}</span>
                        <a
                          href={kit.downloadUrl}
                          target="_blank"
                          rel="noreferrer"
                          className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold flex items-center gap-1 transition-all shadow-sm"
                        >
                          <Download className="w-3.5 h-3.5" /> Access Kit →
                        </a>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Additional Student Utility Options Row */}
                <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-4">
                  <h3 className="font-extrabold text-base text-slate-900 flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-blue-600" /> Academic Success Tools & Quick Actions
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
                    <div
                      onClick={() => setActiveTab("tools")}
                      className="bg-slate-50 hover:bg-blue-50/50 p-4 rounded-xl border border-slate-200 cursor-pointer transition-all text-center"
                    >
                      <span className="text-2xl block mb-1">🧮</span>
                      <h5 className="font-bold text-xs text-slate-900">SGPA & CGPA Calculator</h5>
                      <p className="text-[10px] text-slate-500 mt-0.5">Calculate 10-point semester grades & percentage formula.</p>
                    </div>

                    <div
                      onClick={() => setActiveTab("tools")}
                      className="bg-slate-50 hover:bg-blue-50/50 p-4 rounded-xl border border-slate-200 cursor-pointer transition-all text-center"
                    >
                      <span className="text-2xl block mb-1">📊</span>
                      <h5 className="font-bold text-xs text-slate-900">75% Attendance Tracker</h5>
                      <p className="text-[10px] text-slate-500 mt-0.5">Check bunk limits and university mandatory attendance.</p>
                    </div>

                    <div
                      onClick={() => setActiveTab("news")}
                      className="bg-slate-50 hover:bg-blue-50/50 p-4 rounded-xl border border-slate-200 cursor-pointer transition-all text-center"
                    >
                      <span className="text-2xl block mb-1">📢</span>
                      <h5 className="font-bold text-xs text-slate-900">AKTU 2026 UFM Rules</h5>
                      <p className="text-[10px] text-slate-500 mt-0.5">Official answer copy guidelines and notification alert.</p>
                    </div>

                    <div
                      onClick={() => setActiveTab("community")}
                      className="bg-slate-50 hover:bg-blue-50/50 p-4 rounded-xl border border-slate-200 cursor-pointer transition-all text-center"
                    >
                      <span className="text-2xl block mb-1">💬</span>
                      <h5 className="font-bold text-xs text-slate-900">Student Lounge Forum</h5>
                      <p className="text-[10px] text-slate-500 mt-0.5">Ask questions, share handwritten notes, and discuss.</p>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* ------------------------------------------------------------- */}
            {/* TAB: AISUITE */}
            {/* ------------------------------------------------------------- */}
            {activeTab === "aisuite" && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
              >
                <AiTools />
              </motion.div>
            )}

            {/* ------------------------------------------------------------- */}
            {/* TAB: STUDENTS LOUNGE / FORUM */}
            {/* ------------------------------------------------------------- */}
            {activeTab === "community" && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
              >
                <StudentCommunity user={currUser} />
              </motion.div>
            )}

            {/* ------------------------------------------------------------- */}
            {/* TAB: STUDENT TOOLS */}
            {/* ------------------------------------------------------------- */}
            {activeTab === "tools" && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
              >
                <StudentTools />
              </motion.div>
            )}

            {/* ------------------------------------------------------------- */}
            {/* TAB: ADMIN PANEL PANEL */}
            {/* ------------------------------------------------------------- */}
            {activeTab === "admin" && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
              >
                <AdminPanel
                  user={currUser}
                  isAdmin={isAdmin}
                  internships={internships}
                  jobs={jobs}
                  notes={notes}
                  blogs={blogs}
                  onAddInternship={handleAdminAddInternship}
                  onDeleteInternship={handleAdminDeleteInternship}
                  onAddJob={handleAdminAddJob}
                  onDeleteJob={handleAdminDeleteJob}
                  onAddNote={handleAdminAddNote}
                  onAddBlog={handleAdminAddBlog}
                />
              </motion.div>
            )}

            {/* ------------------------------------------------------------- */}
            {/* TAB: STUDENT PROFILE & BOOKMARKS DISPLAY */}
            {/* ------------------------------------------------------------- */}
            {activeTab === "profile" && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="space-y-8 max-w-4xl mx-auto"
              >
                {!currUser ? (
                  <div className="bg-white dark:bg-slate-950 rounded-2xl p-8 border border-slate-200 dark:border-white/5 shadow-sm text-center">
                    <User className="w-16 h-16 text-slate-300 mx-auto mb-3" />
                    <h3 className="font-bold text-lg text-slate-800 dark:text-slate-100">Private Student Dashboard</h3>
                    <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
                      Please log in with your Google Account to manage academic details, save bookmarks, and configure placements pipeline!
                    </p>
                    <button
                      onClick={signInWithGoogle}
                      className="mt-4 px-6 py-2 bg-blue-600 text-white rounded-xl text-xs font-bold hover:shadow"
                    >
                      Authenticate Google
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-start">
                    
                    {/* Left profile modifier (1col) */}
                    <div className="md:col-span-1 bg-white dark:bg-slate-950 border border-slate-200 dark:border-white/5 p-6 rounded-2xl space-y-4">
                      <div className="text-center space-y-2">
                        <img src={currUser.photoURL || undefined} alt="photo" className="w-16 h-16 rounded-full object-cover mx-auto ring-4 ring-blue-500/10" referrerPolicy="no-referrer" />
                        <h3 className="font-bold text-base">{currUser.displayName || "Student User"}</h3>
                        <span className="text-[10px] font-mono text-slate-500 block">{currUser.email}</span>
                      </div>

                      {/* Display mod details form */}
                      <ProfileForm profile={profile} onSave={handleSaveProfileDetails} />
                    </div>

                    {/* Right tracker statuses (2cols) */}
                    <div className="md:col-span-2 space-y-6">
                      
                      {/* Track Job applications */}
                      <div className="bg-white dark:bg-slate-950 p-6 border border-slate-200 dark:border-white/5 rounded-2xl space-y-4 shadow-sm">
                        <h4 className="font-semibold text-slate-800 dark:text-slate-150 flex items-center gap-1.5 text-sm">
                          <ClipboardList className="w-4 h-4 text-indigo-500" /> Active Placement Applications Statuses
                        </h4>
                        <div className="space-y-3">
                          {profile?.trackedApplications?.map((app, idx) => (
                            <div key={idx} className="bg-slate-50 dark:bg-slate-900/50 p-3.5 rounded-xl border border-slate-100 dark:border-white/5 flex justify-between items-center">
                              <div>
                                <h5 className="font-bold text-xs leading-none text-slate-800 dark:text-slate-150">{app.title}</h5>
                                <span className="text-[10px] text-slate-500 block mt-1">{app.company} • Applied on {new Date(app.appliedAt).toLocaleDateString()}</span>
                              </div>
                              <span className="inline-block px-3 py-1 bg-blue-100 text-blue-700 font-bold uppercase font-mono tracking-wider text-[9px] rounded-full">
                                {app.status}
                              </span>
                            </div>
                          ))}
                          {!profile?.trackedApplications?.length && (
                            <p className="text-xs text-slate-400 italic text-center py-6">
                              No applied opportunities registered. Tap "Apply" on any jobs / internships to automatically start tracking applications.
                            </p>
                          )}
                        </div>
                      </div>

                      {/* Heart saved bookmarks */}
                      <div className="bg-white dark:bg-slate-950 p-6 border border-slate-200 dark:border-white/5 rounded-2xl space-y-4 shadow-sm">
                        <h4 className="font-semibold text-slate-800 dark:text-slate-150 flex items-center gap-1.5 text-sm">
                          <Bookmark className="w-4 h-4 text-indigo-500" /> Bookmarked Listings
                        </h4>
                        <div className="space-y-2">
                          {profile?.bookmarks?.map((id) => {
                            const matchInt = internships.find(i => i.id === id);
                            const matchJob = jobs.find(j => j.id === id);
                            const found = matchInt || matchJob;
                            if (!found) return null;
                            return (
                              <div key={id} className="bg-slate-50 dark:bg-slate-900/50 p-3 rounded-xl flex justify-between items-center">
                                <div>
                                  <h5 className="font-bold text-xs text-slate-800 dark:text-slate-150">{matchInt ? (matchInt as Internship).title : (matchJob as Job).role}</h5>
                                  <span className="text-[9px] font-mono text-slate-500 block">Offeror: {found.companyName}</span>
                                </div>
                                <button
                                  onClick={() => toggleBookmark(id)}
                                  className="text-xs text-rose-500 font-semibold cursor-pointer py-1 px-2.5 bg-rose-50 hover:bg-rose-100/60 rounded-lg"
                                >
                                  Remove Bookmarks
                                </button>
                              </div>
                            );
                          })}
                          {!profile?.bookmarks?.length && (
                            <p className="text-xs text-slate-400 italic text-center py-6">
                              No listings pinned to bookmarks. Tap visual heart badges to save items securely.
                            </p>
                          )}
                        </div>
                      </div>

                    </div>
                  </div>
                )}
              </motion.div>
            )}

          </AnimatePresence>
        )}
      </main>

      {/* ------------------------------------------------------------- */}
      {/* EXPANDED SYSTEM MODALS (Academic Blogs expander) */}
      {/* ------------------------------------------------------------- */}
      <AnimatePresence>
        {selectedBlog && (
          <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/60 backdrop-blur-sm flex justify-center items-center p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-slate-950 max-w-2xl w-full rounded-2xl overflow-hidden border border-slate-200 dark:border-white/10 p-6 md:p-8 space-y-6 max-h-[85vh] overflow-y-auto"
            >
              <div className="flex justify-between items-start">
                <div>
                  <span className="inline-block text-[10px] uppercase font-mono font-bold text-indigo-500">Topper Chronicles</span>
                  <h3 className="text-2xl font-display font-bold text-slate-900 dark:text-white mt-1">{selectedBlog.title}</h3>
                </div>
                <button
                  onClick={() => setSelectedBlog(null)}
                  className="p-1 px-2 rounded-lg border hover:bg-slate-50 text-xs font-semibold cursor-pointer"
                >
                  Close
                </button>
              </div>

              <img src={selectedBlog.imageUrl} alt="banner" className="w-full h-56 object-cover rounded-xl" referrerPolicy="no-referrer" />
              
              <div className="text-xs text-slate-500 font-mono flex items-center gap-1">
                <span>Written by: <strong>{selectedBlog.author}</strong></span>
              </div>

              <div className="prose prose-slate dark:prose-invert font-sans text-sm text-slate-700 dark:text-slate-300 leading-relaxed border-t border-slate-100 dark:border-white/5 pt-4 whitespace-pre-wrap">
                {selectedBlog.content}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ------------------------------------------------------------- */}
      {/* FLOATING COMMUNITY CHAT WIDGET */}
      {/* ------------------------------------------------------------- */}
      <div className="fixed right-6 bottom-6 z-50 flex flex-col items-end">
        <AnimatePresence>
          {chatWidgetOpen && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 15 }}
              className="w-72 bg-white dark:bg-slate-950 border border-slate-250 dark:border-white/10 rounded-2xl shadow-xl overflow-hidden mb-3"
            >
              <div className="px-4 py-2.5 bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-semibold text-xs flex justify-between items-center shadow">
                <span className="flex items-center gap-1"><MessageCircle className="w-4 h-4" /> TechHelp Lounge Ping</span>
                <span className="w-2.5 h-2.5 bg-emerald-400 rounded-full animate-bounce" />
              </div>
              
              {/* Message Streams widget */}
              <div className="h-44 overflow-y-auto p-3 space-y-2 max-h-44 text-xs font-sans">
                {chatMessages.map(m => (
                  <div key={m.id} className="bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-white/5 p-2 rounded-xl">
                    <span className="font-bold text-blue-600 dark:text-blue-400 block pb-0.5 text-[10px]">{m.user}:</span>
                    <p className="text-slate-800 dark:text-slate-100 leading-normal">{m.text}</p>
                  </div>
                ))}
              </div>

              {/* Ping action submit */}
              <form onSubmit={handleAddCommunityMessage} className="p-2 border-t border-slate-150 bg-slate-50/50 dark:bg-slate-950/50 dark:border-white/5 flex gap-1.5 justify-between">
                <input
                  type="text"
                  required
                  placeholder="Leave a dynamic ping..."
                  className="flex-1 px-3 py-1.5 border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-900 text-[11px] rounded-lg text-slate-800 dark:text-white focus:outline-none"
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                />
                <button type="submit" className="px-2.5 py-1.5 bg-slate-900 text-white dark:bg-white dark:text-slate-900 font-bold rounded-lg text-[10px] cursor-pointer">
                  Ping
                </button>
              </form>
            </motion.div>
          )}
        </AnimatePresence>

        <button
          onClick={() => setChatWidgetOpen(!chatWidgetOpen)}
          className="p-3 bg-gradient-to-r from-blue-600 to-indigo-600 hover:shadow-lg hover:scale-105 active:scale-95 text-white rounded-full cursor-pointer shadow-md transition-all flex items-center justify-center"
        >
          {chatWidgetOpen ? <X className="w-5 h-5" /> : <MessageCircle className="w-5 h-5 animate-pulse" />}
        </button>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* STATIC FOOTER */}
      {/* ------------------------------------------------------------- */}
      <footer className="bg-white dark:bg-slate-950 border-t border-slate-200/50 dark:border-white/5 py-8 mt-12 transition-colors">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="text-center md:text-left space-y-1">
            <span className="font-bold text-slate-800 dark:text-slate-200 text-sm font-display tracking-tight">TechHelp © 2026</span>
            <p className="text-xs text-slate-500 font-serif italic">"Never Give Up"</p>
          </div>
          
          <div className="flex gap-4 text-xs font-semibold text-slate-500">
            <button onClick={() => setActiveTab("home")} className="hover:text-blue-500 cursor-pointer">Home</button>
            <span>•</span>
            <button onClick={() => setActiveTab("notes")} className="hover:text-blue-500 cursor-pointer">Study Materials</button>
            <span>•</span>
            <button onClick={() => setActiveTab("internships")} className="hover:text-blue-500 cursor-pointer">Internships</button>
            <span>•</span>
            <button onClick={() => setActiveTab("admin")} className="hover:text-blue-500 cursor-pointer text-slate-400">Sandbox Admin Panel</button>
          </div>
          
          <p className="text-[10px] text-slate-500 font-mono tracking-wide">
            SEO Indexing & Google Search Console Ready Setup
          </p>
        </div>
      </footer>
    </div>
  );
}

// -----------------------------------------------------------------
// PROFILE SETTINGS FORM WIDGET
// -----------------------------------------------------------------
function ProfileForm({ profile, onSave }: { profile: UserProfile | null; onSave: any }) {
  const [display, setDisplay] = useState(profile?.displayName || "");
  const [college, setCollege] = useState(profile?.college || "");
  const [branch, setBranch] = useState(profile?.branch || "");
  const [year, setYear] = useState(profile?.year || "3rd Year");
  const [bio, setBio] = useState(profile?.bio || "");

  useEffect(() => {
    if (profile) {
      setDisplay(profile.displayName || "");
      setCollege(profile.college || "");
      setBranch(profile.branch || "");
      setYear(profile.year || "3rd Year");
      setBio(profile.bio || "");
    }
  }, [profile]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(display.trim(), college.trim(), branch.trim(), year, bio.trim());
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-3 pt-3 border-t border-slate-100 dark:border-white/5">
      <div>
        <label className="block text-[10px] text-slate-500 mb-0.5">Display Username</label>
        <input
          type="text" required
          className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
          value={display}
          onChange={(e) => setDisplay(e.target.value)}
        />
      </div>
      <div>
        <label className="block text-[10px] text-slate-500 mb-0.5">University / College</label>
        <input
          type="text" placeholder="E.g., NIT Trichy"
          className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
          value={college}
          onChange={(e) => setCollege(e.target.value)}
        />
      </div>
      <div className="grid grid-cols-2 gap-2">
        <div>
          <label className="block text-[10px] text-slate-500 mb-0.5">Academic Branch</label>
          <input
            type="text" placeholder="E.g., CSE"
            className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
            value={branch}
            onChange={(e) => setBranch(e.target.value)}
          />
        </div>
        <div>
          <label className="block text-[10px] text-slate-500 mb-0.5">Present Year</label>
          <select
            className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
            value={year}
            onChange={(e) => setYear(e.target.value)}
          >
            <option>1st Year</option>
            <option>2nd Year</option>
            <option>3rd Year</option>
            <option>4th Year</option>
            <option>PostGrad</option>
          </select>
        </div>
      </div>
      <div>
        <label className="block text-[10px] text-slate-500 mb-0.5">Biographical Quote</label>
        <textarea
          rows={2} placeholder="Share academic thoughts..."
          className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 dark:border-white/10 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
          value={bio}
          onChange={(e) => setBio(e.target.value)}
        />
      </div>
      <button
        type="submit"
        className="w-full py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold transition-all shadow-sm cursor-pointer"
      >
        Save Details
      </button>
    </form>
  );
}
