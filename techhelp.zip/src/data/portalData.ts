import { StudyMaterial, Job, Internship } from "../types";

export interface PrepKit {
  id: string;
  title: string;
  category: "dsa" | "sql" | "system_design" | "hr" | "resume";
  readTime: string;
  description: string;
  downloadUrl: string;
  badge: string;
}

export interface OffCampusDrive {
  id: string;
  company: string;
  role: string;
  batch: string;
  package: string;
  deadline: string;
  eligibility: string;
  applyUrl: string;
  status: "Active" | "Closing Soon" | "Upcoming";
}

// -------------------------------------------------------------
// COMPREHENSIVE STUDY MATERIALS (BCA, B.TECH, MCA, MBA, B.PHARM)
// -------------------------------------------------------------
export const ALL_DEFAULT_MATERIALS: Omit<StudyMaterial, "id">[] = [
  // --- BCA NOTES & MATERIALS ---
  {
    title: "BCA Complete C Programming & Algorithm Handbook (Units 1-5)",
    category: "notes",
    subject: "Programming in C (BCA-101)",
    branch: "BCA",
    semester: "Sem 1",
    units: "Units 1-5",
    downloadUrl: "https://www.google.com/search?q=BCA+Programming+in+C+Notes+PDF",
    downloadsCount: 520,
    uploadedBy: "Prof. Rajesh Sharma (HOD CS)",
    createdAt: "2026-05-10T10:00:00Z"
  },
  {
    title: "BCA Digital Computer Fundamentals & Architecture Handout",
    category: "notes",
    subject: "Computer Fundamentals & Architecture (BCA-102)",
    branch: "BCA",
    semester: "Sem 1",
    units: "Units 1-4",
    downloadUrl: "https://www.google.com/search?q=BCA+Digital+Computer+Fundamentals+Notes+PDF",
    downloadsCount: 410,
    uploadedBy: "TechHelp Academic Cell",
    createdAt: "2026-05-12T11:00:00Z"
  },
  {
    title: "BCA Data Structures & Algorithms Using C/C++ Solved Notes & Code",
    category: "notes",
    subject: "Data Structures Using C (BCA-201)",
    branch: "BCA",
    semester: "Sem 2",
    units: "Full Syllabus (Trees, Graphs, Sorting)",
    downloadUrl: "https://www.google.com/search?q=BCA+Data+Structures+Using+C+Notes+PDF",
    downloadsCount: 880,
    uploadedBy: "Topper Student Circle",
    createdAt: "2026-05-15T09:30:00Z"
  },
  {
    title: "BCA Object Oriented Programming with C++ Complete Guide",
    category: "notes",
    subject: "OOPs with C++ (BCA-202)",
    branch: "BCA",
    semester: "Sem 2",
    units: "Units 1-5",
    downloadUrl: "https://www.google.com/search?q=BCA+OOPs+C%2B%2B+Notes+PDF",
    downloadsCount: 645,
    uploadedBy: "Prof. K. N. Rao",
    createdAt: "2026-05-18T14:00:00Z"
  },
  {
    title: "BCA Database Management Systems (SQL, Normalization & ER Diagrams)",
    category: "notes",
    subject: "DBMS & SQL Queries (BCA-301)",
    branch: "BCA",
    semester: "Sem 3",
    units: "Full Notes + 50 SQL Practice Queries",
    downloadUrl: "https://www.google.com/search?q=BCA+DBMS+Notes+PDF",
    downloadsCount: 930,
    uploadedBy: "Abhishek Maurya (Notes Gallery Admin)",
    createdAt: "2026-05-20T16:20:00Z"
  },
  {
    title: "BCA Computer Networks & Data Communication Comprehensive Notes",
    category: "notes",
    subject: "Computer Networks (BCA-302)",
    branch: "BCA",
    semester: "Sem 3",
    units: "OSI 7 Layers, TCP/IP, Routing Protocols",
    downloadUrl: "https://www.google.com/search?q=BCA+Computer+Networks+Notes+PDF",
    downloadsCount: 710,
    uploadedBy: "TechHelp Academic Section",
    createdAt: "2026-05-22T08:45:00Z"
  },
  {
    title: "BCA Java & Object Oriented System Design Master Notes",
    category: "notes",
    subject: "Core Java & GUI Design (BCA-401)",
    branch: "BCA",
    semester: "Sem 4",
    units: "Java OOPs, Multithreading, JDBC, Swing",
    downloadUrl: "https://www.google.com/search?q=BCA+Java+Programming+Notes+PDF",
    downloadsCount: 1140,
    uploadedBy: "Alumni Mentor Team",
    createdAt: "2026-05-25T12:00:00Z"
  },
  {
    title: "BCA Web Technology (HTML5, CSS3, Modern JS, PHP & MySQL) Guide",
    category: "notes",
    subject: "Web Technology & Internet Basics (BCA-402)",
    branch: "BCA",
    semester: "Sem 4",
    units: "Complete Frontend & Backend Notes",
    downloadUrl: "https://www.google.com/search?q=BCA+Web+Technology+Notes+PDF",
    downloadsCount: 1020,
    uploadedBy: "TechHelp Dev Community",
    createdAt: "2026-05-28T15:30:00Z"
  },
  {
    title: "BCA Python Programming for Data Analysis & Automation Guide",
    category: "notes",
    subject: "Python Programming (BCA-501)",
    branch: "BCA",
    semester: "Sem 5",
    units: "Python Syntax, NumPy, Pandas, Matplotlib",
    downloadUrl: "https://www.google.com/search?q=BCA+Python+Programming+Notes+PDF",
    downloadsCount: 890,
    uploadedBy: "Data Analytics Lab",
    createdAt: "2026-06-01T10:15:00Z"
  },
  {
    title: "BCA Software Engineering Principles & Agile Scrum Notes",
    category: "notes",
    subject: "Software Engineering (BCA-502)",
    branch: "BCA",
    semester: "Sem 5",
    units: "SDLC, Waterfall vs Agile, Testing & QA",
    downloadUrl: "https://www.google.com/search?q=BCA+Software+Engineering+Notes+PDF",
    downloadsCount: 670,
    uploadedBy: "Prof. S. Sengupta",
    createdAt: "2026-06-03T11:00:00Z"
  },
  {
    title: "BCA Cloud Computing & Virtualization Fundamentals",
    category: "notes",
    subject: "Cloud Computing & AWS Basics (BCA-601)",
    branch: "BCA",
    semester: "Sem 6",
    units: "IaaS, PaaS, SaaS, AWS EC2, S3 & Security",
    downloadUrl: "https://www.google.com/search?q=BCA+Cloud+Computing+Notes+PDF",
    downloadsCount: 560,
    uploadedBy: "Cloud Architecture Club",
    createdAt: "2026-06-05T13:40:00Z"
  },
  {
    title: "BCA 5-Year Solved University Model Papers & Question Bank",
    category: "pyq",
    subject: "All Major Subjects (Sem 1 to 6)",
    branch: "BCA",
    semester: "Sem 1-6",
    units: "5 Years Solved Papers with Marking Scheme",
    downloadUrl: "https://www.google.com/search?q=BCA+Previous+Year+Question+Papers+Solved+PDF",
    downloadsCount: 1650,
    uploadedBy: "AKTU & Regional University Gold Medalist Panel",
    createdAt: "2026-06-07T09:00:00Z"
  },
  {
    title: "BCA Official Complete 3-Year Curriculum & Syllabus Register",
    category: "syllabus",
    subject: "Official University Regulation & Credit Scheme",
    branch: "BCA",
    semester: "All Semesters",
    units: "Semesters 1 through 6 Credits & Lab Details",
    downloadUrl: "https://www.google.com/search?q=BCA+Official+Syllabus+PDF",
    downloadsCount: 780,
    uploadedBy: "Registrar Academic Board",
    createdAt: "2026-06-08T14:10:00Z"
  },
  {
    title: "BCA Solved Quantum Series: Operating Systems & Unix Shell",
    category: "quantum",
    subject: "Operating Systems (BCA-303)",
    branch: "BCA",
    semester: "Sem 3",
    units: "Last Night Prep Solved Quantum Edition",
    downloadUrl: "https://www.google.com/search?q=BCA+Operating+Systems+Quantum+Solved+PDF",
    downloadsCount: 940,
    uploadedBy: "Abhishek Maurya (Notes Gallery Admin)",
    createdAt: "2026-06-09T17:00:00Z"
  },

  // --- B.TECH NOTES & MATERIALS ---
  {
    title: "Operating Systems In-Depth Concepts (Process, Threads, Memory, Locks)",
    category: "notes",
    subject: "Operating Systems (KCS-401)",
    branch: "B.Tech CSE",
    semester: "Sem 4",
    units: "Units 1-5 Detailed Handwritten Notes",
    downloadUrl: "https://www.google.com/search?q=AKTU+Operating+Systems+Notes+PDF",
    downloadsCount: 1220,
    uploadedBy: "Prof. Verma (IIT Alumni)",
    createdAt: "2026-05-10T08:00:00Z"
  },
  {
    title: "Full DBMS Lecture Notes & CheatSheet",
    category: "notes",
    subject: "Database Management Systems (KCS-501)",
    branch: "B.Tech CSE",
    semester: "Sem 5",
    units: "Units 1-5",
    downloadUrl: "https://courses.cs.washington.edu/courses/cse444/18sp/materials/notes.pdf",
    downloadsCount: 1420,
    uploadedBy: "Admin Prof. Verma",
    createdAt: "2026-05-11T09:00:00Z"
  },
  {
    title: "Computer Networks (TCP/IP, Routing Algorithms, Socket Programming)",
    category: "notes",
    subject: "Computer Networks (KCS-601)",
    branch: "B.Tech CSE",
    semester: "Sem 6",
    units: "Complete Handwritten Bookmarks",
    downloadUrl: "https://www.google.com/search?q=Computer+Networks+Notes+AKTU+PDF",
    downloadsCount: 890,
    uploadedBy: "Siddharth Sen (Director of Engg)",
    createdAt: "2026-05-13T10:00:00Z"
  },
  {
    title: "Theory of Computation & Automata (TOC) Hand-drawn Notes",
    category: "notes",
    subject: "Theory of Automata & Formal Languages (KCS-502)",
    branch: "B.Tech CSE",
    semester: "Sem 5",
    units: "DFA, NFA, PDA, Turing Machines",
    downloadUrl: "https://www.google.com/search?q=Theory+of+Computation+AKTU+Notes+PDF",
    downloadsCount: 960,
    uploadedBy: "Topper Student",
    createdAt: "2026-05-14T11:00:00Z"
  },
  {
    title: "Artificial Intelligence & Machine Learning Math & Algorithms",
    category: "notes",
    subject: "Artificial Intelligence (KCS-071)",
    branch: "B.Tech CSE",
    semester: "Sem 7",
    units: "Search, Game Playing, Neural Networks",
    downloadUrl: "https://www.google.com/search?q=Artificial+Intelligence+AKTU+Notes+PDF",
    downloadsCount: 750,
    uploadedBy: "AI Research Fellow",
    createdAt: "2026-05-16T12:00:00Z"
  },
  {
    title: "Data Structures & Algorithms Previous Year Questions (MIT/IIT/AKTU)",
    category: "pyq",
    subject: "Data Structures and Algorithms (KCS-301)",
    branch: "B.Tech CSE",
    semester: "Sem 3",
    units: "Solved Exam Papers",
    downloadUrl: "https://dspace.mit.edu/bitstream/handle/1721.1/108343/6-046j-spring-2015/contents/exams/MIT6_046JS15_exam1.pdf",
    downloadsCount: 1389,
    uploadedBy: "Topper Student",
    createdAt: "2026-05-17T13:00:00Z"
  },
  {
    title: "BTech CS Syllabus and Subject Outline 2026",
    category: "syllabus",
    subject: "Operating Systems, Networking, Compiler Design",
    branch: "B.Tech CSE",
    semester: "All Semesters",
    units: "Full AICTE/AKTU Syllabus",
    downloadUrl: "https://www.google.com/search?q=AKTU+BTech+CSE+Syllabus+PDF",
    downloadsCount: 610,
    uploadedBy: "TechHelp Academic Section",
    createdAt: "2026-05-18T14:00:00Z"
  },
  {
    title: "Web Technology Quantum Series (Semester 6)",
    category: "quantum",
    subject: "Web Technology (CSE-301)",
    branch: "B.Tech CSE",
    semester: "Sem 6",
    units: "Complete Solved Unit 1-5",
    downloadUrl: "https://www.google.com/search?q=Web+Technology+Quantum+AKTU",
    downloadsCount: 1421,
    uploadedBy: "Abhishek Maurya (Notes Gallery Admin)",
    createdAt: "2026-05-19T15:00:00Z"
  },
  {
    title: "Compiler Design Quantum Series (Semester 5)",
    category: "quantum",
    subject: "Compiler Design (CSE-501)",
    branch: "B.Tech CSE",
    semester: "Sem 5",
    units: "Lexical, Syntax, Semantic Analysis Solved",
    downloadUrl: "https://www.google.com/search?q=Compiler+Design+Quantum+AKTU",
    downloadsCount: 1310,
    uploadedBy: "Abhishek Maurya (Notes Gallery Admin)",
    createdAt: "2026-05-20T16:00:00Z"
  },

  // --- MCA MATERIALS ---
  {
    title: "Software Engineering & OOD Quantum Series",
    category: "quantum",
    subject: "Software Engineering (MCA-203)",
    branch: "MCA",
    semester: "Sem 2",
    units: "Unit 1-5 Solved Questions",
    downloadUrl: "https://www.google.com/search?q=MCA+Software+Engineering+Quantum+AKTU",
    downloadsCount: 819,
    uploadedBy: "Notes Gallery Team",
    createdAt: "2026-05-21T10:00:00Z"
  },
  {
    title: "MCA Advanced Java & Enterprise Application Architecture",
    category: "notes",
    subject: "Advanced Java & Spring Framework (MCA-301)",
    branch: "MCA",
    semester: "Sem 3",
    units: "Servlets, JSP, Spring Boot, Hibernate",
    downloadUrl: "https://www.google.com/search?q=MCA+Advanced+Java+Notes+PDF",
    downloadsCount: 670,
    uploadedBy: "MCA Tech Circle",
    createdAt: "2026-05-22T11:00:00Z"
  },
  {
    title: "MCA Data Warehousing & Big Data Solved Examination Papers",
    category: "pyq",
    subject: "Big Data Analytics (MCA-402)",
    branch: "MCA",
    semester: "Sem 4",
    units: "Hadoop, MapReduce, Spark Solved Questions",
    downloadUrl: "https://www.google.com/search?q=MCA+Big+Data+PYQ+PDF",
    downloadsCount: 540,
    uploadedBy: "MCA Faculty Coordinator",
    createdAt: "2026-05-23T12:00:00Z"
  },

  // --- MBA MATERIALS ---
  {
    title: "Managerial Economics Quantum Series (Semester 1)",
    category: "quantum",
    subject: "Managerial Economics (MBA-102)",
    branch: "MBA",
    semester: "Sem 1",
    units: "Demand Analysis, Market Structures, Pricing",
    downloadUrl: "https://www.google.com/search?q=MBA+Managerial+Economics+Quantum+AKTU",
    downloadsCount: 785,
    uploadedBy: "Notes Gallery Team",
    createdAt: "2026-05-24T13:00:00Z"
  },
  {
    title: "MBA Strategic Management & Corporate Governance Cases",
    category: "notes",
    subject: "Strategic Management (MBA-301)",
    branch: "MBA",
    semester: "Sem 3",
    units: "Porter 5 Forces, SWOT, Case Analyses",
    downloadUrl: "https://www.google.com/search?q=MBA+Strategic+Management+Notes+PDF",
    downloadsCount: 620,
    uploadedBy: "Business School Mentors",
    createdAt: "2026-05-25T14:00:00Z"
  },
  {
    title: "MBA Financial Management & Ratio Analysis Solved Workbook",
    category: "notes",
    subject: "Financial Management (MBA-201)",
    branch: "MBA",
    semester: "Sem 2",
    units: "Capital Budgeting, Cost of Capital, Working Capital",
    downloadUrl: "https://www.google.com/search?q=MBA+Financial+Management+Notes+PDF",
    downloadsCount: 840,
    uploadedBy: "Prof. S. R. Mathur",
    createdAt: "2026-05-26T15:00:00Z"
  },

  // --- B.PHARM MATERIALS ---
  {
    title: "Pharmacology I Quantum Edition (Semester 4)",
    category: "quantum",
    subject: "Pharmacology (BP-401T)",
    branch: "B.Pharm",
    semester: "Sem 4",
    units: "Drug Mechanisms & ANS Pharmacology",
    downloadUrl: "https://www.google.com/search?q=B.Pharm+Pharmacology+Quantum+AKTU",
    downloadsCount: 654,
    uploadedBy: "Notes Gallery Team",
    createdAt: "2026-05-27T16:00:00Z"
  },
  {
    title: "B.Pharm Medicinal Chemistry II Solved Notes & Structures",
    category: "notes",
    subject: "Medicinal Chemistry II (BP-501T)",
    branch: "B.Pharm",
    semester: "Sem 5",
    units: "Chemical Structures, SAR, Synthesis",
    downloadUrl: "https://www.google.com/search?q=B.Pharm+Medicinal+Chemistry+Notes+PDF",
    downloadsCount: 590,
    uploadedBy: "Pharmacy Research Wing",
    createdAt: "2026-05-28T17:00:00Z"
  }
];

// -------------------------------------------------------------
// EXPANDED JOB OPPORTUNITIES (TECH, FRESHERS, BCA & BTECH FRIENDLY)
// -------------------------------------------------------------
export const ALL_DEFAULT_JOBS: Omit<Job, "id">[] = [
  {
    companyName: "Google",
    logoUrl: "https://images.unsplash.com/photo-1573804633927-bfcbcd909acd?auto=format&fit=crop&w=120&h=120&q=80",
    role: "Associate Software Engineer",
    salary: "₹24,00,000 / year",
    location: "Bangalore, India (Hybrid)",
    applyUrl: "https://careers.google.com/jobs",
    createdAt: "2026-06-01T10:00:00Z",
    eligibility: "BCA / B.Tech / MCA (2025/2026 Batch)",
    category: "Software Engineering",
    expLevel: "Freshers (0-1 yr)"
  },
  {
    companyName: "Microsoft",
    logoUrl: "https://images.unsplash.com/photo-1625014618427-fbc980b974f5?auto=format&fit=crop&w=120&h=120&q=80",
    role: "Junior Cloud Operations Engineer",
    salary: "₹16,50,000 / year",
    location: "Hyderabad, India",
    applyUrl: "https://careers.microsoft.com",
    createdAt: "2026-06-02T11:00:00Z",
    eligibility: "BCA / B.Tech / MCA",
    category: "Cloud / DevOps",
    expLevel: "Entry Level"
  },
  {
    companyName: "Amazon",
    logoUrl: "https://images.unsplash.com/photo-1523474253243-231dfc1676b6?auto=format&fit=crop&w=120&h=120&q=80",
    role: "Software Development Engineer I (SDE 1)",
    salary: "₹22,00,000 / year",
    location: "Bangalore / Hyderabad",
    applyUrl: "https://amazon.jobs",
    createdAt: "2026-06-03T09:00:00Z",
    eligibility: "B.Tech CSE / IT / BCA with DSA",
    category: "Software Engineering",
    expLevel: "Freshers (0-1 yr)"
  },
  {
    companyName: "Stripe",
    logoUrl: "https://images.unsplash.com/photo-1551434678-e076c223a692?auto=format&fit=crop&w=120&h=120&q=80",
    role: "Associate Frontend Developer",
    salary: "₹18,00,000 / year ($120k remote)",
    location: "Remote (India / Global)",
    applyUrl: "https://stripe.com/jobs",
    createdAt: "2026-06-04T12:00:00Z",
    eligibility: "BCA / B.Tech / Any Graduate with React",
    category: "Web / Frontend",
    expLevel: "Entry Level"
  },
  {
    companyName: "Zomato",
    logoUrl: "https://images.unsplash.com/photo-1526367790999-0150786686a2?auto=format&fit=crop&w=120&h=120&q=80",
    role: "Junior Backend Engineer (Python/Go)",
    salary: "₹17,50,000 / year",
    location: "Gurgaon, India",
    applyUrl: "https://www.zomato.com/careers",
    createdAt: "2026-06-05T14:30:00Z",
    eligibility: "BCA / B.Tech / MCA",
    category: "Backend Development",
    expLevel: "0-1 Years"
  },
  {
    companyName: "Swiggy",
    logoUrl: "https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&w=120&h=120&q=80",
    role: "Associate React & Mobile Developer",
    salary: "₹15,00,000 / year",
    location: "Bangalore (Hybrid)",
    applyUrl: "https://careers.swiggy.com",
    createdAt: "2026-06-06T10:15:00Z",
    eligibility: "BCA / B.Tech (Strong JS/React)",
    category: "Web & Mobile",
    expLevel: "Freshers"
  },
  {
    companyName: "Infosys",
    logoUrl: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=120&h=120&q=80",
    role: "Specialist Programmer (Power Programmer)",
    salary: "₹9,50,000 / year",
    location: "Pune / Noida / Bangalore",
    applyUrl: "https://career.infosys.com",
    createdAt: "2026-06-07T13:00:00Z",
    eligibility: "BCA / B.Tech / MCA 2026 Batch",
    category: "Competitive Coding",
    expLevel: "Fresher Campus/Off-Campus"
  },
  {
    companyName: "Tata Consultancy Services (TCS)",
    logoUrl: "https://images.unsplash.com/photo-1542744173-8e7e53415bb0?auto=format&fit=crop&w=120&h=120&q=80",
    role: "TCS Digital Innovator & Software Trainee",
    salary: "₹7,50,000 / year",
    location: "Pan-India (Multiple Locations)",
    applyUrl: "https://www.tcs.com/careers",
    createdAt: "2026-06-08T08:30:00Z",
    eligibility: "BCA / B.Tech / MCA (Via TCS NQT)",
    category: "Software Trainee",
    expLevel: "Freshers (2025/2026)"
  },
  {
    companyName: "PhonePe",
    logoUrl: "https://images.unsplash.com/photo-1559526324-4b87b5e36e44?auto=format&fit=crop&w=120&h=120&q=80",
    role: "Quality Assurance & Automation Engineer",
    salary: "₹14,00,000 / year",
    location: "Pune / Bangalore",
    applyUrl: "https://www.phonepe.com/careers",
    createdAt: "2026-06-09T15:00:00Z",
    eligibility: "BCA / B.Tech / MCA with Java/Selenium",
    category: "QA & Automation",
    expLevel: "Entry Level"
  },
  {
    companyName: "Flipkart",
    logoUrl: "https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?auto=format&fit=crop&w=120&h=120&q=80",
    role: "Associate Frontend & UI Systems Developer",
    salary: "₹13,50,000 / year",
    location: "Bengaluru, India",
    applyUrl: "https://www.flipkartcareers.com",
    createdAt: "2026-06-10T11:20:00Z",
    eligibility: "BCA / B.Tech / MCA",
    category: "UI/UX & Frontend",
    expLevel: "0-1 Years"
  },
  {
    companyName: "Deloitte",
    logoUrl: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&w=120&h=120&q=80",
    role: "Technology Analyst - Cyber & Risk Systems",
    salary: "₹10,50,000 / year",
    location: "Gurugram / Hyderabad",
    applyUrl: "https://www2.deloitte.com/careers",
    createdAt: "2026-06-11T09:40:00Z",
    eligibility: "BCA / B.Tech / MCA / MBA Tech",
    category: "Consulting & Cyber",
    expLevel: "Freshers"
  },
  {
    companyName: "Wipro",
    logoUrl: "https://images.unsplash.com/photo-1519389950473-47ba0277781c?auto=format&fit=crop&w=120&h=120&q=80",
    role: "Project Engineer (Turbo Hire)",
    salary: "₹6,50,000 / year",
    location: "Greater Noida / Bengaluru",
    applyUrl: "https://careers.wipro.com",
    createdAt: "2026-06-12T14:00:00Z",
    eligibility: "BCA (WILP Eligible) & B.Tech",
    category: "IT Services",
    expLevel: "Freshers"
  }
];

// -------------------------------------------------------------
// EXPANDED INTERNSHIPS (PAID & STIPEND BACKED)
// -------------------------------------------------------------
export const ALL_DEFAULT_INTERNSHIPS: Omit<Internship, "id">[] = [
  {
    companyName: "Google",
    logoUrl: "https://images.unsplash.com/photo-1573804633927-bfcbcd909acd?auto=format&fit=crop&w=120&h=120&q=80",
    title: "Software Engineering Summer Intern 2026",
    stipend: "₹1,25,000 / month ($8,500)",
    location: "Bangalore, India (Hybrid)",
    duration: "3 Months (Summer 2026)",
    applyUrl: "https://careers.google.com/jobs",
    createdAt: "2026-06-01T10:00:00Z",
    eligibility: "Pre-Final / Final Year BCA & B.Tech",
    category: "Software Development"
  },
  {
    companyName: "Microsoft",
    logoUrl: "https://images.unsplash.com/photo-1625014618427-fbc980b974f5?auto=format&fit=crop&w=120&h=120&q=80",
    title: "Explore Program Software Engineering Intern",
    stipend: "₹80,000 / month",
    location: "Hyderabad, India",
    duration: "2 Months",
    applyUrl: "https://careers.microsoft.com",
    createdAt: "2026-06-02T11:00:00Z",
    eligibility: "1st, 2nd, 3rd Year BCA & B.Tech",
    category: "Software Engineering"
  },
  {
    companyName: "Amazon",
    logoUrl: "https://images.unsplash.com/photo-1523474253243-231dfc1676b6?auto=format&fit=crop&w=120&h=120&q=80",
    title: "SDE Intern (6 Months Co-Op / Summer)",
    stipend: "₹1,10,000 / month",
    location: "Bengaluru, India",
    duration: "6 Months",
    applyUrl: "https://amazon.jobs",
    createdAt: "2026-06-03T09:00:00Z",
    eligibility: "BCA / B.Tech / MCA",
    category: "Backend & Systems"
  },
  {
    companyName: "Cisco",
    logoUrl: "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=120&h=120&q=80",
    title: "Network & Security Engineering Intern",
    stipend: "₹75,000 / month",
    location: "Bengaluru, India",
    duration: "4 Months",
    applyUrl: "https://jobs.cisco.com",
    createdAt: "2026-06-04T12:00:00Z",
    eligibility: "BCA / B.Tech with Networking Knowledge",
    category: "Networking & Cyber"
  },
  {
    companyName: "IBM",
    logoUrl: "https://images.unsplash.com/photo-1568952433726-3896e3881c65?auto=format&fit=crop&w=120&h=120&q=80",
    title: "Cognitive AI & Cloud Intern",
    stipend: "₹60,000 / month",
    location: "Gurgaon / Noida",
    duration: "3 Months",
    applyUrl: "https://www.ibm.com/careers",
    createdAt: "2026-06-05T13:00:00Z",
    eligibility: "BCA / B.Tech / MCA",
    category: "AI & Cloud"
  },
  {
    companyName: "Atlassian",
    logoUrl: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=120&h=120&q=80",
    title: "Full-Stack Development Intern",
    stipend: "₹1,00,000 / month",
    location: "Remote (India)",
    duration: "3 Months",
    applyUrl: "https://www.atlassian.com/company/careers",
    createdAt: "2026-06-06T15:00:00Z",
    eligibility: "BCA & B.Tech Enthusiasts",
    category: "Full-Stack"
  },
  {
    companyName: "Goldman Sachs",
    logoUrl: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=120&h=120&q=80",
    title: "Summer Analyst Engineering Intern",
    stipend: "₹1,25,000 / month",
    location: "Bengaluru, India",
    duration: "2 Months",
    applyUrl: "https://www.goldmansachs.com/careers",
    createdAt: "2026-06-07T10:00:00Z",
    eligibility: "BCA / B.Tech / MCA",
    category: "Fintech Systems"
  },
  {
    companyName: "Razorpay",
    logoUrl: "https://images.unsplash.com/photo-1556742049-0a67c5574f73?auto=format&fit=crop&w=120&h=120&q=80",
    title: "Product Design & Frontend Engineering Intern",
    stipend: "₹55,000 / month",
    location: "Bengaluru (Hybrid)",
    duration: "3 Months",
    applyUrl: "https://razorpay.com/jobs",
    createdAt: "2026-06-08T11:00:00Z",
    eligibility: "BCA / B.Tech (React/Figma)",
    category: "Frontend & UI"
  }
];

// -------------------------------------------------------------
// OTHER VALUABLE STUDENT OPTIONS: PREP KITS & CAREER LAUNCHPAD
// -------------------------------------------------------------
export const PREP_KITS: PrepKit[] = [
  {
    id: "dsa75",
    title: "Top 75 Blind DSA Coding Patterns Handbook",
    category: "dsa",
    readTime: "25 min read",
    description: "The most asked interview questions across Arrays, Two Pointers, Trees, Graphs, and DP with Python/C++/Java solutions.",
    downloadUrl: "https://www.google.com/search?q=Blind+75+DSA+Sheet+PDF",
    badge: "Most Popular"
  },
  {
    id: "sql100",
    title: "SQL Interview Mastery: Top 100 Queries & Tricky Joins",
    category: "sql",
    readTime: "15 min read",
    description: "Master Window functions (ROW_NUMBER, DENSE_RANK), Self Joins, Subqueries, and Index optimization for data & developer rounds.",
    downloadUrl: "https://www.google.com/search?q=Top+100+SQL+Interview+Queries+PDF",
    badge: "High Yield"
  },
  {
    id: "systemdesign",
    title: "System Design for Freshers & Entry-Level Roles",
    category: "system_design",
    readTime: "20 min read",
    description: "Learn how to design scalable apps: Load balancing, Caching with Redis, Database sharding, Microservices vs Monolith.",
    downloadUrl: "https://www.google.com/search?q=System+Design+Primer+for+College+Students+PDF",
    badge: "Core Tech"
  },
  {
    id: "hrkit",
    title: "HR & Behavioral Interview Toolkit (STAR Method)",
    category: "hr",
    readTime: "10 min read",
    description: "Structured answers to 'Tell me about yourself', conflict resolution, leadership examples, and questions to ask the interviewer.",
    downloadUrl: "https://www.google.com/search?q=STAR+Method+Behavioral+Interview+Questions+PDF",
    badge: "Essential"
  },
  {
    id: "resumeats",
    title: "Harvard Style ATS-Friendly Resume Templates (Word & LaTeX)",
    category: "resume",
    readTime: "5 min template",
    description: "Single-page clean resume template proven to pass 99% ATS filters in top tech firms and Indian campus drives.",
    downloadUrl: "https://www.google.com/search?q=Harvard+College+Bulletproof+Resume+Template+Word+PDF",
    badge: "Free Download"
  }
];

// -------------------------------------------------------------
// OFF-CAMPUS DRIVES & HIRING CALENDAR
// -------------------------------------------------------------
export const OFF_CAMPUS_DRIVES: OffCampusDrive[] = [
  {
    id: "tcs-nqt-2026",
    company: "Tata Consultancy Services (TCS)",
    role: "Ninja & Digital Innovator Trainee",
    batch: "2025 & 2026 Batch",
    package: "₹3.6 LPA - ₹7.5 LPA",
    deadline: "Open Active Registration",
    eligibility: "BCA, B.Tech, MCA, B.Sc (IT)",
    applyUrl: "https://www.tcs.com/careers/tcs-nqt",
    status: "Active"
  },
  {
    id: "infy-tq-2026",
    company: "Infosys",
    role: "Systems Engineer & Specialist Programmer",
    batch: "2026 Graduating Batch",
    package: "₹3.8 LPA - ₹9.5 LPA",
    deadline: "Closes this month",
    eligibility: "BCA, B.Tech, MCA",
    applyUrl: "https://career.infosys.com",
    status: "Closing Soon"
  },
  {
    id: "cognizant-genc",
    company: "Cognizant",
    role: "GenC & GenC Elevate Programmer",
    batch: "2025 / 2026 Batch",
    package: "₹4.5 LPA - ₹6.75 LPA",
    deadline: "Rolling Registrations",
    eligibility: "BCA / B.Tech / MCA",
    applyUrl: "https://careers.cognizant.com",
    status: "Active"
  },
  {
    id: "wipro-turbo",
    company: "Wipro",
    role: "Elite National Talent Hunt & WILP",
    batch: "2025 & 2026 Batch",
    package: "₹3.5 LPA - ₹6.5 LPA",
    deadline: "Upcoming Cycle",
    eligibility: "BCA (WILP Eligible) & B.Tech",
    applyUrl: "https://careers.wipro.com",
    status: "Upcoming"
  }
];
